export interface Category {
    id: number;
    name: string;
    serviceTypeId: number;
    serviceCount: number;
  }