export interface CustomJwtPayload {
    userId: string;
    email: string;
    "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/emailaddress"?: string;
    exp:number;
  }