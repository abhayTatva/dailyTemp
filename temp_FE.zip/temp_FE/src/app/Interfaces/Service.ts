export interface Service {
  id: number;
  subCategoryId: number;
  subCategoryName: string;
  categoryId: number;
  serviceTypeId: number;
  name: string;
  description: string;
  price: number;
  commissionPct: number;
  durationMin: number;
  isAvailable: boolean;
  createdBy: number;
  createdOn: string;       
  modifiedBy: number | null;
  modifiedOn: string | null;
}

export interface ServiceWithImage {
  id: number;
  name: string;
  price: number;
  imagePath: string | null;
}