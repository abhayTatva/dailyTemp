export interface ServiceDetail {
    id: number;
    name: string;
    description: string;
    serviceType: string;
    serviceTypeId:number;
    category: string;
    categoryId: number; 
    subCategory: string;
    subCategoryId: number;
    price: number;
    commissionPct: number;
    duration: string;
    availability: string;
    images: string[];
    includes: string[];
    excludes: string[];
  }