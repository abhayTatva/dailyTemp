interface Service {
    id: number;
    name: string;
    duration: string;
    price: number;
    description: string;
    imagePath: string;
    serviceTypeId:number;
  }
  
  interface SubCategoryGroup {
    id: number;
    name: string;
    serviceCount: number;
    services: Service[];
  }
  
  interface CategoryGroup {
    id: number;
    name: string;
    isExpanded: boolean;
    subCategories: SubCategoryGroup[];
  }
  