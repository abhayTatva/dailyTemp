export interface ServiceType {
    id: number;
    name: string;
    imagePath: string;
    bookingCount:number;
  }