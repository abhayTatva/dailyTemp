import { Routes } from '@angular/router';

import {USER_ROUTES} from './routes/user.routes'; 
import {ADMIN_ROUTES} from './routes/admin.routes'; 
import { UserErrorPage } from './features/user-panel/pages/user-error-page/user-error-page';

export const routes: Routes = [
  ...ADMIN_ROUTES,
  ...USER_ROUTES,

  {
    path:'**',
    component:UserErrorPage
  }

];
