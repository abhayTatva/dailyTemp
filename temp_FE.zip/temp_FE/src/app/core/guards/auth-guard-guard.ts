import { CanActivateFn, Router } from '@angular/router';
import { AuthService } from '../../features/user-panel/services/auth-service/auth-service';
import { inject } from '@angular/core';

export const authGuardGuard: CanActivateFn = (route, state) => {
  
  const authService=inject(AuthService);
  const router=inject(Router);

  if(authService.isLoggedIn())
  {
    return true;
  }

  return router.createUrlTree(['/error']);
};
