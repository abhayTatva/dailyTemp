import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AdminErrorPage } from './admin-error-page';

describe('AdminErrorPage', () => {
  let component: AdminErrorPage;
  let fixture: ComponentFixture<AdminErrorPage>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [AdminErrorPage]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AdminErrorPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
