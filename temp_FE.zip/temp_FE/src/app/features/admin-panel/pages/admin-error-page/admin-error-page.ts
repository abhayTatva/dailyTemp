import { Component } from '@angular/core';

@Component({
  selector: 'app-admin-error-page',
  imports: [],
  templateUrl: './admin-error-page.html',
  styleUrl: './admin-error-page.css',
})
export class AdminErrorPage {

}
