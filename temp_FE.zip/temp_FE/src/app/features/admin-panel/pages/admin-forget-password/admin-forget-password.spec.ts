import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AdminForgetPassword } from './admin-forget-password';

describe('AdminForgetPassword', () => {
  let component: AdminForgetPassword;
  let fixture: ComponentFixture<AdminForgetPassword>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [AdminForgetPassword]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AdminForgetPassword);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
