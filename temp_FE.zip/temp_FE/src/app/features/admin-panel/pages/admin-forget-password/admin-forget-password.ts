import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, ReactiveFormsModule, Validators, AbstractControl } from '@angular/forms';
import { Button } from '../../../../shared/components/button/button';
import { CommonModule } from '@angular/common';
import { ActivatedRoute, Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { jwtDecode } from 'jwt-decode';
import { ResetPasswordService } from '../../services/reset-password-service/reset-password-service';

@Component({
  selector: 'app-admin-forget-password',
  imports: [ReactiveFormsModule, Button, CommonModule],
  templateUrl: './admin-forget-password.html',
  styleUrl: './admin-forget-password.css',
})
export class AdminForgetPassword implements OnInit {
  loginForm: FormGroup;

  isError = false

  userEmail!: string;
  token!: string;
  msg:string='';
  errorMessage = '';
  isPasswordVisible = false;
  isConfirmPasswordVisible = false;

  passwordPattern = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!_?-]).{8,25}$/


  constructor(private fb: FormBuilder, private router: Router, private activeRoute: ActivatedRoute, private http: HttpClient, private resetPassword: ResetPasswordService) {

    this.loginForm = this.fb.group({
      password: ['', [Validators.required, Validators.minLength(8), Validators.maxLength(25), Validators.pattern(this.passwordPattern)]],
      confirmPassword: ['', [Validators.required, Validators.minLength(8), Validators.maxLength(25)]]
    });
  }

  ngOnInit(): void {
    this.activeRoute.queryParams.subscribe(param => {
      this.token = param['token'];

      if (this.token) {
        const decoded: any = jwtDecode(this.token);

        this.userEmail = decoded["email"]
          || decoded["http://schemas.xmlsoap.org/ws/2005/05/identity/claims/emailaddress"];
      }
    });
  }


  onLogin() {
    if ((this.loginForm.get('password')?.value).length < 8 || (this.loginForm.get('password')?.value).length > 25) {
      this.isError = true;
      this.errorMessage = 'Password Should be between 8 to 25 characters';
    }

    else if (this.loginForm.get('password')?.hasError('pattern')) {
      this.isError = true;
      this.errorMessage = `Password must contain at least:
                          1 lowercase letter
                          1 uppercase letter
                          1 special character
                          1 numeric value`;
    }


    else if (this.loginForm.get('password')?.value != this.loginForm.get('confirmPassword')?.value) {
      this.isError = true;
      this.errorMessage = 'Password and Confirm Password not match';
    }

    else {
      const password = this.loginForm.value.password;

      const payload = {
        token: this.token,
        resetPassword: password
      };

      this.resetPassword.resetPassword(this.token, this.loginForm.get('password')?.value).subscribe({
        next: () => {
            this.router.navigate(['/admin/admin-login'],
              {
                queryParams: { reset: "Success" }
              }
            );
        },
        error: (error) => {
          if(error.error.message === "old password cannot be new password")
          {
            this.msg="SamePassword";
          }
          else
          {
            this.msg="Failed";
          }

          this.router.navigate(['/admin/admin-login'],
            {
              queryParams: { reset: this.msg }
            }
          );
        }
      });
    }
  }

  togglePassword() {
    this.isPasswordVisible = !this.isPasswordVisible;
  }

  toggleConfirmPassword() {
    this.isConfirmPasswordVisible = !this.isConfirmPasswordVisible;
  }
}
