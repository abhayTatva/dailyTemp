
import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators, ReactiveFormsModule } from '@angular/forms';
import { HttpClient } from '@angular/common/http'; // Import this
import { ActivatedRoute, Router, RouterLink } from '@angular/router';

import { CommonModule } from '@angular/common';
import { Button } from '../../../../shared/components/button/button';
import { jwtDecode } from 'jwt-decode';
import { ToastMessage } from '../../../../shared/components/toast-message/toast-message';
import { environment } from '../../../../../environments/environment';
import { AuthService } from '../../../user-panel/services/auth-service/auth-service';

@Component({
  selector: 'app-admin-login',
  standalone: true,

  imports: [CommonModule, ReactiveFormsModule, Button, RouterLink,ToastMessage],

  templateUrl: './admin-login.html',
  styleUrl: './admin-login.css',
})
export class AdminLogin implements OnInit {

  loginForm: FormGroup;
  errorMessage: string = ''; 
  isLoading: boolean = false; 

  isPasswordVisible = false;

  toastMessage: string | null = null;
  toastType: 'success' | 'error' = 'success';
  toastTrigger=0;


  constructor(
    private fb: FormBuilder,
    private router: Router,
    private activatedRoute: ActivatedRoute,
    private http: HttpClient,
    private authService:AuthService
  ) {
    this.loginForm = this.fb.group({
      email: ['', [Validators.required, Validators.email]],
      password: [
        '',
        [Validators.required,Validators.minLength(8),Validators.maxLength(15),
          Validators.pattern(/^(?=.*[A-Za-z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,15}$/)
        ]
      ]
    });
  }

  ngOnInit(): void {
    this.authService.startAutoLogout();

    this.activatedRoute.queryParams.subscribe(params => {
      if (params['reset'] == "SamePassword") 
      {
        this.toastMessage=`New password cannot be old password! 
                            Login with Old password`;
        this.toastType="error";
        this.clearQueryParams();
      }
      
      else if (params['reset'] == "Failed") 
      {
        this.toastMessage="Some error occured! Try again with new link";
        this.toastType="error";
        this.clearQueryParams();
      }

      else if (params['reset'] == 'Success') 
      {
        this.toastMessage="Password updated successfully!";
        this.toastType="success";
        this.clearQueryParams();
      }
    });
  }

  clearQueryParams() {
    this.router.navigate([], {
      relativeTo: this.activatedRoute,
      queryParams: {},
      replaceUrl: true
    });
  }

  onLogin() {
    if (this.loginForm.invalid) {
      for (const field in this.loginForm.controls) {
        const control = this.loginForm.get(field);
  
        if (control && control.invalid) {
          this.errorMessage = `Invalid ${field}`;
          break;
        }
      }
      return;
    }
    this.isLoading = true;
    this.errorMessage = '';

    const loginData = this.loginForm.value;

    // Use your .NET API URL
    this.http.post<any>(`${environment.apiBaseUrl}/Admin/login`, loginData).subscribe({
      next: (response) => {
        // 1. Store the token (SessionStorage is safer for sensitive admin tabs)
        localStorage.setItem('token', response.token);

        this.router.navigate(['/admin/admin-layout']);
        this.isLoading = false;
      },
      error: (err) => {
        this.errorMessage = err.error?.error || 'Login failed. Please try again.';
        this.isLoading = false;
        console.error('Login error', err);
      }
    });
  }


  isInvalid(field: string): boolean {
    const control = this.loginForm.get(field);
    return !!(control && control.touched && control.invalid);
  }



  togglePassword() {
    this.isPasswordVisible = !this.isPasswordVisible;
  }

  cleartoast(){
    this.toastMessage=null;
  }
  
  
  private checkExistingToken() {
    const token = localStorage.getItem('token');

    if (token) {
      try {
        const decoded: any = jwtDecode(token);
        const isTokenExpired = decoded.exp < Date.now() / 1000;

        if (!isTokenExpired) {
          // Token is still valid, skip login form
          this.router.navigate(['/admin/admin-layout']);
        } else {
          // Token expired, clear it and let them log in
          localStorage.removeItem('token');
        }
      } catch (error) {
        // Token is malformed/invalid, clear it
        localStorage.removeItem('token');
      }
    }
    // If no token exists or it was removed above,
    // the user stays on the login page by default.
  }
}