import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AddEditOfferModalComponent } from './add-edit-offer-modal';

describe('AddEditOfferModal', () => {
  let component: AddEditOfferModalComponent;
  let fixture: ComponentFixture<AddEditOfferModalComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [AddEditOfferModalComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AddEditOfferModalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
