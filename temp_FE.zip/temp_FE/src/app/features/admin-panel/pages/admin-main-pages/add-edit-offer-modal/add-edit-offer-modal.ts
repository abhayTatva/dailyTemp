import { Component, EventEmitter, Input, OnChanges, OnInit, Output, SimpleChanges } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { OfferResponseDto } from '../../../../../models/offer.model';
import { ReactiveFormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
@Component({
  selector: 'app-add-edit-offer-modal',
  imports: [
    ReactiveFormsModule,
    CommonModule
  ],
  templateUrl: './add-edit-offer-modal.html',
  styleUrls: ['./add-edit-offer-modal.scss'],
})
export class AddEditOfferModalComponent implements OnInit, OnChanges {

  @Input()  visible   = false;
  @Input()  editOffer: OfferResponseDto | null = null;
  @Output() save      = new EventEmitter<any>();
  @Output() cancel    = new EventEmitter<void>();

  form!: FormGroup;
  isEditMode = false;

  constructor(private fb: FormBuilder) {}

  ngOnInit(): void {
    this.buildForm(); // initialize form on component load
  }

  ngOnChanges(changes: SimpleChanges): void {
    // Runs every time visible or editOffer input changes
    if (changes['visible'] && this.visible) {
      this.isEditMode = !!this.editOffer;
      this.buildForm();
      if (this.isEditMode && this.editOffer) {
        this.patchForm(this.editOffer);
      }
    }
  }

  private buildForm(): void {
    this.form = this.fb.group({
      couponCode:         ['', [Validators.required, Validators.maxLength(50)]],
      couponDescription:  ['', [Validators.maxLength(255)]],
      discountPercentage: [null, [Validators.required, Validators.min(0.01), Validators.max(100)]],
      // isActive only added in edit mode
      ...(this.isEditMode ? { isActive: [true] } : {}),
    });
  }

  private patchForm(offer: OfferResponseDto): void {
    // discountPercentage comes as "10% Off" from API — strip to get raw number
    const rawDiscount = parseFloat(
      offer.discountPercentage.replace('%', '').replace('Off', '').trim()
    );

    this.form.patchValue({
      couponCode:         offer.couponCode,
      couponDescription:  offer.couponDescription ?? '',
      discountPercentage: rawDiscount,
      isActive:           offer.isActive,
    });
  }

  onSave(): void {
    if (this.form.invalid) {
      this.form.markAllAsTouched();
      return;
    }
    this.save.emit(this.form.value);
  }

  onCancel(): void {
    this.cancel.emit();
  }

  hasError(field: string, error: string): boolean {
    const ctrl = this.form?.get(field);
    return !!(ctrl && ctrl.touched && ctrl.errors?.[error]);
  }
}
