import { Component } from '@angular/core';

@Component({
  selector: 'app-admin-booking-management',
  imports: [],
  templateUrl: './admin-booking-management.html',
  styleUrl: './admin-booking-management.css',
})
export class AdminBookingManagement {

}
