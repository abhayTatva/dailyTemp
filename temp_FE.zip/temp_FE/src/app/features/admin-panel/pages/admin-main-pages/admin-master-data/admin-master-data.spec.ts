import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AdminMasterData } from './admin-master-data';

describe('AdminMasterData', () => {
  let component: AdminMasterData;
  let fixture: ComponentFixture<AdminMasterData>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [AdminMasterData]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AdminMasterData);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
