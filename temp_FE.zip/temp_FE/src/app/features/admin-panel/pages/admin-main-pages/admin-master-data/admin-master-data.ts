import { Component, OnInit, ChangeDetectorRef, NgZone, ViewChild, ElementRef } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ServiceType } from '../../../../../Interfaces/ServiceType';
import { ServiceTypes } from '../../../../../services/servicetype';
import { Category } from '../../../../../Interfaces/Category';
import { CategoryService} from '../../../../../services/categoryservice';
import { SubCategoryService, SubCategory } from '../../../../../services/subcategoryservice';
import { Button } from '../../../shared/components/button/button';
import { Modal } from '../../../shared/components/modal/modal';
import { Button2 } from "../../../shared/components/button2/button2";
import { AdminService } from '../../../../../services/adminservice';
import { environment } from '../../../../../../environments/environment';
import { ToastMessage } from '../../../../../shared/components/toast-message/toast-message';
import { PaginationComponent } from '../../../shared/components/pagination/pagination';
import { Modal2 } from "../../../shared/components/modal2/modal2";
declare var bootstrap: any;

@Component({
  selector: 'app-admin-master-data',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, Button, Button2, ToastMessage, PaginationComponent, Modal2],
  templateUrl: './admin-master-data.html',
  styleUrl: './admin-master-data.css'
})
export class AdminMasterData implements OnInit {

  userId!: number;
  baseUrl2 =`${environment.apiBaseUrl2}`;
  serviceForm: FormGroup;
  services: ServiceType[] = [];
  selectedFile: File | null = null;
  imagePreview: string | ArrayBuffer | null = null;
  isEditMode = false;
  currentServiceId: number | null = null;
  isServiceSubmitted = false;
  backendErrorMessage: string = '';
  @ViewChild('fileInput') fileInput!: ElementRef;

  displayedServices: ServiceType[] = [];
  pageSize: number = 10;
  currentPage: number = 1;
  totalItems: number = 0;

   // MANAGE MODAL
   selectedServiceId: number | null = null;
   selectedServiceName: string = '';
 
    categories: Category[] = [];
    categoryForm: FormGroup;
    subCategories: SubCategory[] = [];
    selectedCategoryId: number | null = null;
    subCategoryForm: FormGroup;

    isCategorySubmitted = false;
    isSubCategorySubmitted = false;

    toastMessage:string|null=null;
    toastType:'error'|'success'='success';
    toastTrigger=0;

    showDeleteDialog = false;
    deleteType: 'service' | 'category' | 'subcategory' | null = null;
    deleteId: number | null = null;
    deleteMessage = '';
 
  constructor( private fb: FormBuilder, 
    private serviceTypesService: ServiceTypes, 
    private categoryService: CategoryService,
    private subCategoryService: SubCategoryService,
    private adminService: AdminService) {
    this.serviceForm = this.fb.group({
      name: ['', Validators.required]
    });
    this.categoryForm = this.fb.group({
      name: ['', [Validators.required, Validators.pattern(/\S+/)]]
    });
    
    this.subCategoryForm = this.fb.group({
      name: ['', [Validators.required, Validators.pattern(/\S+/)]]
    });
  }
 
  ngOnInit() {
    const id = this.adminService.getAdminIdFromToken();

    if (!id) {
      console.error('UserId not found in token');
      return;
    }

    this.userId = Number(id);
    
    this.loadServices();
    this.serviceForm.valueChanges.subscribe(() => {
      this.backendErrorMessage = '';
    });
  }
 

  updateDisplayedDataOfPage() {
    const startIndex = (this.currentPage - 1) * this.pageSize;
    const endIndex = startIndex + this.pageSize;
    this.displayedServices = this.services.slice(startIndex, endIndex);
  }


  handlePageChange(event: {page: number, size: number}) {
    this.currentPage = event.page;
    this.pageSize = event.size;
    this.updateDisplayedDataOfPage(); 
  }

  loadServices() {
    this.serviceTypesService.getAll().subscribe({
      next: (res) => {
        this.services = res; 
        this.totalItems = res.length;
        this.updateDisplayedDataOfPage(); 
      },
      error: (err) => console.error('Error loading services', err)
    });
  }

  
  onFileSelected(event: any) {
    const file = event.target.files[0];
    if (file) {
      this.selectedFile = file;
      const reader = new FileReader();
      reader.onload = () => (this.imagePreview = reader.result);
      reader.readAsDataURL(file);
    }
  }
 
  openAddModal() {
    this.isEditMode = false;
    this.currentServiceId = null;
    this.serviceForm.reset();
    this.imagePreview = null;
    this.selectedFile = null;
    this.isServiceSubmitted = false;
    this.backendErrorMessage = '';
    if (this.fileInput) {
      this.fileInput.nativeElement.value = '';
    }
  }

  openEditModal(service: ServiceType) {
    this.isEditMode = true;
    this.currentServiceId = service.id;
    this.serviceForm.patchValue({ name: service.name });
    this.imagePreview = `${this.baseUrl2}/uploads/services/${service.imagePath}`;
    this.selectedFile = null;
    this.isServiceSubmitted = false;
    this.backendErrorMessage = '';
    if (this.fileInput) {
      this.fileInput.nativeElement.value = '';
    }
  }
 

  saveService() {

    this.isServiceSubmitted = true;
    this.backendErrorMessage = '';
  
    if (this.serviceForm.invalid) {
      return;
    }
  
    const name = this.serviceForm.value.name.trim();
    const file = this.selectedFile || undefined;
  
    const request =
      this.isEditMode && this.currentServiceId
        ? this.serviceTypesService.update(this.currentServiceId,this.userId, name, file)
        : this.serviceTypesService.create(name, this.userId, file);
  
    request.subscribe({
      next: () => {
        
        this.showSuccess(
          this.isEditMode ? 'Service updated successfully' : 'Service added successfully'
        );

        this.loadServices();
        this.isServiceSubmitted = false;
        this.backendErrorMessage = '';
  
        const modalElement = document.getElementById('serviceModal');
  
        if (modalElement) {
  
          const modalInstance =
            bootstrap.Modal.getInstance(modalElement) ||
            new bootstrap.Modal(modalElement);
  
          modalInstance.hide();
        }
  
        this.serviceForm.reset();
        this.imagePreview = null;
        this.selectedFile = null;
  
      },
  
      error: (err) => this.handleError(err)
  
    });
  
  }

  
  // man-part

  handleError(err: any) {

    if (err.error?.errors?.Name) {
      this.backendErrorMessage = err.error.errors.Name[0];
    }
    else if (err.error?.error) {
      this.backendErrorMessage = err.error.error;
    }
    else {
      this.backendErrorMessage = 'Something went wrong. Please try again.';
    }
  
  }

  
  openManageModal(service: ServiceType) {
    this.selectedServiceId = service.id;
    this.selectedServiceName = service.name;

    this.selectedCategoryId = null; 
    this.subCategories = []; 
    
    this.loadCategories(service.id);
}

  openAddCategoryModal() {
    this.isCategorySubmitted = false;
    this.categoryForm.reset(); 
    const modalElement = document.getElementById('addCategoryModal');
    this.backendErrorMessage = '';
    
    if (modalElement) {
     
      const modal = bootstrap.Modal.getOrCreateInstance(modalElement, {
        backdrop: true, 
        keyboard: true  
      });
      modal.show();
    }
  }

  openAddSubCategoryModal() {
    if (!this.selectedCategoryId) {
      this.toastMessage='Please select category first';
      this.toastType='error';
      this.toastTrigger++; 
      return;
    }
    this.backendErrorMessage = '';
    this.isSubCategorySubmitted = false;
    this.subCategoryForm.reset(); 
    const modalElement = document.getElementById('addSubCategoryModal');
    
    if (modalElement) {
      const modal = bootstrap.Modal.getOrCreateInstance(modalElement, {
        backdrop: true,
        keyboard: true
      });
      modal.show();
    }
  }

closeModal(modalId: string) {
  const modalElement = document.getElementById(modalId);
  if (modalElement) {
    const modalInstance = bootstrap.Modal.getInstance(modalElement);
    if (modalInstance) {
      modalInstance.hide();
    }
  }
}


loadCategories(serviceId: number) {
  this.categoryService.getByService(serviceId).subscribe(res => {
    this.categories = res;
  });
}

loadSubCategories(categoryId: number) {
  this.selectedCategoryId = categoryId;

  this.subCategoryService.getByCategory(categoryId).subscribe(res => {
    this.subCategories = res;
  });
}

saveCategory() {
  this.isCategorySubmitted = true;

  this.categoryForm.markAllAsTouched();
  this.categoryForm.updateValueAndValidity();

  if (this.categoryForm.invalid || !this.selectedServiceId) {
    return;
  }

  const request = {
    name: this.categoryForm.value.name.trim(),
    serviceTypeId: this.selectedServiceId,
    UserId: this.userId
  };

  this.categoryService.create(request).subscribe({
    next: () => {

      this.showSuccess('Category added successfully');

      this.categoryForm.reset();
      this.isCategorySubmitted = false;

      this.loadCategories(this.selectedServiceId!);

      const modalElement = document.getElementById('addCategoryModal');
      if (modalElement) {
        const modal = bootstrap.Modal.getOrCreateInstance(modalElement);
        modal.hide();
      }
    },
  
    error: (err) => this.handleError(err)
  });
}

saveSubCategory() {
  this.isSubCategorySubmitted = true;

  this.subCategoryForm.markAllAsTouched();
  this.subCategoryForm.updateValueAndValidity();

  if (this.subCategoryForm.invalid || !this.selectedCategoryId) {
    return; 
  }

  const request = {
    name: this.subCategoryForm.value.name.trim(),
    categoryId: this.selectedCategoryId,
    UserId:this.userId
  };

  this.subCategoryService.create(request).subscribe({
    next: () => {

      this.showSuccess('Sub-Category added successfully');

      this.subCategoryForm.reset();
      this.isSubCategorySubmitted = false;

      this.loadSubCategories(this.selectedCategoryId!);

      const modalElement = document.getElementById('addSubCategoryModal');
      if (modalElement) {
        const modal = bootstrap.Modal.getOrCreateInstance(modalElement);
        modal.hide();
      }
    },
    error: (err) => this.handleError(err)
  });
}

  showSuccess(message: string) {
    this.toastMessage = message;
    this.toastType = 'success';
    this.toastTrigger++;
  }

  openDeleteDialog(type: 'service' | 'category' | 'subcategory', id: number) {

    this.deleteType = type;
    this.deleteId = id;
  
    if (type === 'service') {
      this.deleteMessage = 'Are you sure you want to delete this service?';
    }
  
    if (type === 'category') {
      this.deleteMessage = 'Are you sure you want to delete this category?';
    }
  
    if (type === 'subcategory') {
      this.deleteMessage = 'Are you sure you want to delete this sub category?';
    }
  
    this.showDeleteDialog = true;
  }

  cancelDelete() {
    this.showDeleteDialog = false;
    this.deleteId = null;
    this.deleteType = null;
  }

  confirmDelete() {

    if (!this.deleteType || !this.deleteId) return;
  
    if (this.deleteType === 'category') {
  
      this.categoryService.delete(this.deleteId).subscribe(() => {
  
        this.categories = this.categories.filter(c => c.id !== this.deleteId);
  
        this.subCategories = [];

        this.showSuccess('Category deleted successfully');
  
        this.cancelDelete();
  
      });
  
    }
  
    if (this.deleteType === 'subcategory') {
  
      this.subCategoryService.delete(this.deleteId).subscribe(() => {
  
        this.subCategories = this.subCategories.filter(
          sc => sc.id !== this.deleteId
        );

        this.showSuccess('Sub-Category deleted successfully');
  
        this.cancelDelete();
  
      });
  
    }
  
    if (this.deleteType === 'service') {
  
      this.serviceTypesService.delete(this.deleteId)
        .subscribe(() => {
  
          this.loadServices();

          this.showSuccess('Service deleted successfully');
  
          this.cancelDelete();
  
        });
    }
  }
}