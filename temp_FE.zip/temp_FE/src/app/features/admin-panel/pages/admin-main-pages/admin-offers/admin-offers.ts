import { Component, OnInit, HostListener, OnDestroy } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { MatSelectChange, MatSelectModule } from '@angular/material/select';
import { MatSliderModule } from '@angular/material/slider';
import {
  OfferResponseDto,
  OfferFilterDto,
  PagedResult,
  CreateOfferRequestDto,
  UpdateOfferRequestDto,
} from '../../../../../models/offer.model';
import { ToastMessage } from '../../../../../shared/components/toast-message/toast-message';
import { OfferService } from '../../../../../services/offer.service';
import { AddEditOfferModalComponent } from '../add-edit-offer-modal/add-edit-offer-modal';
import { CommonModule } from '@angular/common';
import { OverlayContainer } from '@angular/cdk/overlay';
import { PaginationComponent } from '../../../shared/components/pagination/pagination';
@Component({
  selector: 'app-admin-offers',
  imports: [FormsModule, AddEditOfferModalComponent, CommonModule, MatSliderModule, ToastMessage,PaginationComponent],
  templateUrl: './admin-offers.html',
  styleUrl: './admin-offers.scss',
})
export class AdminOffers implements OnInit , OnDestroy{
  //Toast
  toastMessage: string | null = null;
  toastType: 'success' | 'error' = 'success';
  toastTrigger = 0;
  // Grid
  offers: OfferResponseDto[] = [];
  totalRecords = 0;
  totalPages = 0;
  isLoading = false;

  // Filter
  showFilterPanel = false;
  filterMinDiscount: number | null = null;
  filterMaxDiscount: number | null = null;
  filterMinCouponApplied: number  = 0;
  filterMaxCouponApplied: number  = 100000;
  filterIsActive: boolean | null = null;

  // Pagination
  currentPage = 1;
  pageSize = 10;

  // Sorting
  sortBy = 'createdOn';
  sortDirection = 'desc';

  openDropdownId: number | null = null;
  // Modal
  showModal = false;
  selectedOffer: OfferResponseDto | null = null;
  // Delete
  showDeleteConfirm = false;
  deleteTargetId: number | null = null;

  constructor(
    private offerService: OfferService,
    private overlayContainer: OverlayContainer
  ) { }

  ngOnInit(): void {
    this.loadOffers();
  }

  ngOnDestroy() {
    const backdrops = document.querySelectorAll('.modal-backdrop');
    backdrops.forEach(b => b.remove());
  
    document.body.classList.remove('modal-open');
  }
  // ── Load ──────────────────────────────────────────────────────────────────
  loadOffers(): void {
    this.isLoading = true;
    const filter: OfferFilterDto = {
      page: this.currentPage,
      pageSize: this.pageSize,
      sortBy: this.sortBy,
      sortDirection: this.sortDirection,
      minDiscount: this.filterMinDiscount,
      maxDiscount: this.filterMaxDiscount,
      minTimeCouponApplied: this.filterMinCouponApplied,
      maxTimeCouponApplied: this.filterMaxCouponApplied,
      isActive: this.filterIsActive,
    };

    this.offerService.getAll(filter).subscribe({
      next: (result: PagedResult<OfferResponseDto>) => {
        this.offers = result.data;
        this.totalRecords = result.totalRecords;
        this.totalPages = result.totalPages;
        this.isLoading = false;
      },
      error: () => { this.isLoading = false; },
    });
  }

  // ── Sort ──────────────────────────────────────────────────────────────────
  onSort(column: string): void {
    if (this.sortBy === column) {
      this.sortDirection = this.sortDirection === 'asc' ? 'desc' : 'asc';
    } else {
      this.sortBy = column;
      this.sortDirection = 'asc';
    }
    this.currentPage = 1;
    this.loadOffers();
  }

  getSortIcon(column: string): string {
    if (this.sortBy !== column) return '↕';
    return this.sortDirection === 'asc' ? '↑' : '↓';
  }

  // ── Pagination ────────────────────────────────────────────────────────────
  onPageChange(event: { page: number; size: number }) {

    const { page, size } = event;
  
    this.currentPage = page;
    this.pageSize = size;
  
    this.loadOffers();
  }

  get pages(): number[] {
    const visiblePages = 3;

    return Array.from({ length: this.totalPages }, (_, i) => i + 1)
      .slice(this.currentPage - 1, this.currentPage - 1 + visiblePages);
  }

  get startRecord(): number {
    return this.totalRecords === 0 ? 0 : (this.currentPage - 1) * this.pageSize + 1;
  }

  get endRecord(): number {
    return Math.min(this.currentPage * this.pageSize, this.totalRecords);
  }

  // ── Filter ────────────────────────────────────────────────────────────────
  toggleFilter(): void { this.showFilterPanel = !this.showFilterPanel; }

  applyFilter(): void {
    this.currentPage = 1;
    this.showFilterPanel = false;
    this.loadOffers();
  }

  cancelFilter(): void {
    this.filterMinDiscount = null;
    this.filterMaxDiscount = null;
    this.filterIsActive = null;
    this.showFilterPanel = false;
    this.currentPage = 1;
    this.filterMinCouponApplied = 0;
    this.filterMaxCouponApplied = 100000;
    this.loadOffers();
  }

  // ── Add ───────────────────────────────────────────────────────────────────
  openAddModal(): void {
    this.selectedOffer = null; // null = Add mode
    this.showModal = true;
  }

  // ── Edit (FIXED — no extra API call, use row data directly) ───────────────
  openEditModal(offer: OfferResponseDto): void {
    this.selectedOffer = offer;
    this.showModal = true;
  }

  // ── Delete ────────────────────────────────────────────────────────────────
  confirmDelete(id: number): void {
    this.deleteTargetId = id;
    this.showDeleteConfirm = true;
  }

  onDeleteConfirmed(): void {
    if (!this.deleteTargetId) return;
    this.offerService.delete(this.deleteTargetId).subscribe({
      next: () => {
        this.toastMessage = `offer delete successfully`;
        this.toastType = 'success';
        this.toastTrigger++;
        this.showDeleteConfirm = false;
        this.deleteTargetId = null;
        this.loadOffers();
      },
    });
  }

  onDeleteCancelled(): void {
    this.showDeleteConfirm = false;
    this.deleteTargetId = null;
  }

  // ── Modal Save ────────────────────────────────────────────────────────────
  onModalSave(formValue: any): void {
    if (this.selectedOffer) {
      // Edit
      const dto: UpdateOfferRequestDto = {
        couponCode: formValue.couponCode,
        couponDescription: formValue.couponDescription,
        discountPercentage: formValue.discountPercentage,
        isActive: formValue.isActive,
      };
      this.offerService.update(this.selectedOffer.id, dto).subscribe({
        next: () => { this.showModal = false; this.loadOffers(); },
      });
    } else {
      // Add
      const dto: CreateOfferRequestDto = {
        couponCode: formValue.couponCode,
        couponDescription: formValue.couponDescription,
        discountPercentage: formValue.discountPercentage,
      };
      this.offerService.create(dto).subscribe({
        next: () => {
          this.toastMessage = `${dto.couponCode} offer Created successfully`;
          this.toastType = 'success';
          this.toastTrigger++;
          this.showModal = false;
          this.loadOffers();
        },
      });
    }
  }

  onModalCancel(): void {
    this.showModal = false;
    this.selectedOffer = null;
  }

  // 1. property


  // 2. methods
  toggleDropdown(id: number): void {
    this.openDropdownId = this.openDropdownId === id ? null : id;
  }
  closeDropdown(): void {
    this.openDropdownId = null;
  }

  onPageSizeChange(event: MatSelectChange) {
    this.currentPage = 1;
    this.pageSize = +event.value;
    this.loadOffers();
  }

  // 3. close on outside click
  @HostListener('document:click', ['$event'])
  onClickOutside(e: MouseEvent): void {
    if (!(e.target as HTMLElement).closest('.action-dropdown')) {
      this.openDropdownId = null;
    }
  }
}
