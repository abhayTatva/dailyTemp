import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AdminPaymentTransaction } from './admin-payment-transaction';

describe('AdminPaymentTransaction', () => {
  let component: AdminPaymentTransaction;
  let fixture: ComponentFixture<AdminPaymentTransaction>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [AdminPaymentTransaction]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AdminPaymentTransaction);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
