import { Component } from '@angular/core';

@Component({
  selector: 'app-admin-payment-transaction',
  imports: [],
  templateUrl: './admin-payment-transaction.html',
  styleUrl: './admin-payment-transaction.css',
})
export class AdminPaymentTransaction {

}
