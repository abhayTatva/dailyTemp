import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormBuilder, Validators,FormGroup } from '@angular/forms';
import { Button2 } from '../../../shared/components/button2/button2';
import { AdminService } from '../../../../../services/adminservice';
import { ToastMessage } from '../../../../../shared/components/toast-message/toast-message';
import { environment } from '../../../../../../environments/environment';

@Component({
  selector: 'app-profile',
  standalone: true,
  imports: [
    CommonModule,
    ReactiveFormsModule,
    Button2,
    ToastMessage
  ],
  templateUrl: './admin-profile.html',
  styleUrls: ['./admin-profile.css']
})
export class AdminProfile implements OnInit {

  profile: {
    name?: string;
    email?: string;
    mobileNumber?: string;
    address?: string;
    imagePath?: string;
  } = {};

  adminId!: number;

  contactForm!: FormGroup;
  passwordForm!: FormGroup;

  baseUrl = environment.mediaBaseUrl;

  // Password visibility toggle
  showCurrent = false;
  showNew = false;
  showConfirm = false;

  toastMessage:string|null=null;
  toastType:'error'|'success'='success';
  toastTrigger=0;

  constructor(
    private fb: FormBuilder,
    private adminService: AdminService,
  ) {

    // Contact form
    this.contactForm = this.fb.group({
      email: [
        '',
        [
          Validators.required,
          Validators.pattern(/^[^\s@]+@[^\s@]+\.[^\s@]+$/)
        ]
      ],
      mobileNumber: [
        '',
        [
          Validators.required,
          Validators.pattern(/^[0-9]{10}$/)
        ]
      ],

      address: [
        '',
        [
          Validators.required,
          Validators.minLength(5),
          Validators.maxLength(200)
        ]
      ]
    });

    // Password form
    this.passwordForm = this.fb.group({
      currentPassword: ['', Validators.required],

      newPassword: [
        '',
        [
          Validators.required,
          Validators.minLength(8),
          Validators.maxLength(15),
          Validators.pattern(/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[\W_]).+$/)
        ]
      ],
      
      confirmPassword: ['', Validators.required]
    });
  }

  ngOnInit(): void {

    const id = this.adminService.getAdminIdFromToken();

    if (!id) {
      console.error('UserId not found in token');
      return;
    }

    this.adminId = id;

    this.loadAdmin();
  }


  loadAdmin() {

    this.adminService.getAdminById(this.adminId)
      .subscribe({
        next: (res) => {

          console.log("API RESPONSE:", res);

          this.profile = {
            name: res.name,
            email: res.email,
            mobileNumber: res.mobileNumber,
            address: res.address,
            imagePath: res.imagePath
          };

          this.adminService.setAdminProfile(this.profile);

          this.contactForm.patchValue({
            email: res.email,
            mobileNumber: res.mobileNumber,
            address: res.address
          });

        },
        error: (err) => {
          console.error('Error loading admin:', err);
        }
      });
  }

 
  // PROFILE IMAGE UPDATE
  onPhotoSelected(event: any) {

    const file = event.target.files[0];

    if (!file) return;

    const formData = new FormData();

    formData.append('AdminId', this.adminId.toString());
    formData.append('Name', this.profile.name || '');
    formData.append('profileImage', file);

    this.adminService.updateBasicInfo(formData)
      .subscribe({
        next: () => {
          this.loadAdmin();
          this.toastMessage='Profile pic updated successfully';
          this.toastType='success';
          this.toastTrigger++;
        },
        error: (err) => {
          console.error('Image update failed:', err);
        }
      });
  }

 
  // CONTACT INFO UPDATE

  numbersOnly(event: any) {
    event.target.value = event.target.value.replace(/[^0-9]/g, '');
  }
  
  saveContactInfo(dialog: HTMLDialogElement) {

    if (this.contactForm.invalid) {
      this.contactForm.markAllAsTouched();
      return;
    }

    const updatedData = {
      adminId: this.adminId,
      email: this.contactForm.value.email,
      mobileNumber: this.contactForm.value.mobileNumber,
      address: this.contactForm.value.address
    };

    this.adminService.updateContactInfo(updatedData)
      .subscribe({
        next: () => {

          this.loadAdmin();

          this.contactForm.reset({
            email: updatedData.email,
            mobileNumber: updatedData.mobileNumber,
            address: updatedData.address
          });

          dialog.close();
          this.toastMessage='Information Updated Successfully';
          this.toastType='success';
          this.toastTrigger++;
        },
        error: (err) => {
          console.error('Update failed:', err);
        }
      });
  }

  
  // CHANGE PASSWORD

  changePassword(dialog: HTMLDialogElement) {

    if (this.passwordForm.invalid) {
      this.passwordForm.markAllAsTouched();
      return;
    }

    const { currentPassword, newPassword, confirmPassword } = this.passwordForm.value;

    if (currentPassword === newPassword) {

      this.toastMessage='Current Password cannot be same as New Password';
      this.toastType='error';
      this.toastTrigger++;

      this.passwordForm.reset();
      dialog.close();
      return;
    }

    // Password match validation
    if (newPassword !== confirmPassword) {
      this.passwordForm.get('confirmPassword')
      ?.setErrors({ mismatch: true });
      return;
    }

    const passwordData = {
      adminId: this.adminId,
      currentPassword: currentPassword,
      newPassword: newPassword
    };

    this.adminService.changePassword(passwordData)
      .subscribe({
        next: () => {

          this.toastMessage='Password Updated Successfully';
          this.toastType='success';
          this.toastTrigger++;

          this.passwordForm.reset();

          dialog.close();
        },
        error: (err) => {
          console.log("Password error:", err);

          if (err.status === 400) {

            this.passwordForm.get('currentPassword')
              ?.setErrors({ incorrectPassword: true });

            this.passwordForm.get('currentPassword')
              ?.markAsTouched();

          }
        }
      });

  }

  // DIALOG FUNCTIONS

  openDialog(dialog: HTMLDialogElement) {
    dialog.showModal();
  }


  closeContactDialog(dialog: HTMLDialogElement) {
    dialog.close();

    this.contactForm.reset({
      email: this.profile.email,
      mobileNumber: this.profile.mobileNumber,
      address: this.profile.address
    });

    this.contactForm.markAsPristine();
    this.contactForm.markAsUntouched();

    Object.keys(this.contactForm.controls).forEach(key => {
      this.contactForm.get(key)?.setErrors(null);
    });
  }

  closeDialog(dialog: HTMLDialogElement) {
    dialog.close();

    this.passwordForm.reset();

    this.passwordForm.markAsPristine();
    this.passwordForm.markAsUntouched();

    this.passwordForm.get('currentPassword')?.setErrors(null);
    this.passwordForm.get('confirmPassword')?.setErrors(null);
  }

}