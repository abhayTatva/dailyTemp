import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AdminServiceDetails } from './admin-service-details';

describe('AdminServiceDetails', () => {
  let component: AdminServiceDetails;
  let fixture: ComponentFixture<AdminServiceDetails>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [AdminServiceDetails]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AdminServiceDetails);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
