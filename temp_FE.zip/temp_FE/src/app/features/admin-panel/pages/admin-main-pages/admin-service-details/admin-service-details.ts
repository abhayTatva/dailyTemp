import { Component, OnInit , ChangeDetectorRef, NgZone } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ActivatedRoute, Router } from '@angular/router';
import { FormArray, FormBuilder, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { ParticularService } from '../../../../../services/particularservice';
import { SubCategoryService } from '../../../../../services/subcategoryservice';
import { ServiceDetail } from '../../../../../Interfaces/ServiceDetail';
import { SubCategory } from '../../../../../Interfaces/SubCategory';
import { environment } from '../../../../../../environments/environment';
import { Switch } from '../../../shared/components/switch/switch';
import { Modal } from '../../../shared/components/modal/modal';

declare var bootstrap: any;

@Component({
  selector: 'app-admin-service-details',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, Switch, Modal],
  templateUrl: './admin-service-details.html',
  styleUrl: './admin-service-details.css',
})
export class AdminServiceDetails implements OnInit {

  serviceId!: number;
  selectedService!: ServiceDetail;
  isLoading = false;
  errorMessage = '';
  baseUrl = environment.mediaBaseUrl;
  baseUrl2 = environment.apiBaseUrl2;

  // ── Edit form ──────────────────────────────────────────────────────────────
  editForm!: FormGroup;
  subCategories: SubCategory[] = [];
  imagePreviews: string[] = [];
  existingImages: { fileName: string; url: string }[] = [];
  isEditSubmitted = false;
  duplicateNameError = '';

  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private fb: FormBuilder,
    private particularService: ParticularService,
    private subCategoryService: SubCategoryService,
    private cdr: ChangeDetectorRef,
    private ngZone: NgZone,
  ) {}

  ngOnInit(): void {
    this.serviceId = Number(this.route.snapshot.paramMap.get('id'));
    this.initEditForm();
    this.loadServiceDetail();
  }

  // ── Form ───────────────────────────────────────────────────────────────────
  private initEditForm() {
    this.editForm = this.fb.group({
      name: ['', [Validators.required, Validators.maxLength(100)]],
      subCategoryId: ['', Validators.required],
      durationMin: [null, [Validators.required, Validators.min(1)]],
      price: [null, [Validators.required, Validators.min(1)]],
      commissionPct: [null, [Validators.required, Validators.min(1), Validators.max(100)]],
      isAvailable: [true],
      includesEnabled: [false],
      excludesEnabled: [false],
      includes: this.fb.array([]),
      excludes: this.fb.array([]),
      images: this.fb.array([]),
    });
  }

  // ── FormArray Getters ──────────────────────────────────────────────────────
  get images(): FormArray { return this.editForm.get('images') as FormArray; }
  get includes(): FormArray { return this.editForm.get('includes') as FormArray; }
  get excludes(): FormArray { return this.editForm.get('excludes') as FormArray; }

  // ── Load detail ────────────────────────────────────────────────────────────
  loadServiceDetail(): void {
    this.isLoading = true;
    this.errorMessage = '';

    this.particularService.getServiceDetail(this.serviceId).subscribe({
      next: (data: ServiceDetail) => {
        this.selectedService = data;
        this.isLoading = false;
      },
      error: (err: any) => {
        this.isLoading = false;
        if (err.status === 404) {
          this.router.navigate(['/admin/admin-layout/service-management']);
        } else {
          this.errorMessage = 'Failed to load service details. Please try again.';
        }
      }
    });
  }

  // ── Open edit modal ────────────────────────────────────────────────────────
  onEditClick(): void {
    this.isEditSubmitted = false;
    this.duplicateNameError = '';
    this.imagePreviews = [];
    this.existingImages = [];
    this.includes.clear();
    this.excludes.clear();
    this.images.clear();

    const detail = this.selectedService;

    // Load subcategories for dropdown
    this.subCategoryService.getByCategory(detail.categoryId).subscribe((res) => {
      this.subCategories = res;

      // Patch form after subcategories loaded so dropdown preselects correctly
      this.editForm.patchValue({
        name: detail.name,
        subCategoryId: detail.subCategoryId,
        durationMin: this.parseDuration(detail.duration),
        price: detail.price,
        commissionPct: detail.commissionPct,
        isAvailable: detail.availability === 'Available',
        includesEnabled: (detail.includes?.length ?? 0) > 0,
        excludesEnabled: (detail.excludes?.length ?? 0) > 0,
      });

      this.existingImages = detail.images.map((path) => ({
        fileName: path.split('/').pop()!,
        url: `${this.baseUrl}/${path}`,
      }));

      detail.includes?.forEach((item) => this.includes.push(this.fb.control(item)));
      detail.excludes?.forEach((item) => this.excludes.push(this.fb.control(item)));

      // Open modal
      const el = document.getElementById('editServiceModal');
      if (el) bootstrap.Modal.getOrCreateInstance(el).show();
    });
  }

  // ── Submit edit ────────────────────────────────────────────────────────────
  submitEdit(): void {
    this.isEditSubmitted = true;
    this.duplicateNameError = '';
    this.editForm.markAllAsTouched();
    if (this.editForm.invalid) return;

    const formValue = this.editForm.value;
    const formData = new FormData();

    formData.append('name', formValue.name);
    formData.append('subCategoryId', formValue.subCategoryId);
    formData.append('durationMin', formValue.durationMin.toString());
    formData.append('price', formValue.price);
    formData.append('commissionPct', formValue.commissionPct.toString());
    formData.append('isAvailable', formValue.isAvailable);

    this.includes.controls.forEach((c: any) => formData.append('includes', c.value));
    this.excludes.controls.forEach((c: any) => formData.append('excludes', c.value));
    this.existingImages.forEach((img) => formData.append('retainedImageNames', img.fileName));
    this.images.controls.forEach((c: any) => formData.append('newImages', c.value));

    this.particularService.updateService(this.serviceId, formData).subscribe({
      next: () => {
        const el = document.getElementById('editServiceModal');
        if (el) bootstrap.Modal.getOrCreateInstance(el).hide();
        this.loadServiceDetail(); // refresh detail view
      },
      error: (err: any) => console.error('Update failed ❌', err),
    });
  }

  // ── Image handling ─────────────────────────────────────────────────────────
  onImageSelect(event: any) {
    const files: FileList = event.target.files;
    if (!files || files.length === 0) return;
    for (let i = 0; i < files.length; i++) {
      const file = files[i];
      this.images.push(this.fb.control(file));
      const reader = new FileReader();
      reader.onload = (e: any) => {
        this.ngZone.run(() => {
          this.imagePreviews.push(e.target.result);
          this.cdr.detectChanges();
        });
      };
      reader.readAsDataURL(file);
    }
    event.target.value = '';
  }

  removeImage(index: number) {
    this.images.removeAt(index);
    this.imagePreviews.splice(index, 1);
  }

  removeExistingImage(index: number) {
    this.existingImages.splice(index, 1);
  }

  // ── Includes / Excludes ────────────────────────────────────────────────────
  addIncludeFromInput(value: string) {
    const text = value?.trim();
    if (!text || text.length > 100) return;
    const exists = this.includes.controls.some(c => c.value === text);
    if (!exists) {
      this.includes.push(this.fb.control(text, [Validators.maxLength(100)]));
    }
  }
  
  addExcludeFromInput(value: string) {
    const text = value?.trim();
    if (!text || text.length > 100) return;
    const exists = this.excludes.controls.some(c => c.value === text);
    if (!exists) {
      this.excludes.push(this.fb.control(text, [Validators.maxLength(100)]));
    }
  }

  removeInclude(index: number) { this.includes.removeAt(index); }
  removeExclude(index: number) { this.excludes.removeAt(index); }

  // ── Helpers ────────────────────────────────────────────────────────────────
  parseDuration(duration: string): number {
    let total = 0;
    const hrMatch = duration.match(/(\d+)\s*hr/);
    const minMatch = duration.match(/(\d+)\s*min/);
    if (hrMatch) total += parseInt(hrMatch[1]) * 60;
    if (minMatch) total += parseInt(minMatch[1]);
    return total;
  }

  getImageUrl(imagePath: string): string {
    return `${this.baseUrl}/${imagePath}`;
  }

  goBack(): void {
    this.router.navigate(['/admin/admin-layout/service-management']);
  }
}