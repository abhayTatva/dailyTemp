import { Component, OnInit, ChangeDetectorRef, NgZone, ViewChild, ElementRef } from '@angular/core';
import { Button } from '../../../shared/components/button/button';
import {
  FormArray,
  FormsModule,
  FormBuilder,
  FormGroup,
  Validators,
  ReactiveFormsModule,
} from '@angular/forms';
import { CommonModule } from '@angular/common';
import { Button2 } from '../../../shared/components/button2/button2';
import { Switch } from '../../../shared/components/switch/switch';
import { Modal } from '../../../shared/components/modal/modal';
import { NgxSliderModule, Options } from '@angular-slider/ngx-slider';
import { RouterModule, Router, ActivatedRoute } from '@angular/router';

import { ServiceType } from '../../../../../Interfaces/ServiceType';
import { Category } from '../../../../../Interfaces/Category';
import { Service } from '../../../../../Interfaces/Service';
import { SubCategory } from '../../../../../Interfaces/SubCategory.js';
import { ParticularService } from '../../../../../services/particularservice';
import { ServiceTypes } from '../../../../../services/servicetype';
import { CategoryService } from '../../../../../services/categoryservice';
import { SubCategoryService } from '../../../../../services/subcategoryservice';
import { AdminService } from '../../../../../services/adminservice';
import { environment } from '../../../../../../environments/environment';
import { ToastMessage } from '../../../../../shared/components/toast-message/toast-message';
declare var bootstrap: any;

@Component({
  selector: 'app-admin-service-management',
  standalone: true,
  imports: [
    Button,
    FormsModule,
    CommonModule,
    Button2,
    Switch,
    Modal,
    NgxSliderModule,
    ReactiveFormsModule,
    RouterModule,
    ToastMessage
  ],
  templateUrl: './admin-service-management.html',
  styleUrl: './admin-service-management.css',
})
export class AdminServiceManagement implements OnInit {
  // ── State ──────────────────────────────────────────────────────────────────
  userId!: number;
  baseUrl2 = environment.apiBaseUrl2;

  serviceTypes: ServiceType[] = [];
  categories: Category[] = [];
  subCategories: SubCategory[] = []; // used in add/edit form dropdown + filter
  manageSubCategories: SubCategory[] = []; // used in manage modal only
  service: Service[] = [];
  private allServices: Service[] = [];

  selectedServiceId: number | null = null;
  selectedCategoryId: number | null = null;
  selectedCategory: any | null = null;
  currentServiceType: ServiceType | null = null; // tracks current open accordion service

  // ── Manage Modal state ─────────────────────────────────────────────────────
  selectedServiceName: string = '';
  isCategorySubmitted = false;
  isSubCategorySubmitted = false;
  categoryBackendError: string = '';
  subCategoryBackendError: string = '';
  isCleaningSubmitted = false;
  duplicateNameError = '';

  // ── Forms ──────────────────────────────────────────────────────────────────
  serviceForm: FormGroup = new FormGroup({});
  categoryForm!: FormGroup;
  subCategoryForm!: FormGroup;
  cleaningForm!: FormGroup;

  // ── Image state ────────────────────────────────────────────────────────────
  imagePreviews: string[] = [];
  existingImages: { fileName: string; url: string }[] = [];
  removedImageNames: string[] = [];

  // ── Edit mode ──────────────────────────────────────────────────────────────
  isEditMode = false;
  editingServiceId: number | null = null;

  // ── Slider ─────────────────────────────────────────────────────────────────
  minValue = 0;
  maxValue = 99999;
  options: Options = {
    floor: 0,
    ceil: 99999,
    step: 0.5,
    translate: (value: number): string => '₹' + value,
  };

  // ── Filter state ───────────────────────────────────────────────────────────
  filterSubCategoryId: number | null = null;
  filterAvailability: string = '';
  filterMinPrice: number = 0;
  filterMaxPrice: number = 99999;
  filterMinCommission: number = 0;
  filterMaxCommission: number = 100;

  //toast msg
  toastMessage:string|null=null;
    toastType:'error'|'success'='success';
    toastTrigger=0;

    showDeleteDialog = false;
    deleteType: 'service' | 'category' | 'subcategory' | null = null;
    deleteId: number | null = null;
    deleteMessage = '';
 

  @ViewChild('cleaningFormRef') cleaningFormRef!: ElementRef<HTMLFormElement>;

  constructor(
    private fb: FormBuilder,
    private particularService: ParticularService,
    private serviceTypeService: ServiceTypes,
    private adminService: AdminService,
    private subCategoryService: SubCategoryService,
    private categoryService: CategoryService,
    private cdr: ChangeDetectorRef,
    private ngZone: NgZone,
    private router: Router,
    private route: ActivatedRoute
  ) {}

  // ── Lifecycle ──────────────────────────────────────────────────────────────
  ngOnInit() {
    const id = this.adminService.getAdminIdFromToken();
    if (!id) {
      console.error('UserId not found in token');
      return;
    }
    this.userId = Number(id);

    this.serviceForm = this.fb.group({ name: [''] });
    this.categoryForm = this.fb.group({
      name: ['', [Validators.required, Validators.pattern(/\S+/)]],
    });
    this.subCategoryForm = this.fb.group({
      name: ['', [Validators.required, Validators.pattern(/\S+/)]],
    });

    this.initCleaningForm();
    this.loadServices();
  }

  // ── Form Initialization ────────────────────────────────────────────────────
  private initCleaningForm() {
    this.cleaningForm = this.fb.group({
      name: ['', [Validators.required, Validators.maxLength(100)]],
      subCategoryId: ['', Validators.required],
      durationMin: [null, [Validators.required, Validators.min(1)]],
      price: [null, [Validators.required, Validators.min(1)]],
      commissionPct: [null, [Validators.required, Validators.min(1), Validators.max(100)]],
      isAvailable: [true],
      includesEnabled: [false],
      excludesEnabled: [false],
      includes: this.fb.array([]),
      excludes: this.fb.array([]),
      images: this.fb.array([]),
    });
  }

  // ── FormArray Getters ──────────────────────────────────────────────────────
  get images(): FormArray {
    return this.cleaningForm.get('images') as FormArray;
  }
  get includes(): FormArray {
    return this.cleaningForm.get('includes') as FormArray;
  }
  get excludes(): FormArray {
    return this.cleaningForm.get('excludes') as FormArray;
  }

  // ── Service Type ───────────────────────────────────────────────────────────
  loadServices() {
    this.serviceTypeService.getAll().subscribe({
      next: (res) => {
        this.serviceTypes = res;
      },
      error: (err) => console.error('Error loading services:', err),
    });
  }

  onServiceType() {
    console.log('Add button clicked');
  }

  addService() {
    if (this.serviceForm.invalid) return;
    const name = this.serviceForm.value.name;
    this.serviceTypeService.create(name, this.userId).subscribe({
      next: () => {
        this.loadServices();
        this.serviceForm.reset();
        this.showSuccess('Service type added successfully');
      },
      error: (err) => {console.error('Error adding service type ', err)
        let errorMessage = 'Failed to add service type';
      if (err.error?.message) {
        errorMessage = err.error.message;
      } else if (typeof err.error === 'string') {
        errorMessage = err.error;
      }

      // Show error toast
      this.showError(errorMessage);
      },
    });
  }

  selectService(service: ServiceType) {
    this.selectedServiceId = service.id;
    this.currentServiceType = service; //  track for manage modal
    this.selectedCategory = null;
    this.subCategories = [];
    this.service = [];
    this.allServices = [];

    this.categoryService.getByService(service.id).subscribe({
      next: (res) => (this.categories = res),
      error: (err) => console.error(err),
    });
  }

  selectCategory(category: Category) {
    this.selectedCategory = category;
    this.selectedCategoryId=category.id;
    this.resetFilters();
    this.loadServiceByCategory(category.id);

    this.subCategoryService.getByCategory(category.id).subscribe((res) => {
      this.ngZone.run(() => {
        this.subCategories = res;
        this.cdr.detectChanges();
      });
    });
  }

  loadServiceByCategory(categoryId: number) {
    this.allServices = [];
    this.service = [];
    this.particularService.getById(categoryId).subscribe({
      next: (res) => {
        this.allServices = res;
        this.applyFilters();
      },
      error: (err) => console.error(err),
    });
  }

  // ── Manage Modal (Category + SubCategory) ──────────────────────────────────
  openManageModal(service: ServiceType) {
    this.selectedServiceId = service.id;
    this.selectedServiceName = service.name;
    this.categoryForm.reset();
    this.subCategoryForm.reset();
    this.selectedCategoryId = null;
    this.manageSubCategories = [];
    this.loadCategories(service.id);
  }

  loadCategories(serviceId: number) {
    this.categoryService.getByService(serviceId).subscribe((res) => {
      this.ngZone.run(() => {
        this.categories = res;
        this.cdr.detectChanges();
      });
    });
  }

  loadSubCategories(categoryId: number) {
    this.selectedCategoryId = categoryId;
    this.subCategoryService.getByCategory(categoryId).subscribe((res) => {
      this.ngZone.run(() => {
        this.manageSubCategories = res; //  separate from form subCategories
        this.cdr.detectChanges();
      });
    });
  }

  openAddCategoryModal() {
    this.isCategorySubmitted = false;
    this.categoryBackendError = '';
    this.categoryForm.reset();
    const el = document.getElementById('addCategoryModal');
    if (el) bootstrap.Modal.getOrCreateInstance(el, { backdrop: true, keyboard: true }).show();
  }

  openAddSubCategoryModal() {
    if (!this.selectedCategoryId) {
      this.showError('Please select a category first');
      return;
    }
    this.isSubCategorySubmitted = false;
    this.subCategoryBackendError = '';
    this.subCategoryForm.reset();
    const el = document.getElementById('addSubCategoryModal');
    if (el) bootstrap.Modal.getOrCreateInstance(el, { backdrop: true, keyboard: true }).show();
  }

  saveCategory() {
    this.isCategorySubmitted = true;
    this.categoryForm.markAllAsTouched();
    if (this.categoryForm.invalid || !this.selectedServiceId) {
      
      return;
    }

    const request = {
      name: this.categoryForm.value.name.trim(),
      serviceTypeId: this.selectedServiceId,
    };

    this.categoryService.create(request).subscribe({
      next: () => {
        this.categoryForm.reset();
        this.isCategorySubmitted = false;
        this.loadCategories(this.selectedServiceId!);
        this.showSuccess('Category added successfully');
        const el = document.getElementById('addCategoryModal');
        if (el) bootstrap.Modal.getOrCreateInstance(el).hide();
      },
      error: (err) => {
        this.categoryBackendError = err.error?.error ?? 'Something went wrong.';
        let errorMessage = err.error?.error ?? 'Something went wrong.';
      this.showError(errorMessage);
      },
    });
  }

  saveSubCategory() {
    this.isSubCategorySubmitted = true;
    this.subCategoryForm.markAllAsTouched();
    if (this.subCategoryForm.invalid || !this.selectedCategoryId) {
      this.showError('Please select a subcategory first');
      return;
    }
     

    const request = {
      name: this.subCategoryForm.value.name.trim(),
      categoryId: this.selectedCategoryId,
    };

    this.subCategoryService.create(request).subscribe({
      next: () => {
        this.subCategoryForm.reset();
        this.isSubCategorySubmitted = false;
        this.loadSubCategories(this.selectedCategoryId!);
        this.showSuccess('Sub-category added successfully');
        const el = document.getElementById('addSubCategoryModal');
        if (el) bootstrap.Modal.getOrCreateInstance(el).hide();
      },
      error: (err) => {
        this.subCategoryBackendError =
          err.error?.errors?.Name?.[0] ?? err.error?.error ?? 'Something went wrong.';
          let errorMessage = err.error?.errors?.Name?.[0] ?? err.error?.error ?? 'Something went wrong.';
          this.showError(errorMessage);
        },
    });
  }

  // ── Modal Open/Reset ───────────────────────────────────────────────────────
  openAddCleaningModal() {
    this.resetModal();
  }

  openEditModal(service: Service) {
    this.resetModal();
    this.isEditMode = true;
    this.editingServiceId = service.id;
    

    this.particularService.getServiceDetail(service.id).subscribe({
      next: (detail) => {
        this.cleaningForm.patchValue({
          name: detail.name,
          subCategoryId: Number(detail.subCategoryId),
          durationMin: this.parseDuration(detail.duration),
          price: detail.price,
          commissionPct: detail.commissionPct,
          isAvailable: detail.availability === 'Available',
          includesEnabled: (detail.includes?.length ?? 0) > 0,
          excludesEnabled: (detail.excludes?.length ?? 0) > 0,
        });

        this.existingImages = detail.images.map((path) => ({
          fileName: path.split('/').pop()!,
          url: `${environment.mediaBaseUrl}/${path}`,
        }));

        this.includes.clear();
        detail.includes?.forEach((item) => this.includes.push(this.fb.control(item)));

        this.excludes.clear();
        detail.excludes?.forEach((item) => this.excludes.push(this.fb.control(item)));
      },
      error: (err: any) => console.error('Failed to load service detail', err),
    });
  }

  resetModal() {
    this.isCleaningSubmitted = false;
    this.duplicateNameError = '';
    this.isEditMode = false;
    this.editingServiceId = null;
    this.existingImages = [];
    this.removedImageNames = [];
    this.imagePreviews = [];

    if (this.cleaningForm) {
      (this.cleaningForm.get('images') as FormArray)?.clear();
      (this.cleaningForm.get('includes') as FormArray)?.clear();
      (this.cleaningForm.get('excludes') as FormArray)?.clear();

      this.cleaningForm.reset({ 
        name: '',
        subCategoryId: '',
        durationMin: 0,
        price: 0,
        commissionPct: 0,
        isAvailable: true,
        includesEnabled: false,
        excludesEnabled: false,
      });
    }
  }

  // ── Submit ─────────────────────────────────────────────────────────────────
  submitService() {
    this.isCleaningSubmitted = true;
    this.duplicateNameError = '';
    this.cleaningForm.markAllAsTouched();

    if (!this.cleaningForm || this.cleaningForm.invalid) return;

    if (!this.isEditMode && !this.selectedCategory) {
      alert('Please select a category first');
      return;
    }

    // Duplicate name check within same category
    const enteredName = this.cleaningForm.value.name.trim().toLowerCase();
    const selectedSubCategoryId = Number(this.cleaningForm.value.subCategoryId);
    const isDuplicate = this.allServices.some(
      (s) =>
        s.name.trim().toLowerCase() === enteredName &&
        s.subCategoryId === selectedSubCategoryId &&
        (!this.isEditMode || s.id !== this.editingServiceId)
    );
    if (isDuplicate) {
      this.duplicateNameError = 'A service with this name already exists in this category.';
      return;
    }

    const formValue = this.cleaningForm.value;
    const formData = new FormData();

    formData.append('name', formValue.name);
    formData.append('subCategoryId', formValue.subCategoryId);
    formData.append('durationMin', formValue.durationMin.toString());
    formData.append('price', formValue.price);
    formData.append('commissionPct', formValue.commissionPct.toString());
    formData.append('isAvailable', formValue.isAvailable);

    this.includes.controls.forEach((c: any) => formData.append('includes', c.value));
    this.excludes.controls.forEach((c: any) => formData.append('excludes', c.value));

    if (this.isEditMode && this.editingServiceId !== null) {
      this.existingImages.forEach((img) => formData.append('retainedImageNames', img.fileName));
      this.images.controls.forEach((c: any) => formData.append('newImages', c.value));

      this.particularService.updateService(this.editingServiceId, formData).subscribe({
        next: () => {
          console.log('Service updated ');
          if (this.selectedCategory) this.loadServiceByCategory(this.selectedCategory.id);
          this.showSuccess('Service updated successfully');
          this.resetModal();
          this.dismissModal('addCleaningServiceModal');
        },
        error: (err: any) => {
          console.error('Update failed ', err);
  
         
          let errorMessage = err.error?.message ?? 'Failed to update service';
          this.showError(errorMessage);
        },
      });
    } else {
      this.images.controls.forEach((c: any) => formData.append('images', c.value));

      this.particularService.addService(formData).subscribe({
        next: (res) => {
          console.log('Service added ', res);
          if (this.selectedCategory) this.loadServiceByCategory(this.selectedCategory.id);
          this.showSuccess('Service added successfully');

          this.resetModal();
          this.dismissModal('addCleaningServiceModal');
        },
        error: (err: any) => {
          console.error('Error adding service ', err);
  
          let errorMessage = err.error?.message ?? 'Failed to add service';
          this.showError(errorMessage);
        },
      });
    }
  }

  // ── CRUD ───────────────────────────────────────────────────────────────────
  goToServiceDetails(id: number) {
    this.router.navigate(['/admin/admin-layout/service-management/service-details', id]);
  }

  onAvailabilityChange(service: any, newValue: boolean) {
    const confirmMsg = newValue
      ? 'Are you sure you want to make this service AVAILABLE?'
      : 'Are you sure you want to make this service UNAVAILABLE?';

    if (!confirm(confirmMsg)) {
      // revert switch if user cancels
      service.isAvailable = !newValue;
      return;
    }
    console.log('Service ID:', service.id);
    console.log('New Availability:', newValue);
    const oldValue = !newValue;
    this.particularService.updateAvailability(service.id, newValue).subscribe({
      next: () => {
        const status = newValue ? 'available' : 'unavailable';
        this.showSuccess(`Service is now ${status}`);
      },
      error: (err) => {
        console.error('Update failed', err);
        service.isAvailable = !newValue;
        let errorMessage = err.error?.message ?? 'Failed to update availability';
        this.showError(errorMessage);
      },
    });
  }

  // ── Filter Logic ───────────────────────────────────────────────────────────
  applyFilters() {
    this.service = this.allServices.filter((s) => {
      if (this.filterSubCategoryId !== null && s.subCategoryId !== this.filterSubCategoryId)
        return false;
      if (s.price < this.filterMinPrice || s.price > this.filterMaxPrice) return false;
      if (s.commissionPct < this.filterMinCommission || s.commissionPct > this.filterMaxCommission)
        return false;
      if (this.filterAvailability === 'true' && !s.isAvailable) return false;
      if (this.filterAvailability === 'false' && s.isAvailable) return false;
      return true;
    });
  }

  onFilterSubCategoryChange(value: string) {
    this.filterSubCategoryId = value ? Number(value) : null;
    this.applyFilters();
  }
  onFilterAvailabilityChange(value: string) {
    this.filterAvailability = value;
    this.applyFilters();
  }
  onFilterPriceChange() {
    this.filterMinPrice = this.minValue;
    this.filterMaxPrice = this.maxValue;
    this.applyFilters();
  }
  onFilterCommissionChange(min: string, max: string) {
    this.filterMinCommission = min ? Number(min) : 0;
    this.filterMaxCommission = max ? Number(max) : 100;
    this.applyFilters();
  }

  resetFilters() {
    this.filterSubCategoryId = null;
    this.filterAvailability = '';
    this.filterMinPrice = 0;
    this.filterMaxPrice = 99999;
    this.filterMinCommission = 0;
    this.filterMaxCommission = 100;
    this.minValue = 0;
    this.maxValue = 99999;
    this.applyFilters();
  }

  // ── Image Handling ─────────────────────────────────────────────────────────
  onImageSelect(event: any) {
    const files: FileList = event.target.files;
    if (!files || files.length === 0) return;
    for (let i = 0; i < files.length; i++) {
      const file = files[i];
      this.images.push(this.fb.control(file));
      const reader = new FileReader();
      reader.onload = (e: any) => {
        this.ngZone.run(() => {
          this.imagePreviews.push(e.target.result);
          this.cdr.detectChanges();  // ← force Angular to update view
        });
      };
      reader.readAsDataURL(file);
    }
    // Reset input so same file can be selected again
    event.target.value = '';
  }

  removeImage(index: number) {
    this.images.removeAt(index);
    this.imagePreviews.splice(index, 1);
  }
  removeExistingImage(index: number) {
    const removed = this.existingImages.splice(index, 1)[0];
    this.removedImageNames.push(removed.fileName);
  }

  // ── Includes / Excludes ────────────────────────────────────────────────────
  addInclude(item: string = '') {
    if (!item.trim()) return;
    this.includes.push(this.fb.control(item.trim()));
  }
  addExclude(item: string = '') {
    if (!item.trim()) return;
    this.excludes.push(this.fb.control(item.trim()));
  }
  removeInclude(index: number) {
    this.includes.removeAt(index);
  }
  removeExclude(index: number) {
    this.excludes.removeAt(index);
  }

  addIncludeFromInput(value: string) {
    const text = value?.trim();
    if (!text) return;
    if (text.length > 100) return; // guard
    const exists = this.includes.controls.some(c => c.value === text);
    if (!exists) {
      this.includes.push(this.fb.control(text, [Validators.maxLength(100)]));
    }
  }
  
  addExcludeFromInput(value: string) {
    const text = value?.trim();
    if (!text) return;
    if (text.length > 100) return; // guard
    const exists = this.excludes.controls.some(c => c.value === text);
    if (!exists) {
      this.excludes.push(this.fb.control(text, [Validators.maxLength(100)]));
    }
  }
  addSubCategory() {
    console.log('');
  }

  // ── Helpers ────────────────────────────────────────────────────────────────
  parseDuration(duration: string): number {
    let total = 0;
    const hrMatch = duration.match(/(\d+)\s*hr/);
    const minMatch = duration.match(/(\d+)\s*min/);
    if (hrMatch) total += parseInt(hrMatch[1]) * 60;
    if (minMatch) total += parseInt(minMatch[1]);
    return total;
  }

  trackByIndex(index: number): number {
    return index;
  }

  private dismissModal(modalId: string) {
    const el = document.getElementById(modalId);
    if (el) bootstrap.Modal.getOrCreateInstance(el).hide();
  }

  submitFromModal() {
    this.cleaningFormRef.nativeElement.requestSubmit();
  }




  // alerts
  openDeleteDialog(type: 'service' | 'category' | 'subcategory' , id: number) {
    console.log('openDeleteDialog called', type, id);

    this.deleteType = type;
    this.deleteId = id;
  
    if (type === 'service') {
      this.deleteMessage = 'Are you sure you want to delete this service?';
    }
  
    if (type === 'category') {
      this.deleteMessage = 'Are you sure you want to delete this category?';
    }
  
    if (type === 'subcategory') {
      this.deleteMessage = 'Are you sure you want to delete this sub category?';
    }
  
    this.showDeleteDialog = true;
    this.cdr.detectChanges();
  }
  
  cancelDelete() {
    this.showDeleteDialog = false;
    this.deleteId = null;
    this.deleteType = null;
  }

  confirmDelete() {

    if (!this.deleteType || !this.deleteId) return;
  
    if (this.deleteType === 'category') {
  
      this.categoryService.delete(this.deleteId).subscribe( {
        next: () => {
        this.categories = this.categories.filter(c => c.id !== this.deleteId);
        this.applyFilters();
        this.subCategories = [];
        this.service=[];

        this.showSuccess('Category deleted successfully');
  
        this.cancelDelete();
  
      },
      error: (err) =>{ console.error('Delete failed', err)
        let errorMessage = 'Failed to delete category';

        // Extract error message from backend if available
        if (err.error?.message) {
          errorMessage = err.error.message;
        } else if (typeof err.error === 'string') {
          errorMessage = err.error;
        }
  
        // Show error toast
        this.showError(errorMessage);
      },
     } );
  
    }
  
    if (this.deleteType === 'subcategory') {
  
      this.subCategoryService.delete(this.deleteId).subscribe( {
        next: () => {
        this.subCategories = this.subCategories.filter(
          sc => sc.id !== this.deleteId
        );
        if (this.manageSubCategories) {
          this.manageSubCategories = this.manageSubCategories.filter(sc => sc.id !== this.deleteId);
        }
        this.applyFilters();
        this.service=[];
        this.showSuccess('Sub-Category deleted successfully');
  
        this.cancelDelete();
  
      },
      error: (err) =>{ console.error('Delete failed', err)
        let errorMessage = 'Failed to delete subcategory';

        // Extract error message from backend if available
        if (err.error?.message) {
          errorMessage = err.error.message;
        } else if (typeof err.error === 'string') {
          errorMessage = err.error;
        }
  
        // Show error toast
        this.showError(errorMessage);
      },
    });
  
    }
  
    if (this.deleteType === 'service') {
  
      this.particularService.deleteService(this.deleteId).subscribe({
        next: () => {
          if (this.selectedCategory) {
            this.loadServiceByCategory(this.selectedCategory.id);
          }
        
          this.showSuccess('Service deactivated successfully');
          this.cancelDelete();
        },
        error: (err) =>{ console.error('Delete failed', err)
          let errorMessage = 'Failed to delete service';

          // Extract error message from backend if available
          if (err.error?.message) {
            errorMessage = err.error.message;
          } else if (typeof err.error === 'string') {
            errorMessage = err.error;
          }
    
          // Show error toast
          this.showError(errorMessage);
        },
      });
    }
  }
  showSuccess(message: string) {
    this.toastMessage = message;
    this.toastType = 'success';
    this.toastTrigger++; // increment to trigger ngOnChanges
  }
  showError(message: string) {
    this.toastMessage = message;
    this.toastType = 'error';
    this.toastTrigger++; // increment to trigger ngOnChanges
  }
}
