import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ServicePartners } from './service-partners';

describe('ServicePartners', () => {
  let component: ServicePartners;
  let fixture: ComponentFixture<ServicePartners>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [ServicePartners]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ServicePartners);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
