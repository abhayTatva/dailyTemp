import { Component } from '@angular/core';

@Component({
  selector: 'app-service-partners',
  imports: [],
  templateUrl: './service-partners.html',
  styleUrl: './service-partners.css',
})
export class ServicePartners {

}
