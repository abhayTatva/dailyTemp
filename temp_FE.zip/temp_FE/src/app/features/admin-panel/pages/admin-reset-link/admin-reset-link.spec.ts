import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AdminResetLink } from './admin-reset-link';

describe('AdminResetLink', () => {
  let component: AdminResetLink;
  let fixture: ComponentFixture<AdminResetLink>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [AdminResetLink]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AdminResetLink);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
