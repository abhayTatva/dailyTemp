import { CommonModule } from '@angular/common';
import { Component, Input } from '@angular/core';
import { FormBuilder, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { Button } from '../../../../shared/components/button/button';
import { Router, RouterLink } from '@angular/router';
import { AdminSendEmail } from '../../services/send-email-service/admin-send-email';

@Component({
  selector: 'app-admin-reset-link',
  imports: [CommonModule, ReactiveFormsModule, Button],
  templateUrl: './admin-reset-link.html',
  styleUrl: './admin-reset-link.css',
})
export class AdminResetLink {
  isError = false;
  isSent = false;

  errorMessage = '';
  successMessage='';

  emailForm: FormGroup;

  constructor(private fb: FormBuilder, private router: Router,private emailService:AdminSendEmail) {
    this.emailForm = this.fb.group({
      email: ['', [Validators.email, Validators.required]]
    })
  }

  onReset() 
  {
    if (this.emailForm.get('email')?.invalid) 
    {
      this.isError = true;
      this.isSent = false;
      this.errorMessage = 'Enter a valid email address';
    }
    else 
    {
      this.emailService.sendResetLink(this.emailForm.get('email')?.value).subscribe({
        next:(res)=>{
          this.isSent=true;
          this.isError=false;
          this.successMessage = res.message;
        },
        error:()=>{
          this.isError=true;
          this.isSent = false;
          this.errorMessage="email not registered";
        }
      });
    }
  }
}
