import { TestBed } from '@angular/core/testing';

import { AdminSendEmail } from './admin-send-email';

describe('AdminSendEmail', () => {
  let service: AdminSendEmail;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(AdminSendEmail);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
