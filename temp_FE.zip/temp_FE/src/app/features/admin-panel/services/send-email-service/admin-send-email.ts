import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root',
})
export class AdminSendEmail {
  private apiUrl="http://localhost:5025/api/SendResetPasswordEmail";

  constructor(private http:HttpClient){}

  sendResetLink(email:string):Observable<any>{
    return this.http.post(`${this.apiUrl}/send-link`,{email});
  }
}
