import { CommonModule } from '@angular/common';
import { Component, EventEmitter, Input, Output } from '@angular/core';

@Component({
  selector: 'app-button',
  imports: [CommonModule],
  templateUrl: './button.html',
  styleUrl: './button.css',
})
export class Button {
  @Input() label:string="click";
  @Input() width: string = '120px';
  @Input() height: string = '40px';
  @Input() borderRadius:string='8px';
  @Input() type:string='button';
  @Input() dismiss: string = '';

  @Output() buttonClick=new EventEmitter<void>();

  handleClick(){
    this.buttonClick.emit();
  }
}
