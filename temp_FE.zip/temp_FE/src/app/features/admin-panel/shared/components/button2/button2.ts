import { CommonModule } from '@angular/common';
import { Component, EventEmitter, Input, Output } from '@angular/core';


@Component({
  selector: 'app-button2',
  imports: [CommonModule],
  templateUrl: './button2.html',
  styleUrl: './button2.css',
})
export class Button2 {
  @Input() label:string="click";
  @Input() width: string = '120px';
  @Input() height: string = '40px';
  @Input() borderRadius:string='8px';
  @Input() dataBsToggle?: string;
  @Input() dataBsTarget?: string;
  @Input() dismiss: string = ''; 

  @Output() buttonClick=new EventEmitter<void>();

  onClick(){
    this.buttonClick.emit();
  }

}
