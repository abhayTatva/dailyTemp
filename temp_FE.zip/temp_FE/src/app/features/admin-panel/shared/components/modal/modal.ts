import { Component, Input, Output, EventEmitter } from '@angular/core';
import { Button } from '../button/button';
import { Button2 } from '../button2/button2';
import { CommonModule } from '@angular/common';
import { FormGroup, ReactiveFormsModule } from '@angular/forms';

@Component({
  selector: 'app-modal',
  standalone: true,
  imports: [Button, Button2, CommonModule, ReactiveFormsModule],
  templateUrl: './modal.html',
  styleUrl: './modal.css',
})
export class Modal {
  @Input() title: string = '';
  @Input() modalId: string = 'commonModal';
  @Input() dialogClass: string = '';
  @Input() formGroup!: FormGroup;
  @Input() footerAlign: 'center' | 'end' | 'start' = 'center';
  @Input() buttonWidth: string = '172px';
  @Input() buttonHeight: string = '48px';
  @Input() allowClickOutside: boolean = false;
  @Input() autoDismiss: boolean = true;

  @Output() submitForm = new EventEmitter<void>();

  onSubmit() {
    this.submitForm.emit();
  }

  @Output() save = new EventEmitter<void>();

  onSave() {
    console.log('Modal Save Clicked');
    this.save.emit();
  }

}
