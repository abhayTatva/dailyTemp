import { Component , Input, Output, EventEmitter } from '@angular/core';
import { Button } from '../button/button';
import { Button2 } from '../button2/button2';
import { CommonModule, NgClass } from '@angular/common';
import { FormGroup, ReactiveFormsModule } from '@angular/forms';

@Component({
  selector: 'app-modal2',
  imports: [Button2, Button, NgClass],
  templateUrl: './modal2.html',
  styleUrl: './modal2.css',
})
export class Modal2 {
  @Input() title: string = '';
  @Input() modalId: string = 'commonModal';
  @Input() dialogClass: string = '';
  @Input() formGroup!: FormGroup;

  @Input() allowClickOutside: boolean = false;  // mg

  @Output() submitForm = new EventEmitter<void>();

  onSubmit() {
    this.submitForm.emit();
  }

  @Output() save = new EventEmitter<void>();

  onSaveClick() {
    console.log('Modal Save Clicked');
    this.save.emit();
  }

  close() {

    const modalElement = document.getElementById(this.modalId);

    if (!modalElement) return;

    const bootstrap = (window as any).bootstrap;

    const modalInstance =
      bootstrap.Modal.getInstance(modalElement) ||
      new bootstrap.Modal(modalElement);

    modalInstance.hide();

  }

}
