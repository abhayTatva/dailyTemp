import { Component } from '@angular/core';
import { FormBuilder, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { LightButton } from '../../shared/components/light-button/light-button';
import { Button } from '../../../../shared/components/button/button';
import { AuthService } from '../../services/auth-service/auth-service';
import { CommonModule } from '@angular/common';
import { SendOtpService } from '../../services/send-otp-service/send-otp-service';


@Component({
  selector: 'app-enter-otp',
  standalone: true,
  imports: [ReactiveFormsModule, Button, LightButton, CommonModule],
  templateUrl: './enter-otp.html',
  styleUrl: './enter-otp.css',
})
export class EnterOTP {

  email!: string;
  name!: string;

  ngOnInit() {
    this.email = sessionStorage.getItem("email")!;
    this.name = sessionStorage.getItem("name")!;
  }

  loginForm: FormGroup;
  message: string | null = null;
  messageType: 'error' | 'success' | '' = '';

  constructor(private fb: FormBuilder, private router: Router, private authService: AuthService, private sendOtpService: SendOtpService) {

    this.loginForm = this.fb.group({
      otp: ['', [Validators.maxLength(4), Validators.minLength(4), Validators.required, Validators.pattern(/^[0-9]{4}$/)]]
    })
  }

  onLogin() {
    if (this.loginForm.get("otp")?.value == '') {
      this.message = "Please enter OTP";
      this.messageType = 'error';
    }
    else if (this.loginForm.get('otp')?.invalid) {
      this.message = "OTP must be 4 digits.";
      this.messageType = 'error';
    }
    else {
      this.sendOtpService.verifyOtp(this.name, this.email, this.loginForm.get('otp')?.value).subscribe({
        next: (res: any) => {
          localStorage.setItem("user_token", res.token);
          this.router.navigate(['/layout/home'])
        },
        error: (err) => {
          this.message = err.error.message,
          this.messageType = 'error';
        }
      });
    }
  }

  onResendOTP() {
    this.sendOtpService.sendOtp(this.email,this.name).subscribe({
      next: () => {
        this.message = "OTP Resend Successfully";
        this.messageType = 'success';
      },
      error: (err) => { console.log("Error occured", err) }
    });
  }
}
