import { Component } from '@angular/core';
import { FormBuilder, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { Router, RouterLink } from '@angular/router';
import { Button } from '../../../../shared/components/button/button';
import { CommonModule } from '@angular/common';
import { SendOtpService } from '../../services/send-otp-service/send-otp-service';



@Component({
  selector: 'app-login',
  standalone: true,
  imports: [ReactiveFormsModule, Button, CommonModule,RouterLink],
  templateUrl: './login.html',
  styleUrl: './login.css',
})
export class Login {
  loginForm: FormGroup;
  errorMessage: string | null = null

  constructor(private fb: FormBuilder, private router: Router, private sendOtpService: SendOtpService) {

    this.loginForm = this.fb.group({
      name: ['', [Validators.required, Validators.minLength(2),Validators.maxLength(30)]],
      email: ['', [Validators.email, Validators.required,Validators.maxLength(40  ),Validators.minLength(6)]]
    })
  }

  onLogin() {
    if (this.loginForm.get('name')?.invalid) {
      this.errorMessage = "Please enter a valid name"
    }

    else if (this.loginForm.get('email')?.invalid) {
      this.errorMessage = "Please enter a valid email address";
    }

    else {
      sessionStorage.setItem("email", this.loginForm.get('email')?.value,);
      sessionStorage.setItem("name", this.loginForm.get('name')?.value);
      
      this.sendOtpService.sendOtp(this.loginForm.get('email')?.value, this.loginForm.get('name')?.value).subscribe({
        next: () => {
          this.router.navigate(["/enter-otp"])
        },
        error: (err) => { console.log("Error occured", err) }
      });
    }
  }
}
