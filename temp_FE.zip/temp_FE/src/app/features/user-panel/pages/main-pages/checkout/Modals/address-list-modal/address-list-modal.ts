import { Component, inject, OnInit, output } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CheckoutService } from '../../checkout.service';
import { SavedAddress } from '../../checkout.models';

@Component({
  selector: 'app-address-list-modal',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './address-list-modal.html',
  styleUrls: ['./address-list-modal.scss'],
})
export class AddressListModalComponent implements OnInit{
  readonly svc = inject(CheckoutService);

  close       = output<void>();
  openMap     = output<void>();
  addNew      = output<void>();

  selectedIndex: number | null = null;

  ngOnInit() {
    this.svc.loadSavedAddresses();   // ← trigger fetch
  
    const cur = this.svc.selectedAddress();
    if (cur) {
      this.selectedIndex = this.svc.savedAddresses()  // ← now a signal, add ()
        .findIndex(a => a === cur);
    }
  }
  select(addr: SavedAddress, i: number): void {
    this.selectedIndex = i;
  }

  save(): void {
    if (this.selectedIndex !== null) {
      this.svc.confirmAddress(this.svc.savedAddresses()[this.selectedIndex]);
    }
    this.close.emit();
  }
}
