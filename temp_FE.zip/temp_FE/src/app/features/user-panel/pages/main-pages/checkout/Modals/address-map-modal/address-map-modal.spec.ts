import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AddressMapModalComponent } from './address-map-modal';

describe('AddressMapModal', () => {
  let component: AddressMapModalComponent;
  let fixture: ComponentFixture<AddressMapModalComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [AddressMapModalComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AddressMapModalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
