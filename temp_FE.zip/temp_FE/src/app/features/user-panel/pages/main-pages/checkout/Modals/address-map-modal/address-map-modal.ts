import {
  Component, OnInit, AfterViewInit, OnDestroy,
  inject, output, signal,
  NgZone
} from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import * as L from 'leaflet';
import { CheckoutService } from '../../checkout.service';
import { SavedAddress } from '../../checkout.models';

// ── Fix Leaflet's broken default marker icons in Angular/Webpack ──
const iconDefault = L.icon({
  iconUrl: 'assets/marker-icon.png',
  iconRetinaUrl: 'assets/marker-icon-2x.png',
  shadowUrl: 'assets/marker-shadow.png',
  iconSize: [25, 41],
  iconAnchor: [12, 41],
  popupAnchor: [1, -34],
  shadowSize: [41, 41],
});
L.Marker.prototype.options.icon = iconDefault;

@Component({
  selector: 'app-address-map-modal',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './address-map-modal.html',
  styleUrls: ['./address-map-modal.scss'],
})
export class AddressMapModalComponent implements AfterViewInit, OnDestroy {
  readonly svc = inject(CheckoutService);
  private zone = inject(NgZone);

  close = output<void>();
  goBack = output<void>(); // ← kept as-is, "Change" still goes back to list

  // ── Form fields (unchanged) ──
  saveAs = signal<'Home' | 'Other'>('Other');
  houseNumberError = signal<string | null>(null);
  customLabelError = signal<string | null>(null);
  // ── Map state ──
  private map!: L.Map;
  private marker!: L.Marker;

  isFetching = signal(false);
  fetchError = signal<string | null>(null);

  // replaces the hardcoded `previewAddress` object
  previewAddress = signal<SavedAddress>({
    latitude: 0,
    longitude: 0,
    fullAddress: 'Fetching address…',
    houseNumber: '',
    landmark: '',
    label: 0,
    customLabel: '',
  });

  // Default center — Times Square (matches your first saved address)
  private readonly defaultLatLng: L.LatLngTuple = [23.0225, 72.5714];

  // ── Lifecycle ──
  ngAfterViewInit(): void {
    // Small timeout lets Angular finish rendering the #checkout-map div
    setTimeout(() => this.initMap(), 0);
  }

  ngOnDestroy(): void {
    this.map?.remove();
  }

  updateHouseNumber(value: string) {
    this.previewAddress.update(addr => ({
      ...addr,
      houseNumber: value
    }));
  }

  updateLandmark(value: string) {
    this.previewAddress.update(addr => ({
      ...addr,
      landmark: value
    }));
  }

  updateCustomLabel(value: string) {
    this.previewAddress.update(addr => ({
      ...addr,
      customLabel: value
    }));
  }
  // ── Map setup ──
  private initMap(): void {
    const pending = this.svc.pendingMapLocation();
    const center: L.LatLngTuple = pending ? [pending.lat, pending.lng] : this.defaultLatLng;
    this.map = L.map('checkout-map', {
      center: center,
      zoom: 16,
      zoomControl: true,
      attributionControl: false,   // keeps UI clean; re-enable if you need it
    });

    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
      maxZoom: 19,
    }).addTo(this.map);

    this.marker = L.marker(center, { draggable: true }).addTo(this.map);

    // Drag ends → reverse-geocode the new position
    this.marker.on('dragend', () => {
      const { lat, lng } = this.marker.getLatLng();
      this.reverseGeocode(lat, lng);
    });

    // Tap/click on map → move marker + reverse-geocode
    this.map.on('click', (e: L.LeafletMouseEvent) => {
      this.marker.setLatLng(e.latlng);
      this.reverseGeocode(e.latlng.lat, e.latlng.lng);
    });

    // Fetch address for the initial pin position
    this.reverseGeocode(center[0], center[1]);
    this.svc.setPendingMapLocation(null);
  }

  // ── Reverse-geocode ──
  private reverseGeocode(lat: number, lng: number): void {
    this.isFetching.set(true);
    this.fetchError.set(null);

    this.svc.reverseGeocode(lat, lng).subscribe({
      next: (res: any) => {
        // ↓ Adjust field names to match your API's actual response shape
        console.log(res);
        this.previewAddress.set({
          latitude: lat,
          longitude: lng,
          fullAddress: res.fullAddress ?? res.address ?? '',
          houseNumber: res.houseNumber ?? '',
          landmark: res.landmark ?? '',
          label: res.label ?? 0,
          customLabel: res.customLabel ?? '',
        });
        this.isFetching.set(false);
      },
      error: () => {
        this.fetchError.set('Could not fetch address. Try moving the pin.');
        this.isFetching.set(false);
      },
    });
  }

  // ── Use current GPS location ──
  locateMe(): void {
    if (!navigator.geolocation) {
      alert('Geolocation is not supported by your browser.');
      return;
    }

    navigator.geolocation.getCurrentPosition(
      ({ coords }) => {
        this.zone.run(() => {                              // ← key fix
          const latlng = L.latLng(coords.latitude, coords.longitude);
          this.map.setView(latlng, 16);                   // 1. pan map
          this.marker.setLatLng(latlng);                  // 2. move pin
          this.reverseGeocode(coords.latitude, coords.longitude); // 3. fetch address
        });
      },
      (err) => {
        this.zone.run(() => {
          console.log('this is error for location', err);
          this.fetchError.set('Location access denied.');  // show error in UI
        });
      }
    );
  }

  setSaveAs(v: 'Home' | 'Other'): void { this.saveAs.set(v); }

  checkValidation(): boolean {
    this.houseNumberError.set(null);
    this.customLabelError.set(null);
    if (!this.previewAddress().houseNumber?.trim()) {
      this.houseNumberError.set('House number is required');
    }
    if (this.saveAs() === 'Other') {

      if (!this.previewAddress().customLabel?.trim()) {
        this.customLabelError.set('Custom label is required');
      }
    }

    if (this.houseNumberError() || this.customLabelError()) {
      return false;
    }
    return true;
  }
  save(): void {
    if (!this.checkValidation()) return;
    this.svc.saveAddress(this.previewAddress()).subscribe();
    this.svc.confirmAddress(this.previewAddress());
    this.close.emit();
  }
}