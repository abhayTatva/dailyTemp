import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AddressSearchModalComponent } from './address-search-modal';

describe('AddressSearchModal', () => {
  let component: AddressSearchModalComponent;
  let fixture: ComponentFixture<AddressSearchModalComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [AddressSearchModalComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AddressSearchModalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
