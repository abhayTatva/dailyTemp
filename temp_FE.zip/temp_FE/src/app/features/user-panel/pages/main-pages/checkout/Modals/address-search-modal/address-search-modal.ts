// address-search-modal.component.ts
import {
  Component, OnInit, OnDestroy,
  inject, output, signal, NgZone
} from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { HttpClient } from '@angular/common/http';
import { of, Subject, Subscription } from 'rxjs';
import { debounceTime, distinctUntilChanged, switchMap, catchError } from 'rxjs/operators';
import { CheckoutService } from '../../checkout.service';
import { SavedAddress } from '../../checkout.models';

export interface SearchSuggestion {
  displayName: string;
  subText: string;
  lat: number;
  lng: number;
}

export interface AddressPickEvent {
  lat: number;
  lng: number;
  address: string;
}

@Component({
  selector: 'app-address-search-modal',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './address-search-modal.html',
  styleUrls: ['./address-search-modal.scss'],
})
export class AddressSearchModalComponent implements OnInit, OnDestroy {
  private http   = inject(HttpClient);
  private zone   = inject(NgZone);
  readonly svc   = inject(CheckoutService);

  /** Emitted when the user cancels / closes */
  close = output<void>();

  /**
   * Emitted when the user picks any address (suggestion, recent, or GPS).
   * Parent should open the map modal pre-centred on this position.
   */
  addressPicked = output<AddressPickEvent>();

  // ── State ──
  searchQuery   = signal('');
  suggestions   = signal<SearchSuggestion[]>([]);
  isSearching   = signal(false);
  recentSearches = signal<SavedAddress[]>([]);

  private search$ = new Subject<string>();
  private sub!: Subscription;

  ngOnInit(): void {
    // Load saved addresses to show as "Recent Searches"
    this.svc.loadSavedAddresses();
    this.recentSearches.set(this.svc.savedAddresses());

    // Wire up debounced search
    this.sub = this.search$.pipe(
      debounceTime(400),
      distinctUntilChanged(),
      switchMap(query => {
        if (!query.trim()) {
          this.suggestions.set([]);
          this.isSearching.set(false);
          return of([]);
        }
        this.isSearching.set(true);
        return this.http
          .get<any[]>(
            `https://nominatim.openstreetmap.org/search` +
            `?format=json&q=${encodeURIComponent(query)}&limit=6&addressdetails=1`,
            { headers: { 'Accept-Language': 'en' } }
          )
          .pipe(catchError(() => of([])));
      })
    ).subscribe((results: any[]) => {
      this.isSearching.set(false);
      this.suggestions.set(
        results.map(r => {
          const parts = r.display_name.split(',').map((p: string) => p.trim());
          return {
            displayName: parts[0],
            subText: parts.slice(1, 4).join(', '),
            lat: parseFloat(r.lat),
            lng: parseFloat(r.lon),
          };
        })
      );
    });
  }

  ngOnDestroy(): void {
    this.sub?.unsubscribe();
  }

  // ── Handlers ──

  onSearch(value: string): void {
    this.searchQuery.set(value);
    this.search$.next(value);
  }

  clearSearch(): void {
    this.searchQuery.set('');
    this.suggestions.set([]);
    this.isSearching.set(false);
  }

  /** User clicked a Nominatim suggestion */
  pick(s: SearchSuggestion): void {
    this.addressPicked.emit({ lat: s.lat, lng: s.lng, address: s.displayName });
  }

  /** User clicked a saved / recent address */
  pickSaved(addr: SavedAddress): void {
    this.addressPicked.emit({
      lat: addr.latitude,
      lng: addr.longitude,
      address: addr.fullAddress,
    });
  }

  /** "Use current location" button */
  useCurrentLocation(): void {
    if (!navigator.geolocation) {
      alert('Geolocation is not supported by your browser.');
      return;
    }
    navigator.geolocation.getCurrentPosition(
      ({ coords }) => {
        this.zone.run(() => {
          this.addressPicked.emit({
            lat: coords.latitude,
            lng: coords.longitude,
            address: '',          // map modal will reverse-geocode it
          });
        });
      },
      () => {
        this.zone.run(() => alert('Location access denied.'));
      }
    );
  }
}
