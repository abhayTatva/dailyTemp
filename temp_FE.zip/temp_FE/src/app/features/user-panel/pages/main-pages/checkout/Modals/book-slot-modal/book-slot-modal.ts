import { Component, inject, input, output, signal, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CheckoutService } from '../../checkout.service';
import { AvailableDateResponseDto, AvailableSlotResponseDto } from '../../checkout.models';

@Component({
  selector: 'app-book-slot-modal',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './book-slot-modal.html',
  styleUrls: ['./book-slot-modal.scss'],
})
export class BookSlotModalComponent implements OnInit {
  readonly svc = inject(CheckoutService);

  // Pass serviceId from parent: <app-book-slot-modal [serviceId]="..." />
  serviceId = input.required<number>();

  close = output<void>();

  dates  = signal<AvailableDateResponseDto[]>([]);
  slots  = signal<AvailableSlotResponseDto[]>([]);
  loading = signal<boolean>(false);

  selectedDate = signal<AvailableDateResponseDto | null>(null);
  selectedSlot = signal<AvailableSlotResponseDto | null>(null);

  ngOnInit(): void {
    this.loading.set(true);
    this.svc.getAvailableDates(this.serviceId()).subscribe({
      next: (dates) => {
        this.dates.set(dates);
        // Auto-select first available date
        const first = dates.find(d => d.isAvailable) ?? null;
        if (first) this.selectDate(first);
        this.loading.set(false);
      },
      error: () => this.loading.set(false),
    });
  }

  selectDate(d: AvailableDateResponseDto): void {
    if (!d.isAvailable) return;
    this.selectedDate.set(d);
    this.selectedSlot.set(null);
    this.slots.set([]);

    this.svc.getAvailableSlots(this.serviceId(), d.date).subscribe({
      next: (slots) => this.slots.set(slots),
    });
  }

  selectSlot(s: AvailableSlotResponseDto): void {
    if (!s.isAvailable) return;
    this.selectedSlot.set(s);
  }

  save(): void {
    const d = this.selectedDate();
    const s = this.selectedSlot();
    if (!d || !s) return;
    this.svc.confirmSlot(this.svc.serviceName(),s.slotId,d.date);
    this.close.emit();
  }
}