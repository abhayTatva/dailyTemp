import { Component, inject, output, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CheckoutService } from '../../checkout.service';

@Component({
  selector: 'app-payment-method-modal',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './payment-method-modal.html',
  styleUrls: ['./payment-method-modal.scss'],
})
export class PaymentMethodModalComponent {
  readonly svc = inject(CheckoutService);

  close = output<void>();

  selected = signal<string | null>(this.svc.selectedPayment());

  select(m: string): void { this.selected.set(m); }

  save(): void {
    if (!this.selected()) return;
    this.svc.confirmPayment(this.selected()!);
    this.close.emit();
  }
}
