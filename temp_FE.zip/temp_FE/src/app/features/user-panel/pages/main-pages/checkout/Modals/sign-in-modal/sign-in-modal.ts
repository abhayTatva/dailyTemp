import { Component, EventEmitter, Output, output } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormBuilder, Validators, FormGroup } from '@angular/forms';
import { SendOtpService } from '../../../../../services/send-otp-service/send-otp-service';
@Component({
  selector: 'app-sign-in-modal',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule],
  templateUrl: './sign-in-modal.html',
  styleUrls: ['./sign-in-modal.scss']
})
export class SignInModalComponent {
  @Output() showToast = new EventEmitter<{ message: string; type: 'success' | 'error' }>();
  close = output<void>();
  otpSent = output<string>();

  form!: FormGroup;

  constructor(private fb: FormBuilder , private sendOtpService: SendOtpService) {
    this.form = this.fb.group({
      name: ['', [Validators.required, Validators.maxLength(20)]],
      email: ['', [Validators.required, Validators.email]]
    });
  }

  sendOtp() {
    if (this.form.invalid) {
      this.form.markAllAsTouched();
      return;
    }
      const email = this.form.value.email!;
      sessionStorage.setItem("email", this.form.get('email')?.value,);
      sessionStorage.setItem("name", this.form.get('name')?.value);
      
      this.sendOtpService.sendOtp(this.form.get('email')?.value, this.form.get('name')?.value).subscribe({
        next: () => {
          this.showToast.emit({
            message: 'Otp send Successfully!',
            type: 'success'
          });
          this.otpSent.emit(email);
        },
        error: (err : any) => { console.log("Error occured", err) }
      });
  }
}