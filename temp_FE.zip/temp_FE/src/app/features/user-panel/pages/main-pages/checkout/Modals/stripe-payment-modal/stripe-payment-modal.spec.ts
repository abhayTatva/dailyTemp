import { ComponentFixture, TestBed } from '@angular/core/testing';

import { StripePaymentModal } from './stripe-payment-modal';

describe('StripePaymentModal', () => {
  let component: StripePaymentModal;
  let fixture: ComponentFixture<StripePaymentModal>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [StripePaymentModal]
    })
    .compileComponents();

    fixture = TestBed.createComponent(StripePaymentModal);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
