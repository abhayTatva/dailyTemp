import {
  Component, Input, Output, EventEmitter,
  OnInit, OnDestroy, ChangeDetectorRef, inject
} from '@angular/core';
import { CommonModule } from '@angular/common';
import { loadStripe, Stripe, StripeElements, StripePaymentElement } from '@stripe/stripe-js';
import { environment } from '../../../../../../../../environments/environment';


@Component({
  selector: 'app-stripe-payment-modal',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './stripe-payment-modal.html',
  styleUrls: ['./stripe-payment-modal.scss'],
})
export class StripePaymentModalComponent implements OnInit, OnDestroy {
  @Input() clientSecret!: string;
  @Input() amountDisplay!: string;      // e.g. "$12.50"
  @Output() close          = new EventEmitter<void>();
  @Output() paymentSuccess = new EventEmitter<void>();
  @Output() paymentError   = new EventEmitter<string>();

  private cdr = inject(ChangeDetectorRef);

  private stripe:         Stripe | null = null;
  private elements:       StripeElements | null = null;
  private paymentElement: StripePaymentElement | null = null;

  isLoading    = true;
  isProcessing = false;
  errorMessage: string | null = null;

  async ngOnInit() {
    this.stripe = await loadStripe(environment.stripePublishableKey);
    if (!this.stripe) {
      this.errorMessage = 'Payment system failed to load. Please try again.';
      this.isLoading = false;
      this.cdr.markForCheck();
      return;
    }

    this.elements = this.stripe.elements({
      clientSecret: this.clientSecret,
      appearance: { theme: 'stripe' },
    });

    this.paymentElement = this.elements.create('payment');
    this.paymentElement.mount('#stripe-payment-element');
    this.paymentElement.on('ready', () => {
      this.isLoading = false;
      this.cdr.markForCheck();
    });
  }

  ngOnDestroy() {
    this.paymentElement?.unmount();
  }

  async submit() {
    if (!this.stripe || !this.elements || this.isProcessing) return;

    this.isProcessing = true;
    this.errorMessage = null;
    this.cdr.markForCheck();

    const { error } = await this.stripe.confirmPayment({
      elements: this.elements,
      redirect: 'if_required',
    });

    if (error) {
      this.errorMessage = error.message ?? 'Payment failed. Please try again.';
      this.isProcessing = false;
      this.cdr.markForCheck();
      this.paymentError.emit(this.errorMessage);
    } else {
      // Payment confirmed — webhook will mark DB as Paid asynchronously
      this.paymentSuccess.emit();
    }
  }
}