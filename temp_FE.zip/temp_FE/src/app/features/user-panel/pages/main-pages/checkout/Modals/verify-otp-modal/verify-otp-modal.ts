import { Component, EventEmitter, Output, output, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SendOtpService } from '../../../../../services/send-otp-service/send-otp-service';

@Component({
  selector: 'app-verify-otp-modal',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './verify-otp-modal.html',
  styleUrls: ['./verify-otp-modal.scss']
})
export class VerifyOtpModalComponent {
  @Output() showToast = new EventEmitter<{ message: string; type: 'success' | 'error' }>();
  constructor (private sendOtpService: SendOtpService){}
  close = output<void>();
  verified = output<string>();

  otp = signal('');

  verify() {
    if (this.otp().length !== 4) {
      return;
    }
    const name = sessionStorage.getItem("name")!;
    const email = sessionStorage.getItem("email")!;

    this.sendOtpService.verifyOtp(name, email, this.otp()).subscribe({
      next: (res:any) => {
        localStorage.setItem("user_token", res.token);
        this.verified.emit(email);
      },
      error: (err : any) => {
        this.showToast.emit({
          message: 'Invalid Otp !',
          type: 'error'
        }); 
      }
    });
  }
}