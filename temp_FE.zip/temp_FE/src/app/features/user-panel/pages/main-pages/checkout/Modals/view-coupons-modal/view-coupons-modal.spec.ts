import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ViewCouponsModal } from './view-coupons-modal';

describe('ViewCouponsModal', () => {
  let component: ViewCouponsModal;
  let fixture: ComponentFixture<ViewCouponsModal>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [ViewCouponsModal]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ViewCouponsModal);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
