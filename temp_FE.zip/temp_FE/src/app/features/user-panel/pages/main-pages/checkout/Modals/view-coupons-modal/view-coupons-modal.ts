import { Component, inject, input, output } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CheckoutService } from '../../checkout.service';

@Component({
  selector: 'app-view-coupons-modal',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './view-coupons-modal.html',
  styleUrls: ['./view-coupons-modal.scss'],
})
export class ViewCouponsModalComponent {
  readonly svc = inject(CheckoutService);
  serviceId    = input.required<number>();
  close        = output<void>();
}