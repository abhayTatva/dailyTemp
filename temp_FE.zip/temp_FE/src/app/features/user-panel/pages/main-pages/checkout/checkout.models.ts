// ── Address ───────────────────────────────────────────────────
export interface SavedAddress {
  id?:          number;       // ← ADD: needed for UserAddressId in booking
  latitude:     number;
  longitude:    number;
  fullAddress:  string;
  houseNumber:  string;
  landmark?:    string;
  label:        number;
  customLabel?: string;
}

// ── Slot ──────────────────────────────────────────────────────
export interface AvailableDateResponseDto {
  date:        string;
  displayDate: string;
  isAvailable: boolean;
}

export interface AvailableSlotResponseDto {
  slotId:      number;
  startTime:   string;
  isAvailable: boolean;
}

// ── Checkout Summary ──────────────────────────────────────────
export interface CouponSummaryDto {
  id:                  number;
  couponCode:          string;
  couponDescription:   string | null;
  discountPercentage:  number;
}

export interface CheckoutSummaryResponseDto {
  serviceId:        number;
  serviceTypeId:    number;   // ← ADD: needed for booking request
  serviceName:      string;
  serviceDuration:  string;
  serviceAmount:    number;
  taxPercentage:    number;
  taxAmount:        number;
  total:            number;
  currency:         string;

  serviceAmountInr: number;
  taxAmountInr:     number;
  totalInr:         number;
  exchangeRate:     number;

  availableCoupons: CouponSummaryDto[];
}

export interface ApplyCouponRequestDto {
  offerId:   number;
  serviceId: number;
}

export interface ApplyCouponResponseDto {
  offerId:                       number;
  couponCode:                    string;
  couponDescription:             string | null;
  discountPercentage:            number;
  serviceAmount:                 number;
  taxAmount:                     number;
  discountAmount:                number;
  totalAmountAfterDiscount:      number;
  currency:                      string;

  discountAmountInr:             number;
  totalAmountAfterDiscountInr:   number;
  exchangeRate:                  number;
}

// ── Booking ───────────────────────────────────────────────────
export interface CreateBookingRequestDto {
  serviceId:     number;
  serviceTypeId: number;
  userAddressId: number;
  serviceSlotId: number;
  bookingDate:   string;        // "YYYY-MM-DD"
  paymentMethod: number;        // 0 = Cash, 1 = Card
  offerId?:      number | null;
}

export interface CreateBookingResponseDto {
  bookingId:     number;
  bookingNumber: string;
  paymentMethod: number;
  clientSecret?: string;        // present only for Card
  amount:        number;
  currency:      string;
}