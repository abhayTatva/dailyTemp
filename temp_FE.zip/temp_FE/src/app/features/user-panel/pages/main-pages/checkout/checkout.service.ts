import { Injectable, signal, computed } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { environment } from '../../../../../../environments/environment';
import {
  SavedAddress,
  AvailableDateResponseDto,
  AvailableSlotResponseDto,
  CheckoutSummaryResponseDto,
  ApplyCouponRequestDto,
  ApplyCouponResponseDto,
  CreateBookingRequestDto,
  CreateBookingResponseDto,
} from './checkout.models';
import { catchError, Observable, tap, throwError } from 'rxjs';

@Injectable({ providedIn: 'root' })
export class CheckoutService {
  private readonly slotsUrl    = `${environment.apiBaseUrl}/slots`;
  private readonly checkoutUrl = `${environment.apiBaseUrl}/checkout`;

  constructor(private http: HttpClient) {}

  // ── Address state ─────────────────────────────────────────────
  savedAddresses     = signal<SavedAddress[]>([]);
  isLoadingAddresses = signal(false);
  isSavingAddress    = signal(false);
  saveAddressError   = signal<string | null>(null);
  pendingMapLocation = signal<{ lat: number; lng: number; address: string } | null>(null);

  setPendingMapLocation(loc: { lat: number; lng: number; address: string } | null): void {
    this.pendingMapLocation.set(loc);
  }

  readonly paymentMethods = ['Debit/Credit Card', 'Cash'];

  // ── Core phase signals ────────────────────────────────────────
  readonly phase           = signal<number>(0);
  readonly userEmail       = signal<string | null>(null);
  readonly selectedAddress = signal<SavedAddress | null>(null);
  readonly selectedSlot    = signal<string | null>(null);    // display label
  readonly selectedSlotId  = signal<number | null>(null);    // ← NEW
  readonly selectedDate    = signal<string | null>(null);    // ← NEW  "YYYY-MM-DD"
  readonly selectedPayment = signal<string | null>(null);

  // ── Summary signals ───────────────────────────────────────────
  readonly summary      = signal<CheckoutSummaryResponseDto | null>(null);
  readonly appliedCoupon = signal<ApplyCouponResponseDto | null>(null);

  // ── Computed ──────────────────────────────────────────────────
  readonly serviceTypeId    = computed(() => this.summary()?.serviceTypeId ?? 0);  // ← NEW
  readonly serviceName      = computed(() => this.summary()?.serviceName ?? '');
  readonly serviceDuration  = computed(() => this.summary()?.serviceDuration ?? '');
  readonly serviceAmount    = computed(() => this.summary()?.serviceAmount ?? 0);
  readonly taxAmount        = computed(() => this.summary()?.taxAmount ?? 0);
  readonly taxPercentage    = computed(() => this.summary()?.taxPercentage ?? 0);
  readonly total            = computed(() => this.summary()?.total ?? 0);
  readonly coupons          = computed(() => this.summary()?.availableCoupons ?? []);
  readonly currency         = computed(() => this.summary()?.currency ?? 'USD');

  readonly discountAmount = computed(() => this.appliedCoupon()?.discountAmount ?? 0);
  readonly amountToPay    = computed(
    () => this.appliedCoupon()?.totalAmountAfterDiscount ?? this.total()
  );

  readonly serviceAmountInr = computed(() => this.summary()?.serviceAmountInr ?? 0);
  readonly taxAmountInr     = computed(() => this.summary()?.taxAmountInr ?? 0);
  readonly totalInr         = computed(() => this.summary()?.totalInr ?? 0);

  readonly discountAmountInr  = computed(() => this.appliedCoupon()?.discountAmountInr ?? 0);
  readonly amountToPayInr     = computed(
    () => this.appliedCoupon()?.totalAmountAfterDiscountInr ?? this.totalInr()
  );

  // ── API calls ─────────────────────────────────────────────────
  getSummary(serviceId: number): Observable<CheckoutSummaryResponseDto> {
    return this.http.get<CheckoutSummaryResponseDto>(`${this.checkoutUrl}/summary/${serviceId}`);
  }

  applyCoupon(dto: ApplyCouponRequestDto): Observable<ApplyCouponResponseDto> {
    return this.http.post<ApplyCouponResponseDto>(`${this.checkoutUrl}/apply-coupon`, dto);
  }

  getAvailableDates(serviceId: number): Observable<AvailableDateResponseDto[]> {
    const params = new HttpParams().set('serviceId', serviceId.toString());
    return this.http.get<AvailableDateResponseDto[]>(`${this.slotsUrl}/dates`, { params });
  }

  getAvailableSlots(serviceId: number, date: string): Observable<AvailableSlotResponseDto[]> {
    const params = new HttpParams().set('serviceId', serviceId.toString()).set('date', date);
    return this.http.get<AvailableSlotResponseDto[]>(`${this.slotsUrl}/available`, { params });
  }

  book(dto: CreateBookingRequestDto): Observable<CreateBookingResponseDto> {
    return this.http.post<CreateBookingResponseDto>(`${this.checkoutUrl}/book`, dto);
  }

  // ── State mutations ───────────────────────────────────────────
  signIn(email: string): void {
    this.userEmail.set(email);
    if (this.phase() < 1) this.phase.set(1);
  }

  signOut(): void {
    this.userEmail.set(null);
    this.phase.set(0);
  }

  confirmAddress(addr: SavedAddress): void {
    this.selectedAddress.set(addr);
    if (this.phase() < 2) this.phase.set(2);
  }

  // ← UPDATED: now accepts slotId + date so booking request is complete
  confirmSlot(displayLabel: string, slotId: number, date: string): void {
    this.selectedSlot.set(displayLabel);
    this.selectedSlotId.set(slotId);
    this.selectedDate.set(date);
    if (this.phase() < 3) this.phase.set(3);
  }

  confirmPayment(method: string): void {
    this.selectedPayment.set(method);
    if (this.phase() < 4) this.phase.set(4);
  }

  resetForNewService(): void {
    this.summary.set(null);
    this.appliedCoupon.set(null);
    this.selectedAddress.set(null);
    this.selectedSlot.set(null);
    this.selectedSlotId.set(null);
    this.selectedDate.set(null);
    this.selectedPayment.set(null);
    this.phase.set(this.userEmail() ? 1 : 0);
  }

  toggleCoupon(offerId: number, serviceId: number): void {
    if (this.appliedCoupon()?.offerId === offerId) {
      this.appliedCoupon.set(null);
      return;
    }
    this.applyCoupon({ offerId, serviceId }).subscribe({
      next: (res) => this.appliedCoupon.set(res),
    });
  }

  loadSavedAddresses(): void {
    this.isLoadingAddresses.set(true);
    this.http.get<SavedAddress[]>(`${environment.apiBaseUrl}/user-addresses`).subscribe({
      next: (data) => {
        this.savedAddresses.set(data);
        this.isLoadingAddresses.set(false);
      },
      error: () => this.isLoadingAddresses.set(false),
    });
  }

  saveAddress(addr: SavedAddress): Observable<any> {
    this.isSavingAddress.set(true);
    this.saveAddressError.set(null);
    const body = {
      latitude:    addr.latitude ?? 0,
      longitude:   addr.longitude ?? 0,
      fullAddress: addr.fullAddress,
      houseNumber: addr.houseNumber ?? '',
      landmark:    addr.landmark ?? '',
      label:       addr.label ?? 0,
      customLabel: addr.customLabel ?? '',
    };
    return this.http.post(`${environment.apiBaseUrl}/user-addresses/enter-address`, body).pipe(
      tap(() => {
        this.savedAddresses.update(list => [addr, ...list]);
        this.confirmAddress(addr);
        this.isSavingAddress.set(false);
      }),
      catchError((err) => {
        this.saveAddressError.set('Failed to save address.');
        this.isSavingAddress.set(false);
        return throwError(() => err);
      })
    );
  }

  reverseGeocode(lat: number, lng: number) {
    return this.http.get(
      `${environment.apiBaseUrl}/user-addresses/reverse-geocode?lat=${lat}&lng=${lng}`
    );
  }
}