import {
  Component, inject, signal, OnInit,
  ViewChild, ElementRef, ChangeDetectorRef,
} from '@angular/core';
import { CommonModule } from '@angular/common';
import { ActivatedRoute, Router, RouterLink } from '@angular/router';
import { AddressListModalComponent } from './Modals/address-list-modal/address-list-modal';
import { AddressMapModalComponent } from './Modals/address-map-modal/address-map-modal';
import { BookSlotModalComponent } from './Modals/book-slot-modal/book-slot-modal';
import { PaymentMethodModalComponent } from './Modals/payment-method-modal/payment-method-modal';
import { CheckoutService } from './checkout.service';
import { SignInModalComponent } from './Modals/sign-in-modal/sign-in-modal';
import { VerifyOtpModalComponent } from './Modals/verify-otp-modal/verify-otp-modal';
import { ViewCouponsModalComponent } from './Modals/view-coupons-modal/view-coupons-modal';
import { AddressSearchModalComponent, AddressPickEvent }
  from './Modals/address-search-modal/address-search-modal';
import { StripePaymentModalComponent } from './Modals/stripe-payment-modal/stripe-payment-modal';
import { ToastMessage } from '../../../../../shared/components/toast-message/toast-message';
import { jwtDecode } from 'jwt-decode';
import { CreateBookingResponseDto } from './checkout.models';

type ModalType =
  | 'sign-in' | 'verify-otp' | 'address-list' | 'address-search'
  | 'address-map' | 'book-slot' | 'payment-method' | 'coupons'
  | 'stripe-payment' | null;

@Component({
  selector: 'app-checkout',
  standalone: true,
  imports: [
    CommonModule, RouterLink,
    SignInModalComponent, VerifyOtpModalComponent,
    AddressListModalComponent, AddressMapModalComponent,
    BookSlotModalComponent, PaymentMethodModalComponent,
    ViewCouponsModalComponent, AddressSearchModalComponent,
    StripePaymentModalComponent, ToastMessage,
  ],
  templateUrl: './checkout.html',
  styleUrls: ['./checkout.scss'],
})
export class CheckoutComponent implements OnInit {
  toastMessage: string | null = null;
  toastType: 'success' | 'error' = 'success';
  toastTrigger = 0;

  readonly svc = inject(CheckoutService);
  private readonly cdr = inject(ChangeDetectorRef);
  private readonly router = inject(Router);

  activeModal = signal<ModalType>(null);
  serviceId = signal<number>(0);

  // Held between book() call and Stripe modal result
  pendingBooking = signal<CreateBookingResponseDto | null>(null);
  isBooking = signal<boolean>(false);

  constructor(private route: ActivatedRoute) {
    this.route.paramMap.subscribe(params => {
      this.serviceId.set(Number(params.get('id')));
    });
  }

  ngOnInit() {
    this.svc.resetForNewService();
    const token = localStorage.getItem('user_token');
    if (token) {
      try {
        const decoded: any = jwtDecode(token);
        if (decoded.exp < Date.now() / 1000) {
          localStorage.removeItem('user_token');
        } else {
          this.svc.signIn(decoded.email);
        }
      } catch {
        localStorage.removeItem('user_token');
      }
    }
    this.route.queryParams.subscribe(params => {
      const serviceTypeId = +params['serviceTypeId'];
    
      this.svc.getSummary(this.serviceId()).subscribe({
        next: (res) => {
          this.svc.summary.set({
            ...res,
            serviceTypeId: serviceTypeId   // ✅ manually add it
          });
        },
        error: (err) => console.error('getSummary failed:', err),
      });
    });
  }

  @ViewChild('couponStrip') couponStrip!: ElementRef<HTMLDivElement>;
  private readonly SCROLL_AMOUNT = 234;
  canScrollLeft = signal<boolean>(false);
  canScrollRight = signal<boolean>(true);

  onStripScroll() { this.updateArrowState(); }

  private updateArrowState() {
    const el = this.couponStrip?.nativeElement;
    if (!el) return;
    this.canScrollLeft.set(el.scrollLeft > 0);
    this.canScrollRight.set(el.scrollLeft + el.clientWidth < el.scrollWidth - 1);
    this.cdr.markForCheck();
  }

  scrollCoupons(direction: 1 | -1) {
    const el = this.couponStrip?.nativeElement;
    if (!el) return;
    el.scrollBy({ left: direction * this.SCROLL_AMOUNT, behavior: 'smooth' });
    setTimeout(() => this.updateArrowState(), 320);
  }

  openModal(m: ModalType) { this.activeModal.set(m); }
  closeModal() { this.activeModal.set(null); }
  onAddNew() { this.openModal('address-search'); }
  onGoBack() { this.openModal('address-list'); }
  goBack() { window.history.back(); }

  onLoginSuccess(email: string) {
    this.handleToast({ message: 'Logged in successfully', type: 'success' });
    this.svc.signIn(email);
    this.closeModal();
  }

  onAddressPicked(event: AddressPickEvent) {
    this.svc.setPendingMapLocation(event);
    this.openModal('address-map');
  }

  // ── Pay ───────────────────────────────────────────────────────
  pay() {
    const addr = this.svc.selectedAddress();
    const slotId = this.svc.selectedSlotId();
    const date = this.svc.selectedDate();
    const method = this.svc.selectedPayment();

    if (!addr?.id || !slotId || !date || !method) {
      console.log(slotId);
      console.log(date);
      this.handleToast({ message: 'Please complete all steps before paying', type: 'error' });
      return;
    }

    this.isBooking.set(true);

    this.svc.book({
      serviceId: this.serviceId(),
      serviceTypeId: this.svc.serviceTypeId(),
      userAddressId: addr.id,
      serviceSlotId: slotId,
      bookingDate: date,
      paymentMethod: method === 'Cash' ? 0 : 1,
      offerId: this.svc.appliedCoupon()?.offerId ?? null,
    }).subscribe({
      next: (res) => {
        this.isBooking.set(false);
        if (res.paymentMethod === 0) {
          // Cash — booking confirmed immediately
          this.handleToast({ message: 'Booking confirmed!', type: 'success' });
          setTimeout(() =>
            this.router.navigate(['/layout/booking-confirmation', res.bookingId]), 1200);
        } else {
          // Card — open Stripe modal with clientSecret
          this.pendingBooking.set(res);
          this.openModal('stripe-payment');
        }
      },
      error: () => {
        this.isBooking.set(false);
        this.handleToast({ message: 'Booking failed. Please try again.', type: 'error' });
      },
    });
  }

  // ── Stripe modal callbacks ────────────────────────────────────
  onStripePaymentSuccess() {
    this.closeModal();
    const booking = this.pendingBooking();
    this.handleToast({ message: 'Payment successful! Booking confirmed.', type: 'success' });
    setTimeout(() =>
      this.router.navigate(['/layout/booking-confirmation', booking?.bookingId]), 1200);
  }

  onStripePaymentError(errorMsg: string) {
    this.handleToast({ message: errorMsg, type: 'error' });
    // Modal stays open so user can retry or change method
  }

  onStripeModalClose() {
    this.closeModal();
    this.pendingBooking.set(null);
  }

  handleToast(event: { message: string; type: 'success' | 'error' }) {
    this.toastMessage = event.message;
    this.toastType = event.type;
    this.toastTrigger++;
  }

  // Helper for template
  get stripeAmountDisplay(): string {
    const b = this.pendingBooking();
    if (!b) return '';
    return `$${b.amount.toFixed(2)}`;
  }
}