import { ComponentFixture, TestBed } from '@angular/core/testing';

import { HomeAllServices } from './home-all-services';

describe('HomeAllServices', () => {
  let component: HomeAllServices;
  let fixture: ComponentFixture<HomeAllServices>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [HomeAllServices]
    })
    .compileComponents();

    fixture = TestBed.createComponent(HomeAllServices);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
