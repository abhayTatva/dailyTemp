import { ComponentFixture, TestBed } from '@angular/core/testing';

import { HomeJoinUs } from './home-join-us';

describe('HomeJoinUs', () => {
  let component: HomeJoinUs;
  let fixture: ComponentFixture<HomeJoinUs>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [HomeJoinUs]
    })
    .compileComponents();

    fixture = TestBed.createComponent(HomeJoinUs);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
