import { Component } from '@angular/core';
import { RouterLink, RouterLinkActive } from '@angular/router';

@Component({
  selector: 'app-home-join-us',
  imports: [RouterLink, RouterLinkActive],
  templateUrl: './home-join-us.html',
  styleUrl: './home-join-us.css',
})
export class HomeJoinUs {

}
