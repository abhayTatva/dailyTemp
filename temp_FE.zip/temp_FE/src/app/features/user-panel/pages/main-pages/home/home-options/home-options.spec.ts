import { ComponentFixture, TestBed } from '@angular/core/testing';

import { HomeOptions } from './home-options';

describe('HomeOptions', () => {
  let component: HomeOptions;
  let fixture: ComponentFixture<HomeOptions>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [HomeOptions]
    })
    .compileComponents();

    fixture = TestBed.createComponent(HomeOptions);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
