import { CommonModule } from '@angular/common';
import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { Router, RouterLink } from '@angular/router';
import { ServiceType } from '../../../../../../Interfaces/ServiceType';
import { environment } from '../../../../../../../environments/environment';
import { ServiceTypes } from '../../../../../../services/servicetype';
import { Route } from '@angular/router';

@Component({
  selector: 'app-home-options',
  standalone: true,
  imports: [CommonModule, RouterLink],
  templateUrl: './home-options.html',
  styleUrl: './home-options.css',
})
export class HomeOptions implements OnInit {

  @ViewChild('slider') slider!: ElementRef;

  scroll(direction: 'left' | 'right') {
    const sliderEl = this.slider.nativeElement;
    
    // Get the width of the first card
    const firstCard = sliderEl.querySelector('.options-card');
    if (!firstCard) return;

    const cardWidth = firstCard.offsetWidth + 70; 
  
    if (direction === 'left') {
      sliderEl.scrollLeft -= cardWidth;
    } else {
      sliderEl.scrollLeft += cardWidth;
    }
  }
  services: ServiceType[] = [];

  baseUrl2 = `${environment.apiBaseUrl2}`;

  constructor(private serviceTypeService: ServiceTypes,private router:Router) {}

  ngOnInit(): void {
    this.loadServices();
  }

  onImageError(event: any) {
    event.target.src = 'assets/images/image_ERR_01.png';
  }
  loadServices() {
    this.serviceTypeService.getAll().subscribe({
      next: (data) => {
        this.services = data;
      },
      error: (err) => {
        console.error("Error loading services", err);
      }
    });
  }
  goToListing(id:number,name:string)
  {
    this.router.navigate(['/layout/service-listing', id],
      { queryParams: { name } }
    );

  }
}