import { ComponentFixture, TestBed } from '@angular/core/testing';

import { HomePopularProducts } from './home-popular-products';

describe('HomePopularProducts', () => {
  let component: HomePopularProducts;
  let fixture: ComponentFixture<HomePopularProducts>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [HomePopularProducts]
    })
    .compileComponents();

    fixture = TestBed.createComponent(HomePopularProducts);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
