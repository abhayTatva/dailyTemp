
import { Component, ElementRef, ViewChild, AfterViewInit, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';

import { ParticularService } from '../../../../../../services/particularservice';
import { ServiceWithImage } from '../../../../../../Interfaces/Service';
import { environment } from '../../../../../../../environments/environment';
import { Button3 } from '../../../../shared/components/button3/button3';
import { Router } from '@angular/router';


@Component({
  selector: 'app-home-popular-products',
  imports: [CommonModule,Button3],
  templateUrl: './home-popular-products.html',
  styleUrl: './home-popular-products.css',
})
export class HomePopularProducts implements AfterViewInit, OnInit{

  baseUrl2 =`${environment.apiBaseUrl2}`;
  @ViewChild('slider') slider!: ElementRef;

  showLeftArrow = false;
  showRightArrow = true;

  services: ServiceWithImage[] = [];

  constructor(private serviceApi: ParticularService,private router:Router) {}

  ngOnInit() {
    this.loadServices();
  }

  loadServices() {
    this.serviceApi.getPopularService(10).subscribe({
      next: (res) => {
        this.services = res;
      },
      error: (err) => {
        console.error('Error loading services', err);
      }
    });
  }

  ngAfterViewInit() {
    setTimeout(() => this.checkArrows(), 500);
  }

  onScroll() {
    this.checkArrows();
  }

  checkArrows() {
    const el = this.slider?.nativeElement;
    if (!el) return;

    this.showLeftArrow = el.scrollLeft > 10;
    this.showRightArrow =
      el.scrollLeft + el.clientWidth < el.scrollWidth - 10;
  }

  scroll(direction: 'left' | 'right') {

    const sliderEl = this.slider.nativeElement;
    const card = sliderEl.querySelector('.service-card-wrapper');

    if (card) {

      const moveDistance = card.offsetWidth;

      sliderEl.scrollBy({
        left: direction === 'left' ? -moveDistance : moveDistance,
        behavior: 'smooth'
      });

      setTimeout(() => this.checkArrows(), 500);
    }
  }
  onImageError(event: any) {
    event.target.src = 'assets/images/image_ERR_03.jpg';
  }

  goToDetails(id:number)
  {
    console.log(id)
    this.router.navigate(['/layout/service-details-demo',id]);
  }
  goToServices()
  {
    this.router.navigate(['/layout/service'])
  }
}
