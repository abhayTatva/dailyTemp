import { Component, OnInit } from '@angular/core';
import { Subject, debounceTime } from 'rxjs';
import { SearchService } from '../../../../../../services/searchservice';
import { Router } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { ParticularService } from '../../../../../../services/particularservice';
import { CountFormatPipe } from '../../../../../../shared/components/pipe/count-format-pipe';

@Component({
  selector: 'app-home-search',
  standalone: true,
  imports: [FormsModule, CommonModule,CountFormatPipe],
  templateUrl: './home-search.html',
  styleUrl: './home-search.css',
})
export class HomeSearch implements OnInit {

  searchTerm = '';
  results: any[] = [];
  isSearching = false;

  services: any[] = [];
  serviceCount = 0;

  private searchSubject = new Subject<string>();

  constructor(
    private searchService: SearchService,
    private router: Router,
    private serviceApi: ParticularService
  ) {}

  ngOnInit() {

    this.serviceApi.getAllServices().subscribe(res => {
      this.services = res;
      this.serviceCount = res.length;
    });

    this.searchSubject.pipe(debounceTime(300)).subscribe(term => {

      if (term.length < 2) {
        this.results = [];
        this.isSearching = false;
        return;
      }

      this.isSearching = true;

      this.searchService.searchServices(term)
      .subscribe(res => {
        this.results = res;
      });

    });
  }

  onSearch() {
    this.isSearching = true;
    this.searchSubject.next(this.searchTerm);
  }

  searchNow() {
    if (this.results.length > 0) {
      this.goToService(this.results[0]);
    }
  }

  goToService(service: any) {

    this.results = [];

    this.router.navigate(
      ['/layout/service-details-demo', service.serviceId]
    );
  }
}