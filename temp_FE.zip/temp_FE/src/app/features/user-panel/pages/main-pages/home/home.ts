import { Component } from '@angular/core';
import { HomeSearch } from './home-search/home-search';
import { HomeJoinUs } from './home-join-us/home-join-us';
import { HomeOptions } from './home-options/home-options';
import { HomePopularProducts } from './home-popular-products/home-popular-products';
import { HomeAllServices } from './home-all-services/home-all-services';

@Component({
  selector: 'app-home',
  imports: [HomeSearch,HomeJoinUs,HomeOptions,HomePopularProducts,HomeAllServices],
  templateUrl: './home.html',
  styleUrl: './home.css',
})
export class Home {

}
