import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ServiceDetailsDemo } from './service-details-demo';

describe('ServiceDetailsDemo', () => {
  let component: ServiceDetailsDemo;
  let fixture: ComponentFixture<ServiceDetailsDemo>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [ServiceDetailsDemo]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ServiceDetailsDemo);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
