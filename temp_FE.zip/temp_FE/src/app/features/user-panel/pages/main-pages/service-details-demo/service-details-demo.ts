import { Component } from '@angular/core';

@Component({
  selector: 'app-service-details-demo',
  imports: [],
  templateUrl: './service-details-demo.html',
  styleUrl: './service-details-demo.css',
})
export class ServiceDetailsDemo {

}
