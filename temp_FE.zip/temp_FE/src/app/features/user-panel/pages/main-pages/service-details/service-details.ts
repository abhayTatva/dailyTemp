import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { ParticularService } from '../../../../../services/particularservice';
import { ServiceDetail } from '../../../../../Interfaces/ServiceDetail';
import { CommonModule } from '@angular/common';
import { Button3 } from '../../../shared/components/button3/button3';
import { environment } from '../../../../../../environments/environment';
import { Route } from '@angular/router';
import { switchMap } from 'rxjs/operators';
@Component({
  selector: 'app-service-details',
  standalone: true,
  imports: [CommonModule,Button3],
  templateUrl: './service-details.html',
  styleUrl: './service-details.css',
})
export class ServiceDetails implements OnInit {
  constructor(private route:ActivatedRoute,private particularServiceApi:ParticularService,private router:Router){}

service!:ServiceDetail;
otherServices:any;
ngOnInit(): void {

  this.route.paramMap.subscribe(params=>{
    const id = Number(params.get('id'));
    this.loadService(id);
  });


}
loadService(id:number){
  this.particularServiceApi.getServiceDetail(id).pipe(
    switchMap(service=>{
      this.service = service;
      console.log(this.service);
      return this.particularServiceApi.getServicesBySubCategory(service.subCategoryId);
    })
  ).subscribe(res=>{
    this.otherServices = res.filter(s=>s.id !== this.service.id);
    console.log(this.otherServices);
  });
}
  selectedPreviewImg: string | null = null;
  currentImgIndex: number | null = null;
  baseUrl2 = environment.apiBaseUrl2;
 
  
  openPreview(index: number) {
    this.currentImgIndex = index;
    document.body.style.overflow = 'hidden';
  }

  closePreview() {
    this.currentImgIndex = null;
    document.body.style.overflow = 'auto';
  }

  navigate(event: Event, direction: number) {
    event.stopPropagation(); 
    if (this.currentImgIndex !== null) {
      const total = this.service.images.length;
   
      this.currentImgIndex = (this.currentImgIndex + direction + total) % total;
    }
  }
  goToOthersDetails(id:number)
  {
    console.log(id);
    this.router.navigate(['/layout/service-details', id]);
  }
  goToCheckout(id:number,serviceTypeId:number)
  {
    console.log("service id:"+id);
    this.router.navigate(['/layout/checkout',id],
        { queryParams: { serviceTypeId } });
  }
  name!:string;
  goToListing()
  {
    this.name=this.service.serviceType;
    this.router.navigate(['/layout/service-listing', this.service.serviceTypeId],
      { queryParams: { name:this.name } }
    );
  }
}