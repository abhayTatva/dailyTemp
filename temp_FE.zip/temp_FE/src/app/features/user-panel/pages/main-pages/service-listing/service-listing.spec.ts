import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ServiceListing } from './service-listing';

describe('ServiceListing', () => {
  let component: ServiceListing;
  let fixture: ComponentFixture<ServiceListing>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [ServiceListing]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ServiceListing);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
