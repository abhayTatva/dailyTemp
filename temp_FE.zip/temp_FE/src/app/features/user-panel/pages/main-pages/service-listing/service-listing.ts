
import { Component, OnInit } from '@angular/core';

import { CommonModule } from '@angular/common';
import { ActivatedRoute, Router } from '@angular/router';
import { Button3 } from '../../../shared/components/button3/button3';
import { environment } from '../../../../../../environments/environment';
import { ServiceTypes } from '../../../../../services/servicetype';
import { CategoryService } from '../../../../../services/categoryservice';
import { SubCategoryService } from '../../../../../services/subcategoryservice';
import { ParticularService } from '../../../../../services/particularservice';
import { CountFormatPipe } from '../../../../../shared/components/pipe/count-format-pipe';



@Component({
  selector: 'app-service-listing',
  standalone: true,
  imports: [CommonModule,Button3,CountFormatPipe],
  templateUrl: './service-listing.html',
  styleUrl: './service-listing.css',
})
export class ServiceListing implements OnInit {
  activeSubCategoryId: number = 10; // "Furnished Apartment"
  totalServices: number = 0;
  categories:CategoryGroup[]=[];
  constructor(private route: ActivatedRoute,
            private router:Router,
            private categoryService:CategoryService,
            private subCategoryService:SubCategoryService,
            private particularService:ParticularService) {}

    baseUrl2 = environment.apiBaseUrl2;
    currentServices: Service[] = [];
    currentSubCategoryName: string = '';
    serviceTypeName:string|null='';
    ngOnInit() {
      const serviceTypeId = this.route.snapshot.paramMap.get('id');
      this.route.queryParams.subscribe(params => {
        console.log(params);
        this.serviceTypeName = params['name'];
      });
      console.log(this.serviceTypeName);
      if(serviceTypeId)
      {
        this.loadCategories(Number(serviceTypeId));
        this.calculateTotalServices(Number(serviceTypeId));
      }
    }
    loadCategories(serviceTypeId:number)
    {
        this.categoryService.getByService(serviceTypeId).subscribe((cats:any[])=>{
          this.categories=cats.map(c=>({
            id: c.id,
            name: c.name,
            isExpanded: false,
            subCategories: []
          }));
          if(this.categories.length > 0){
            const firstCategory = this.categories[0];
            firstCategory.isExpanded = true;
      
            this.loadSubCategories(firstCategory);
          }
            
        
        })
    }
    loadSubCategories(category: CategoryGroup)
  {
    this.subCategoryService.getByCategory(category.id).subscribe((subs:any[])=>{

      category.subCategories = subs.map(s => ({
        id: s.id,
        name: s.name,
        serviceCount: 0,
        services: []
      }));

      if(category.subCategories.length > 0){
        const firstSub = category.subCategories[0];
        this.loadServices(firstSub);
      }

    });
  }
  loadServices(sub: SubCategoryGroup)
  {
    this.activeSubCategoryId = sub.id;
    this.currentSubCategoryName = sub.name;

    // clear previously loaded services
    this.currentServices = [];


    this.particularService.getServicesBySubCategory(sub.id).subscribe((services:any[])=>{

      this.currentServices = services.map(s => ({
        id: s.id,
        name: s.name,
        duration: s.duration + ' Min',
        price: s.price,
        description: 'Professional service delivered with quality, reliability, and attention to detail to meet your needs efficiently.',
        imagePath: s.imagePath,
        serviceTypeId:s.serviceTypeId
      }));

      sub.serviceCount = sub.services.length;

    });
  }

    toggleCategory(category: CategoryGroup) {
      category.isExpanded = !category.isExpanded;
      if(category.isExpanded && category.subCategories.length===0)
      {
        this.loadSubCategories(category);
      }
    }

    scrollToSubCategory(sub: SubCategoryGroup) {
      this.loadServices(sub);
    
      const element = document.getElementById('subcat-' + sub.id);
      if (element) {
        element.scrollIntoView({ behavior: 'smooth', block: 'start' });
      }
    
  }
  selectedServiceId:number|null=null;
  goToDetails(id:number)
  {
    this.selectedServiceId=id;
    this.router.navigate(['/layout/service-details-demo', id]);
  }

  goToCheckOut(id:number,serviceTypeId:number)
  {
    console.log("went to checkout");
    console.log("service id:"+id);
    console.log("service id:"+serviceTypeId);
    this.router.navigate(['/checkout',id],
        { queryParams: { serviceTypeId } });
  }

  calculateTotalServices(serviceTypeId: number) {

    this.totalServices = 0;

    this.categoryService.getByService(serviceTypeId).subscribe((cats: any[]) => {

      cats.forEach(category => {

        this.subCategoryService.getByCategory(category.id).subscribe((subs: any[]) => {

          subs.forEach(sub => {

            this.particularService.getServicesBySubCategory(sub.id)
            .subscribe((services: any[]) => {

              this.totalServices += services.length;

            });

          });

        });

      });

    });

  }

  getSubCategoryIcon(name: string): string {

    const key = name.toLowerCase();
  
    if (key.includes('clean')) return 'bi-stars';
    if (key.includes('bath')) return 'bi-droplet';
    if (key.includes('kitchen')) return 'bi-egg-fried';
    if (key.includes('electric')) return 'bi-lightning';
    if (key.includes('plumb')) return 'bi-tools';
    if (key.includes('paint')) return 'bi-brush';
    if (key.includes('ac')) return 'bi-snow';
    if (key.includes('repair')) return 'bi-wrench';
    if (key.includes('camera') || key.includes('cctv')) return 'bi-camera-video';
    if (key.includes('install')) return 'bi-hammer';
  
    return 'bi-house-fill'; 
  }
}




