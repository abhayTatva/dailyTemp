
import { CommonModule } from '@angular/common';
import { Component,OnInit } from '@angular/core';
import { Router } from "@angular/router";
import { ServiceType } from '../../../../../Interfaces/ServiceType';
import { ServiceTypes } from '../../../../../services/servicetype';
import { environment } from '../../../../../../environments/environment';
import { CountFormatPipe } from '../../../../../shared/components/pipe/count-format-pipe';

@Component({
  selector: 'app-service-provided',
  imports: [CommonModule,CountFormatPipe],
  templateUrl: './service-provided.html',
  styleUrl: './service-provided.css',
})
export class ServiceProvided implements OnInit {
  baseUrl2 = environment.apiBaseUrl2;
  serviceTypes:ServiceType[]=[];
  serviceTypesId:number | null=null;
  selectedServiceTypeId:number|null=null;

  constructor(private router:Router,private serviceTypeService:ServiceTypes){}

  ngOnInit():void{
    this.loadServiceTypes();
  }
  loadServiceTypes()
  {
    this.serviceTypeService.getAll().subscribe(res=>{
      this.serviceTypes=res;
    })

  }
  goToNext(id:number,name:string)
  {
    console.log(id,name);
    this.selectedServiceTypeId=id;
    this.router.navigate(['/layout/service-listing', id],
      { queryParams: { name } }
    );
   
  }

  onImageError(event: any) {
    event.target.src = 'assets/images/image_ERR_01.png';
  }
}
