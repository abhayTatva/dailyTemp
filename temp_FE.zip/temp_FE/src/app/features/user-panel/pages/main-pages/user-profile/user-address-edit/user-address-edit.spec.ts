import { ComponentFixture, TestBed } from '@angular/core/testing';

import { UserAddressEdit } from './user-address-edit';

describe('UserAddressEdit', () => {
  let component: UserAddressEdit;
  let fixture: ComponentFixture<UserAddressEdit>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [UserAddressEdit]
    })
    .compileComponents();

    fixture = TestBed.createComponent(UserAddressEdit);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
