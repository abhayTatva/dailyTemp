import { CommonModule } from '@angular/common';
import { HttpClient } from '@angular/common/http';
import { AfterViewInit, Component, Input } from '@angular/core';
import { FormBuilder, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { Button } from '../../../../../../shared/components/button/button';
import { WhiteButton } from '../../../../shared/components/white-button/white-button';
import * as L from 'leaflet';
import { CloseSearchModalService } from '../../../../services/close-search-modal-service/close-search-modal-service';
import { ToastService } from '../../../../services/toast-service/toast-service';

@Component({
  selector: 'app-user-address-edit',
  imports: [ReactiveFormsModule, CommonModule, Button, WhiteButton],
  templateUrl: './user-address-edit.html',
  styleUrl: './user-address-edit.css',
})
export class UserAddressEdit implements AfterViewInit {
  map!: L.Map;
  marker!: L.Marker;

  addressForm!: FormGroup;

  houseNumberEdit: string | null = null;
  landmarkEdit: string | null = null;
  customLabelEdit = "";
  fullAddressEdit = "";
  addressId: number | null = null;
  latitude: number = 0;
  longitude: number = 0;
  label: number = 0;

  errorMessage = '';
  errorMessageDisplay = false;

  @Input() locationEdit: any;

  constructor(private fb: FormBuilder, private router: Router, private http: HttpClient, private closeSearch: CloseSearchModalService, private toastService: ToastService) { }

  ngOnInit(): void {

    if (this.locationEdit) {
      this.landmarkEdit = this.locationEdit.landmark;
      this.houseNumberEdit = this.locationEdit.houseNumber;
      this.addressId = this.locationEdit.addressId;
      this.customLabelEdit = this.locationEdit.customLabel;
      this.fullAddressEdit = this.locationEdit.fullAddress;
      this.latitude = this.locationEdit.latitude;
      this.longitude = this.locationEdit.longitude;
    }

    this.addressForm = this.fb.group({
      house: [this.houseNumberEdit],
      landmark: [this.landmarkEdit]
    });
  }

  ngAfterViewInit(): void {
    this.initializeMap();
  }

  initializeMap() {
    this.map = L.map('map').setView([this.latitude, this.longitude], 13);

    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
      attribution: '© OpenStreetMap contributors'
    }).addTo(this.map);

    this.map.on('click', (e: any) => {
      const lat = e.latlng.lat;
      const lng = e.latlng.lng;

      this.setMarker(lat, lng);
      this.reverseGeocode(lat, lng);
    });
  }

  setMarker(lat: number, lng: number) {
    if (this.marker) {
      this.map.removeLayer(this.marker);
    }

    this.marker = L.marker([lat, lng]).addTo(this.map);

    this.latitude = lat;
    this.longitude = lng;
  }

  reverseGeocode(lat: number, lng: number) {
    this.http.get(`http://localhost:5025/api/user-addresses/reverse-geocode?lat=${lat}&lng=${lng}`)
      .subscribe((data: any) => {
        this.fullAddressEdit = data.fullAddress;
      });
  }

  //EDIT ADDRESS

  closeEditMenu() {
    this.closeSearch.setFormClose(false);
    this.router.navigate(['layout/profile']);
  }

  selectLabel(type: number) {
    this.label = type;
  }

  saveEditAddress() {
    if (this.addressForm.invalid) {
      this.errorMessageDisplay = true;
    }

    else {
      let houseValue = this.addressForm.get('house')?.value.trim();
      let landmarkValue = this.addressForm.get('landmark')?.value.trim();

      if (houseValue === '' || landmarkValue === '') {
        this.errorMessageDisplay = true;
        this.errorMessage = "Value cannot be empty or spaces";
        return;
      }

      if (!houseValue) {
        houseValue = this.houseNumberEdit;
      }

      if (!landmarkValue) {
        landmarkValue = this.landmarkEdit;
      }

      const payload = {
        houseNumber: houseValue,
        landmark: landmarkValue,
        fullAddress: this.fullAddressEdit,
        latitude: this.latitude,
        longitude: this.longitude,
      };

      this.http.patch(`http://localhost:5025/api/user-addresses/update-address/${this.addressId}`, payload)
        .subscribe({
          next: () => {
            this.toastService.show("Address Updated Successfully","success")
          },
          error: () => {
            this.toastService.show("Error Occured","error")
          }
        });
    }
  }
}
