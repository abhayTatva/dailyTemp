import { ComponentFixture, TestBed } from '@angular/core/testing';

import { UserAddressForm } from './user-address-form';

describe('UserAddressForm', () => {
  let component: UserAddressForm;
  let fixture: ComponentFixture<UserAddressForm>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [UserAddressForm]
    })
    .compileComponents();

    fixture = TestBed.createComponent(UserAddressForm);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
