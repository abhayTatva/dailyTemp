import { CommonModule } from '@angular/common';
import { HttpClient } from '@angular/common/http';
import { AfterViewInit, Component, EventEmitter, Input, OnInit, output, Output } from '@angular/core';
import { FormBuilder, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { Button } from '../../../../../../shared/components/button/button';
import { WhiteButton } from '../../../../shared/components/white-button/white-button';
import * as L from 'leaflet';
import { Router } from '@angular/router';
import { ToastService } from '../../../../services/toast-service/toast-service';

@Component({
  selector: 'app-user-address-form',
  imports: [ReactiveFormsModule, CommonModule, Button, WhiteButton],
  templateUrl: './user-address-form.html',
  styleUrl: './user-address-form.css',
})
export class UserAddressForm implements AfterViewInit {
  map!: L.Map;
  marker!: L.Marker;

  addressForm!: FormGroup;

  lat: number = 0;
  lng: number = 0;
  address: string = '';
  label: number = 0;

  errorMessage = '';
  errorMessageDisplay = false;

  @Input() location: any;
  @Output() backToSearch = new EventEmitter<void>();
  @Output() backToProfile = new EventEmitter<void>();

  constructor(private fb: FormBuilder, private router: Router, private http: HttpClient, private toastService: ToastService) { }

  ngOnInit(): void {
    this.addressForm = this.fb.group({
      house: ['', Validators.required],
      landmark: ['', Validators.required],
      customLabel: ['']
    });

    if (this.location) {
      this.address = this.location.address,
        this.lat = this.location.lat,
        this.lng = this.location.lon
    }
  }

  //MAP FUNCTIONS

  ngAfterViewInit(): void {
    this.initializeMap();
  }

  initializeMap() {
    if (!this.map) {
      this.map = L.map('map').setView([this.lat, this.lng], 20);


      L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        attribution: '© OpenStreetMap contributors'
      }).addTo(this.map);
    }
    else {
      this.map.setView([this.lat, this.lng], 20)
    }

    this.setMarker(this.lat, this.lng);

    this.map.on('click', (e: any) => {
      const lat = e.latlng.lat;
      const lng = e.latlng.lng;

      this.setMarker(lat, lng);
      this.reverseGeocode(lat, lng);
    });
  }

  setMarker(lat: number, lng: number) {
    if (this.marker) {
      this.map.removeLayer(this.marker);
    }

    this.marker = L.marker([lat, lng]).addTo(this.map);

    this.lat = lat;
    this.lng = lng;
  }

  reverseGeocode(lat: number, lng: number) {
    this.http.get(`http://localhost:5025/api/user-addresses/reverse-geocode?lat=${lat}&lng=${lng}`)
      .subscribe((data: any) => {
        this.address = data.fullAddress;
        console.log(data.fullAddress);
      });
  }

  //SAVE ADDRESS

  redirectToSearch() {
    this.backToSearch.emit();
  }

  redirectToProfile() {
    this.backToProfile.emit();
  }

  selectLabel(type: number) {
    this.label = type;
  }

  saveAddress() {

    if (this.addressForm.invalid) {
      this.errorMessageDisplay = true;
      this.errorMessage = "Fields cannot be empty";
    }
    else {
      this.errorMessageDisplay = false;
      const payload = {
        latitude: this.lat,
        longitude: this.lng,
        fullAddress: this.address,
        houseNumber: this.addressForm.get('house')?.value,
        landmark: this.addressForm.get('landmark')?.value,
        label: this.label,
        customLabel: this.addressForm.get('customLabel')?.value
      };

      this.http.post('http://localhost:5025/api/user-addresses/enter-address', payload)
        .subscribe({
          next: () => {
            this.toastService.show('Address Saved Successfully', 'success');
          },
          error: () => {
            this.toastService.show('Error occured', 'error');
          }
        });
  }
}
}
