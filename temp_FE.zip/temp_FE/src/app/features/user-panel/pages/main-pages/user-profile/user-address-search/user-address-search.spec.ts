import { ComponentFixture, TestBed } from '@angular/core/testing';

import { UserAddressSearch } from './user-address-search';

describe('UserAddressSearch', () => {
  let component: UserAddressSearch;
  let fixture: ComponentFixture<UserAddressSearch>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [UserAddressSearch]
    })
    .compileComponents();

    fixture = TestBed.createComponent(UserAddressSearch);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
