import { CommonModule } from '@angular/common';
import { HttpClient } from '@angular/common/http';
import { Component, EventEmitter, OnInit, Output } from '@angular/core';
import { FormControl, ReactiveFormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { debounceTime, distinctUntilChanged, of, switchMap } from 'rxjs';

@Component({
  selector: 'app-user-address-search',
  imports: [ReactiveFormsModule, CommonModule],
  templateUrl: './user-address-search.html',
  styleUrl: './user-address-search.css',
})
export class UserAddressSearch implements OnInit {

  searchControl = new FormControl('');
  suggestions: any[] = [];
  recentSearches: any[] = [];

  @Output() locationSelected = new EventEmitter<any>();


  constructor(private http: HttpClient, private router: Router) { }

  ngOnInit(): void {
    const stored = localStorage.getItem('recentSearches');
    this.recentSearches = stored ? JSON.parse(stored) : [];

    this.searchControl.valueChanges.pipe(
      debounceTime(500),
      distinctUntilChanged(),
      switchMap(value => {
        if (!value || value.trim() === '') {
          this.suggestions = [];
          return of([]);
        }

        return this.http.get<any[]>(
          `http://localhost:5025/api/user-addresses/geocode?query=${value}` 
        );
      })
    ).subscribe(res => {
      this.suggestions = res;
    });
  }

  addRecentSearch(place: any) {
    this.recentSearches = this.recentSearches.filter(
      item => item.displayName !== place.displayName
    );

    this.recentSearches.push(place);

    if (this.recentSearches.length > 2) {
      this.recentSearches.shift();
    }

    localStorage.setItem('recentSearches', JSON.stringify(this.recentSearches));
  }

  selectLocation(place: any) {
    this.searchControl.setValue(place.displayName, { emitEvent: false });
    this.suggestions = [];

    this.addRecentSearch(place);

    const data = {
      address: place.displayName,
      lat: place.lat,
      lon: place.lon
    };
    this.locationSelected.emit(data);
  }

  selectRecent(place:any){
    const data = {
      address: place.displayName,
      lat: place.lat,
      lon: place.lon
    };
    this.locationSelected.emit(data);
  }

  getCurrentLocation() {
    if (!navigator.geolocation) {
      alert('Geolocation not supported');
      return;
    }
  
    navigator.geolocation.getCurrentPosition(
      (position) => {
        const lat = position.coords.latitude;
        const lon = position.coords.longitude;

        this.getAddressFromCoords(lat, lon);
      },
      (error) => {
        console.error(error);
        alert('Unable to fetch location');
      }
    );
  }

  getAddressFromCoords(lat: number, lon: number) {
    this.http.get<any>(
      `http://localhost:5025/api/user-addresses/reverse-geocode?lat=${lat}&lon=${lon}`
    ).subscribe({
      next: (res) => {
        const place = {
          displayName: res.display_name || res.fullAddres || 'TatvaSoft, Sindhu Bhavan Road, Thaltej, Ghatlodiya Taluka, Ahmedabad, Gujarat, 380054, India',
          lat: lat,
          lon: lon
        };

        this.addRecentSearch(place);
  
        const data = {
          address: place.displayName,
          lat: lat,
          lon: lon
        };
        this.locationSelected.emit(data);
      },
      error: (err) => {
        console.error(err);
      }
    });
  }
}
