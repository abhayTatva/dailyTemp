import { AfterViewInit, Component, HostListener } from '@angular/core';
import { WhiteButton } from '../../../shared/components/white-button/white-button';
import { UserProfileModal } from '../../../shared/components/user-profile-modal/user-profile-modal';
import { CommonModule } from '@angular/common';
import { AuthService } from '../../../services/auth-service/auth-service';
import { UpdateDetailsService } from '../../../services/update-details-service/update-details-service';
import { FormBuilder, FormGroup, ReactiveFormsModule } from '@angular/forms';
import * as L from 'leaflet';
import { HttpClient } from '@angular/common/http';
import { ActivatedRoute, Router, RouterOutlet } from '@angular/router';
import { Button } from '../../../../../shared/components/button/button';
import { ToastMessage } from '../../../../../shared/components/toast-message/toast-message';
import { CloseSearchModalService } from '../../../services/close-search-modal-service/close-search-modal-service';
import { UserAddressSearch } from './user-address-search/user-address-search';
import { UserAddressForm } from './user-address-form/user-address-form';
import { ToastService } from '../../../services/toast-service/toast-service';
import { UserAddressEdit } from './user-address-edit/user-address-edit';
import { PaginationComponent } from '../../../../admin-panel/shared/components/pagination/pagination';

export interface Address {
  id: number,
  latitude: string,
  longitude: string,
  fullAddress: string;
  houseNumber: string;
  landmark: string;
  label: string,
  customLabel: string
}

@Component({
  selector: 'app-user-profile',
  imports: [WhiteButton, UserProfileModal, CommonModule, ReactiveFormsModule, Button, ToastMessage, UserAddressSearch, UserAddressForm, UserAddressEdit],
  templateUrl: './user-profile.html',
  styleUrl: './user-profile.css',
})


export class UserProfile {
  map!: L.Map;
  marker!: L.Marker;

  addressForm!: FormGroup;

  address: Address[] = [];

  constructor(
    private authService: AuthService,
    private updateDetails: UpdateDetailsService,
    private fb: FormBuilder,
    private http: HttpClient,
    private closeSearch: CloseSearchModalService,
    private toastService: ToastService
  ) { }

  toastMessage: string | null = null;
  toastType: 'success' | 'error' = 'success';
  toastTrigger = 0;

  showPhoneModal = false;
  showAddressModal = false;
  confirmDeleteModal = false;
  isEditMode = false;
  currentModal: 'search' | 'edit' | 'add' | null = null;
  selectedAddress: any = null;

  phoneNumber: string | null = null;
  email: string | null = null;

  deleteId: number | null = null;

  modalError: string | null = null; //error message in modeal
  openMenuIndex: number | null = null; //knows which menu button to open

  selectedLocation: any = null;
  selectedEditLocation: any = null;

  @HostListener('document:click')
  closeMenu() {
    this.openMenuIndex = null;
  }

  ngOnInit(): void {
    this.email = this.authService.getEmail();
    this.updateDetails.getPhone(this.email).subscribe({
      next: (number) => { this.phoneNumber = number },
      error: (err) => { console.log("error in fetching mobile number", err) }
    })

    this.closeSearch.formClose$.subscribe(value => {
      this.showAddressModal = value;
    });

    this.toastService.toast$.subscribe(
      data => {
        if (data) {
          this.toastMessage = data.message;
          this.toastType = data.type;
          this.toastTrigger = data.trigger;
          this.showAddressModal = false;
          this.getAddress();
          this.toastService.clear();
        }
      }
    );

    //MAP ADD ADDRESS FUNCTION

    this.addressForm = this.fb.group({
      search: [''],
      fullAddress: [''],
      city: [''],
      state: [''],
      pincode: [''],
      latitude: [null],
      longitude: [null]
    });

    //LOAD ADDRESSES 
    this.getAddress();
  }

  //CLOSE ON BACKDROP CLICK   

  onBackdropClick(event: MouseEvent) {
    if ((event.target as HTMLElement).classList.contains('modal-backdrop')) {
      this.showAddressModal = false;
    }
  }

  //PHONE MODAL

  openPhoneModal() {
    this.showPhoneModal = true;
  }

  closePhoneModal() {
    this.showPhoneModal = false;
    this.modalError = null;
  }

  handlePhoneSubmit(number: string) {
    if (number.length != 10) {
      this.modalError = "Enter a valid mobile number";
    }
    else {
      this.updateDetails.updatePhone(number, this.email).subscribe({
        next: () => {
          this.phoneNumber = number;
          this.toastService.show("Mobile Number Updated","success");
        },
        error: (err) => { console.log("errors occured", err)
          this.toastService.show("Some Error Occured","error");
         }
      });
      this.showPhoneModal = false;
      this.modalError = "";
    }
  }

  //ADDRESS MENU

  toggleMenu(index: number) {
    if (this.openMenuIndex === index) {
      this.openMenuIndex = null;
    } else {
      this.openMenuIndex = index;
    }
  }

  toggleAddressModal() {
    this.showAddressModal = !this.showAddressModal;
    if (this.showAddressModal == true) {
      this.currentModal = "search";
    }
  }

  getAddress() {
    this.http.get<Address[]>('http://localhost:5025/api/user-addresses').subscribe({
      next: (res) => {
        this.address = res.map(addr => ({
          ...addr,
          customLabel: Number(addr.customLabel) === 0 ? 'Home' : addr.customLabel
        }));
      },
      error: (err) => { console.log(err) }
    });
  }

  get isLimitReached(): boolean {
    return this.address.length >= 5;
  }

  //DELETE FUNCTION

  openConfirmDeleteModal(id: number) {
    this.openMenuIndex = null;
    this.deleteId = id;
    this.confirmDeleteModal = true;
  }

  onDeleteBackdropClick(event: MouseEvent) {
    if ((event.target as HTMLElement).classList.contains('confirm-modal-backdrop')) {
      this.confirmDeleteModal = false;
    }
  }

  deleteAddress() {
    this.http.delete(`http://localhost:5025/api/user-addresses/delete-address/${this.deleteId}`).subscribe({
      next: () => {
        this.confirmDeleteModal = false;
        this.getAddress();
        this.toastMessage = "Address Deleted";
        this.toastType = "success";
        this.toastTrigger++;
      },
      error: (err) => { (console.log("error occured:", err)) }
    });
  }

  //EDIT ADDRESS

  openEditAddressMenu(place: any, id: number) {
    const data = {
      houseNumber: place.houseNumber,
      landmark: place.landmark,
      customLabel: place.customLabel,
      fullAddress: place.fullAddress,
      addressId: id,
      latitude: place.latitude,
      longitude: place.longitude
    }

    this.selectedEditLocation = data;
    this.showAddressModal = true;
    this.currentModal = 'edit';

    this.openMenuIndex = null;
  }

  handleLocation(data: any) {
    this.selectedLocation = data;
    this.currentModal = 'add';
  }

  goToSearch() {
    this.currentModal = 'search';
  }

  goToProfile() {
    this.toggleAddressModal();
    this.currentModal = null;
  }
}
