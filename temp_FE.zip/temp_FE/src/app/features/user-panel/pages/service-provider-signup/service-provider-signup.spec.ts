import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ServiceProviderSignup } from './service-provider-signup';

describe('ServiceProviderSignup', () => {
  let component: ServiceProviderSignup;
  let fixture: ComponentFixture<ServiceProviderSignup>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [ServiceProviderSignup]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ServiceProviderSignup);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
