import { Component, HostListener } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormBuilder, FormGroup, FormArray, ReactiveFormsModule, Validators, FormsModule } from '@angular/forms';
import { ServiceTypes } from '../../../../services/servicetype';
import { CategoryService } from '../../../../services/categoryservice';
import { SubCategoryService, SubCategory } from '../../../../services/subcategoryservice'; 
import { ServicePartner } from '../../services/service-partner';
import { ToastMessage } from '../../../../shared/components/toast-message/toast-message';
import { FormState } from '../../services/form-state';
import { Router } from '@angular/router';

@Component({
  selector: 'app-service-provider-signup',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, FormsModule, ToastMessage],
  templateUrl: './service-provider-signup.html',
  styleUrl: './service-provider-signup.css',
})
export class ServiceProviderSignup {

  emailExists = false;
  checkingEmail = false;

  profileForm!: FormGroup;

  maxDOB!: string;
  maxToday!: string;

  selectedServiceId!: number;
  services: any[] = [];
  serviceSearch = '';
  filteredServices: any[] = [];
  showServiceDropdown = false;
  serviceNotFound = false;
  serviceTouched = false;

  allLanguages = ['English', 'Hindi', 'Gujarati'];

  categories: any[] = [];
  selectedCategoryObjects: any[] = [];
  selectedCategories: number[] = [];

  subCategories: SubCategory[] = [];
  selectedSubCategories: number[] = [];

  profileImageFile!: File | null;
  profileImagePreview: string | ArrayBuffer | null = null;

  documents: File[] = [];
  allowedDocumentTypes = [
    'application/pdf',
    'application/msword', 
    'application/vnd.openxmlformats-officedocument.wordprocessingml.document' 
  ];
  isDragging = false;

  toastMessage: string | null = null;
  toastType: 'success' | 'error' = 'success';
  toastTrigger = 0;

  formSubmitted = false;
  
  constructor(private fb: FormBuilder,
    private serviceTypes: ServiceTypes,
    private categoryService: CategoryService,
    private subCategoryService: SubCategoryService,
    private servicePartnerService: ServicePartner,
    private formStateService: FormState,
    private router : Router) {}


  @HostListener('document:click', ['$event'])
  handleOutsideClick(event: any) {

    const clickedInside =
      event.target.closest('.service-dropdown') ||
      event.target.closest('.service-input');

    if (!clickedInside) {
      this.showServiceDropdown = false;
    }

  }

  checkEmailExists() {
    const emailControl = this.personalInfo.get('email');

    if (!emailControl || emailControl.invalid) return;

    const email = emailControl.value;
    
    this.checkingEmail = true;
  
    this.servicePartnerService.checkEmail(email).subscribe({
      next: (res) => {
        this.emailExists = res.exists;
        this.checkingEmail = false;
  
        if (this.emailExists) {
          this.personalInfo.get('email')?.setErrors({ emailExists: true });
        } else {
          const errors = this.personalInfo.get('email')?.errors;
          if (errors) {
            delete errors['emailExists'];
            this.personalInfo.get('email')?.setErrors(Object.keys(errors).length ? errors : null);
          }
        }
      },
      error: () => {
        this.checkingEmail = false;
      }
    });
  }

  checkDuplicateEducation() {
    const seen = new Set();
    let hasDuplicateEdu = false;
  
    this.education.controls.forEach((edu: any) => {
      const school = edu.get('school')?.value?.trim().toLowerCase();
      const year = edu.get('passingYear')?.value;
  
      if (school && year) {
        const key = `${school}-${year}`;
  
        if (seen.has(key)) {
          edu.setErrors({ duplicate: true });
          hasDuplicateEdu = true;
        } else {
          seen.add(key);
          if (edu.errors?.['duplicate']) {
            const errors = edu.errors;
            delete errors['duplicate'];
            edu.setErrors(Object.keys(errors).length ? errors : null);
          }
        }
      }
    });
  
    return hasDuplicateEdu;
  }

  checkDuplicateExperience() {
    const seen = new Set();
    let hasDuplicateExp = false;
  
    this.experience.controls.forEach((exp: any) => {
      const company = exp.get('company')?.value?.trim().toLowerCase();
      const role = exp.get('role')?.value?.trim().toLowerCase();
  
      if (company && role) {
        const key = `${company}-${role}`;
  
        if (seen.has(key)) {
          exp.setErrors({ duplicate: true });
          hasDuplicateExp = true;
        } else {
          seen.add(key);
  
          if (exp.errors?.['duplicate']) {
            const errors = exp.errors;
            delete errors['duplicate'];
            exp.setErrors(Object.keys(errors).length ? errors : null);
          }
        }
      }
    });
  
    return hasDuplicateExp;
  }

  allowOnlyNumbers(event: any) {
    const input = event.target.value;
    event.target.value = input.replace(/[^0-9]/g, '');
    }

  ngOnInit() {
    window.scrollTo(0, 0);

    const today = new Date();
    const minAgeDate = new Date(
      today.getFullYear() - 18,
      today.getMonth(),
      today.getDate()
    );

    this.maxDOB = minAgeDate.toISOString().split('T')[0];
    this.maxToday = today.toISOString().split('T')[0];

    this.profileForm = this.fb.group({
      personalInfo: this.fb.group({
        fullName: ['', [Validators.required, Validators.maxLength(150), this.minTrimmedLengthValidator(2)]],
        dob: ['', [Validators.required, this.futureDateValidator]],
        gender: ['', Validators.required],
        mobileNumber: ['', [Validators.required,Validators.pattern('^[0-9]{10}$')]],
        email: ['', [Validators.required, Validators.email, Validators.maxLength(150), this.dotAfterAtValidator]],
        permanentAddress: ['', [Validators.required, Validators.maxLength(500)]],
        residentialAddress: ['', [Validators.required, Validators.maxLength(500)]]
      }),
      education: this.fb.array([]),
      experience: this.fb.array([]),
      languages: this.fb.array([])
    });

    const saved = this.formStateService.formData;

    if (saved) {
      this.profileForm.get('personalInfo')?.patchValue(saved.personalInfo);

      saved.education.forEach((edu: any) => {
        this.education.push(this.fb.group(edu));
      });
      saved.experience.forEach((exp: any) => {
        this.experience.push(this.fb.group(exp));
      });
      saved.languages.forEach((lang: any) => {
        this.languages.push(this.fb.group(lang));
      });

    } else {
      this.education.push(this.createEducation());
      this.experience.push(this.createExperience());
      this.languages.push(this.createLanguage());
    }

    this.loadServices();

    this.profileForm.valueChanges.subscribe(value => {
      this.formStateService.formData = value;
    });

    this.education.valueChanges.subscribe(() => {
      this.checkDuplicateEducation();
    });
    this.experience.valueChanges.subscribe(() => {
      this.checkDuplicateExperience();
    });
    this.personalInfo.get('dob')?.valueChanges.subscribe(() => {
      this.education.controls.forEach((edu: any) => {
        edu.get('passingYear')?.updateValueAndValidity();
      });
    });
  }

  loadServices() {
    this.serviceTypes.getAll().subscribe(res => {
      this.services = res;
      this.filteredServices = res;
    });
  }

  filterServices() {
    this.showServiceDropdown = true;
    const search = this.serviceSearch.toLowerCase().trim();
    this.selectedServiceId = 0;
    this.serviceNotFound = false;
    if (!search) {
      this.filteredServices = this.services;
      return;
    }
    this.filteredServices = this.services.filter(service =>
      service.name.toLowerCase().includes(search)
    );
    this.serviceNotFound = this.filteredServices.length === 0;
  }

  onServiceEnter() {
    const match = this.services.find(
      s => s.name.toLowerCase() === this.serviceSearch.toLowerCase().trim()
    ); 
    if (!match) {
      this.selectedServiceId = 0;
      this.serviceNotFound = true;
    } else {
      this.selectService(match);
    }
  
    this.showServiceDropdown = false;
  }

  selectService(service: any) {
    this.serviceSearch = service.name;
    this.selectedServiceId = service.id;
    this.showServiceDropdown = false; 
    this.serviceNotFound = false;
    this.onServiceChange(service.id);
  }

  onServiceChange(serviceId: number) {
    // this.selectedServiceId = serviceId;
    this.categories = [];
    this.subCategories = [];
    this.selectedCategories = [];
    this.selectedCategoryObjects = [];
    this.selectedSubCategories = [];

    this.categoryService.getByService(serviceId)
      .subscribe(res => {
        this.categories = res;
      });

  }
  
  selectCategory(category: any) {
    if (this.selectedCategories.includes(category.id)) return;
    this.selectedCategories.push(category.id);
    this.selectedCategoryObjects.push(category); 
    this.loadSubCategories();
  }

  removeCategory(category: any) {
    this.selectedCategoryObjects =
      this.selectedCategoryObjects.filter(c => c.id !== category.id);
  
    this.selectedCategories =
      this.selectedCategories.filter(id => id !== category.id);
  
    this.loadSubCategories();
  }

  loadSubCategories() {
    this.subCategories = [];

    this.selectedCategories.forEach(categoryId => {

      this.subCategoryService
        .getByCategory(categoryId)
        .subscribe(res => {
          res.forEach(sub => {
            const exists = this.subCategories
              .find(s => s.id === sub.id);

            if (!exists) {
              this.subCategories.push(sub);
            }
          });
        });
    });
  }

  toggleSubCategory(sub: SubCategory) {

    const index = this.selectedSubCategories.indexOf(sub.id);

    if (index > -1) {
      this.selectedSubCategories.splice(index, 1);
    } else {
      this.selectedSubCategories.push(sub.id);
    }

  }

  get personalInfo() {
    return this.profileForm.get('personalInfo') as FormGroup;
  }

  get education() {
    return this.profileForm.get('education') as FormArray;
  }

  get experience() {
    return this.profileForm.get('experience') as FormArray;
  }

  get languages() {
    return this.profileForm.get('languages') as FormArray;
  }

  addEducation() {
    this.education.push(this.createEducation());
  }

  createEducation(): FormGroup {
    return this.fb.group({
      school: ['',[Validators.required, this.minTrimmedLengthValidator(3)]],
      passingYear: ['',[ Validators.required, Validators.pattern(/^\d{4}$/), this.passingYearValidator]],
      marks: ['', [Validators.required, Validators.min(0), Validators.max(100)]]
    });
  }

  removeEducation(index: number) {
    this.education.removeAt(index);
  }

  addExperience() {
    this.experience.push(this.createExperience());
  }

  createExperience(): FormGroup {
    return this.fb.group({
      company: [''],
      role: [''],
      fromDate: ['', this.noFutureDateValidator],
      toDate: ['', this.noFutureDateValidator]
    },  { validators: [this.experienceRequiredValidator, this.dateRangeValidator]  }, );
  }

  removeExperience(index: number) {
    this.experience.removeAt(index);
  }

  dateRangeValidator(group: FormGroup) {
    const from = group.get('fromDate')?.value;
    const to = group.get('toDate')?.value;

    if (from && to && new Date(to) < new Date(from)) {
      return { invalidRange: true };
    }
    return null;
  }

  experienceRequiredValidator(group: FormGroup) {
    const { company, role, fromDate, toDate } = group.value;

    const anyFilled = company || role || fromDate || toDate;
    const allFilled = company && role && fromDate && toDate;

    if (anyFilled && !allFilled) {
      return { incomplete: true };
    }
    return null;
  }

  addLanguage() {
    this.languages.push(this.createLanguage());
  }

  createLanguage(): FormGroup {
    return this.fb.group({
      language: ['', Validators.required],
      proficiency: ['', Validators.required]
    });
  }

  getAvailableLanguages(index: number): string[] {
    const selectedLanguages = this.languages.value
      .map((l: any) => l.language)
      .filter((l: string, i: number) => l && i !== index); 
    
    return this.allLanguages.filter(lang => !selectedLanguages.includes(lang));
  }

  removeLanguage(index: number) {
    this.languages.removeAt(index);
  }

  onProfileImageSelected(event: any) {
    const file = event.target.files[0];
    if (!file) return;
    if (file.size > 2 * 1024 * 1024) {
      this.showToast('Profile image must be less than 2MB');
      event.target.value = '';
      return;
    }

    const allowedTypes = ['image/jpeg', 'image/png', 'image/jpg', 'image/webp'];
    if (!allowedTypes.includes(file.type)) {
      this.showToast('Only JPG, JPEG, PNG or WEBP image is allowed');
      event.target.value = '';
      return;
    }
    this.profileImageFile = file;

    const reader = new FileReader();
    reader.onload = () => {
      this.profileImagePreview = reader.result;
    };
    reader.readAsDataURL(file);
  }

  onDragOver(event: DragEvent) {
    event.preventDefault();
    this.isDragging = true;
  }
  
  onDragLeave(event: DragEvent) {
    event.preventDefault();
    this.isDragging = false;
  }
  
  onDrop(event: DragEvent) {
    event.preventDefault();
    this.isDragging = false;
    const files = event.dataTransfer?.files;
    if (!files) return;
    this.handleFiles(files);
  }

  handleFiles(files: FileList) {
    for (let i = 0; i < files.length; i++) {
      const file = files[i];
      if (file.size > 2 * 1024 * 1024) {
        this.showToast('File size must be less than 2MB');
        continue;
      }
      if (!this.allowedDocumentTypes.includes(file.type)) {
        this.showToast('Only PDF, DOC, or DOCX files are allowed');
        continue;
      }
      const exists = this.documents.some(doc =>
        doc.name === file.name && doc.size === file.size
      );
      if (exists) {
        this.showToast('This document is already uploaded');
        continue;
      }
      this.documents.push(file);
    }
  }

  onAttachmentSelected(event: any) {
    const files = event.target.files;
    this.handleFiles(files);
    event.target.value = '';
  }

  viewDocument(file: File) {
    const fileURL = URL.createObjectURL(file);
    window.open(fileURL, '_blank');
  }

  removeDocument(index: number, event: Event) {
    event.stopPropagation(); 
    this.documents.splice(index, 1);
  }

  futureDateValidator(control: any) {
    if (!control.value) return null;
  
    const selectedDate = new Date(control.value);
    const today = new Date();
  
    today.setHours(0,0,0,0);
    if (selectedDate > today) {
      return { futureDate: true };
    }
  
    let age = today.getFullYear() - selectedDate.getFullYear();
    const monthDiff = today.getMonth() - selectedDate.getMonth();
    if ( monthDiff < 0 || (monthDiff === 0 && today.getDate() < selectedDate.getDate())) {
      age--;
    }
    if (age < 18) {
      return { underAge: true };
    }
    return null;
  }

  noFutureDateValidator(control: any) {
    if (!control.value) return null;
  
    const selectedDate = new Date(control.value);
    const today = new Date();
  
    today.setHours(0, 0, 0, 0);
  
    return selectedDate > today ? { futureDate: true } : null;
  }

  passingYearValidator = (control: any) => {
    if (!control.value) return null;

    const passingYear = Number(control.value);
    const currentYear = new Date().getFullYear();

    if (passingYear > currentYear) {
      return { futureYear: true };
    }

    if (!control.root || !(control.root as FormGroup).get) return null;

    const dob = control.root.get('personalInfo.dob')?.value;
    if (!dob) return null;

    const dobYear = new Date(dob).getFullYear();

    if (passingYear < dobYear) {
      return { beforeDOB: true };
    }

    return null;
  };

  dotAfterAtValidator(control: any) {
    if (!control.value) return null;
    const email: string = control.value;
  
    const atIndex = email.indexOf('@');
    const dotIndex = email.lastIndexOf('.');
  
    if (atIndex === -1 || dotIndex === -1 || dotIndex < atIndex) {
      return { dotAfterAt: true };
    }
  
    return null;
  }

  minTrimmedLengthValidator(min: number) {
    return (control: any) => {
      if (!control.value) return null;
  
      const value = control.value.trim();
      return value.length < min ? { minTrimmedLength: true } : null;
    };
  }

  showToast(message: string) {
    this.toastMessage = message;
    this.toastType = 'error';
    this.toastTrigger++;
  }

  validateServiceOnBlur() {
    this.serviceTouched = true;

    const search = this.serviceSearch?.trim().toLowerCase();
    if (!search) {
      this.selectedServiceId = 0;
      this.serviceNotFound = false;
      return;
    }
    const match = this.services.find(
      s => s.name.toLowerCase() === search
    );
    if (!match) {
      this.selectedServiceId = 0;
      this.serviceNotFound = true;
    } else {
      this.selectService(match);
    }
    this.showServiceDropdown = false;
  }

  validateExtraFields(): boolean {

    if (!this.selectedServiceId) return false;
  
    if (this.selectedCategories.length === 0) return false;
  
    if (this.selectedSubCategories.length === 0) return false;
  
    if (this.documents.length === 0) return false;

    return true;
  }

  scrollToFirstError() {
    setTimeout(() => {
      const invalidControl = document.querySelector(
        'input.ng-invalid, select.ng-invalid, textarea.ng-invalid'
      ) as HTMLElement;
  
      if (invalidControl) {
        invalidControl.scrollIntoView({
          behavior: 'smooth',
          block: 'center'
        });
  
        invalidControl.focus();
        return;
      }
  
      if (!this.selectedServiceId || this.serviceNotFound) {
        const el = document.getElementById('serviceField');
        el?.scrollIntoView({ behavior: 'smooth', block: 'center' });
        return;
      }
      if (this.selectedCategories.length === 0) {
        const el = document.getElementById('categoryField');
        el?.scrollIntoView({ behavior: 'smooth', block: 'center' });
        return;
      }

      if (this.documents.length === 0) {
        const el = document.getElementById('documentField');
        el?.scrollIntoView({ behavior: 'smooth', block: 'center' });
        return;
      }
  
    }, 100);
  }

  onSubmit() {
  
    this.formSubmitted = true;

    const hasDuplicateEdu = this.checkDuplicateEducation();
    const hasDuplicateExp = this.checkDuplicateExperience();

    if (this.profileForm.invalid || hasDuplicateEdu ||
      hasDuplicateExp ||this.emailExists || !this.validateExtraFields()) {
      this.profileForm.markAllAsTouched();
       this.scrollToFirstError();
      return;
    }

    console.log("Creating FormData...");
  
    const formData = new FormData();
  
    const formValue = this.profileForm.value;
    const personal = formValue.personalInfo;
  
    formData.append('FullName', personal.fullName);               
    formData.append('DateOfBirth', personal.dob);                
    formData.append('Gender', personal.gender);                   
    formData.append('MobileNumber', personal.mobileNumber);       
    formData.append('Email', personal.email);                     
    formData.append('PermanentAddress', personal.permanentAddress); 
    formData.append('ResidentialAddress', personal.residentialAddress);

    formData.append('ServiceTypeId', this.selectedServiceId.toString()); 

    formValue.education.forEach((edu: any, index: number) => {
      formData.append(`Educations[${index}].SchoolCollegeName`, edu.school);       
      formData.append(`Educations[${index}].PassingYear`, edu.passingYear); 
      formData.append(`Educations[${index}].MarksPercentage`, edu.marks);        
    });

    formValue.experience.forEach((exp: any, index: number) => {
      formData.append(`Experiences[${index}].CompanyName`, exp.company);  
      formData.append(`Experiences[${index}].Role`, exp.role);         
      formData.append(`Experiences[${index}].FromDate`, exp.fromDate); 
      formData.append(`Experiences[${index}].ToDate`, exp.toDate);    
    });

    formValue.languages.forEach((lang: any, index: number) => {
      formData.append(`Languages[${index}].Language`, lang.language);       
      formData.append(`Languages[${index}].Proficiency`, lang.proficiency); 
    });

    this.selectedCategories.forEach((cat, index) => {
      formData.append(`CategoryIds[${index}]`, cat.toString()); 
    });

    this.selectedSubCategories.forEach((sub, index) => {
      formData.append(`SubCategoryIds[${index}]`, sub.toString()); 
    });

    if (this.profileImageFile) {
      formData.append('ProfileImage', this.profileImageFile); 
    }

    this.documents.forEach(doc => {
      formData.append('Documents', doc); 
    });

    console.log("Calling API...");
    
    this.servicePartnerService.applyServicePartner(formData)
      .subscribe({
        next: res => {
          console.log('Application submitted successfully', res);
          this.router.navigate(['/service-provider-submitted']);
          this.profileForm.reset();

          this.education.clear();
          this.experience.clear();
          this.languages.clear();

          this.education.push(this.createEducation());
          this.experience.push(this.createExperience());
          this.languages.push(this.createLanguage());

          this.selectedServiceId = 0;
          this.serviceSearch = '';
          this.selectedCategories = [];
          this.selectedCategoryObjects = [];
          this.selectedSubCategories = [];
          this.categories = [];
          this.subCategories = [];

          this.documents = [];
          this.profileImageFile = null;
          this.profileImagePreview = null;
          this.formStateService.formData = null;

          this.serviceTouched = false;
        },
        error: err => {
          console.error('Submission failed', err);
          console.log("Status:", err.status);
          console.log("Backend error object:", err.error);
          console.log("Validation errors:", err.error?.errors);
          this.showToast("Application didn't submitted.")
          }
        });
    }

    onCancel() {
      this.formStateService.formData = null;
    
      this.profileForm.reset();
    
      this.education.clear();
      this.experience.clear();
      this.languages.clear();
    
      this.education.push(this.createEducation());
      this.experience.push(this.createExperience());
      this.languages.push(this.createLanguage());
    
      this.selectedServiceId = 0;
      this.serviceSearch = '';
      this.selectedCategories = [];
      this.selectedCategoryObjects = [];
      this.selectedSubCategories = [];
      this.categories = [];
      this.subCategories = [];
    
      this.documents = [];
      this.profileImageFile = null;
      this.profileImagePreview = null;
    
      this.serviceTouched = false;
      this.formSubmitted = false;
    
      this.router.navigate(['/layout/home']);
    }

    returnHome()
    {
      this.router.navigate(["/layout/home"]);
    }
}

