import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ServiceProviderThankyou } from './service-provider-thankyou';

describe('ServiceProviderThankyou', () => {
  let component: ServiceProviderThankyou;
  let fixture: ComponentFixture<ServiceProviderThankyou>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [ServiceProviderThankyou]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ServiceProviderThankyou);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
