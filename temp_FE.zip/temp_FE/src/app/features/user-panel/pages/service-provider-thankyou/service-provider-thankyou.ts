import { Component } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-service-provider-thankyou',
  imports: [],
  templateUrl: './service-provider-thankyou.html',
  styleUrl: './service-provider-thankyou.css',
})
export class ServiceProviderThankyou {
  constructor(private router : Router){}

  viewServices() {
    this.router.navigate(['/layout/service']);
  }

  goHome() {
    this.router.navigate(['/layout/home']);
  }
}
