import { ComponentFixture, TestBed } from '@angular/core/testing';

import { UserErrorPage } from './user-error-page';

describe('UserErrorPage', () => {
  let component: UserErrorPage;
  let fixture: ComponentFixture<UserErrorPage>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [UserErrorPage]
    })
    .compileComponents();

    fixture = TestBed.createComponent(UserErrorPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
