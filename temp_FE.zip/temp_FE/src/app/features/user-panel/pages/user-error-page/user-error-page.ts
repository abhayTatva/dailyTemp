import { Component } from '@angular/core';
import { Button } from '../../../../shared/components/button/button';
import { Router, RouterLink } from '@angular/router';

@Component({
  selector: 'app-user-error-page',
  imports: [Button],
  templateUrl: './user-error-page.html',
  styleUrl: './user-error-page.css',
})
export class UserErrorPage {
 constructor(private router:Router){}

 goToHome()
 {
  this.router.navigate(['layout/home'])
 }
}
