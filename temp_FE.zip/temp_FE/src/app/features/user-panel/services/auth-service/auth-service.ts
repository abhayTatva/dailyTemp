import { Injectable } from '@angular/core';
import { jwtDecode } from 'jwt-decode';
import { CustomJwtPayload } from '../../../../Interfaces/CustomJwtPayload';
import { Router } from '@angular/router';

@Injectable({
  providedIn: 'root',
})
export class AuthService {
  private logoutTimer: any;

  constructor(private router:Router){}

  getToken() {
    return localStorage.getItem("user_token");
  }

  getDecodedToken():CustomJwtPayload | null {
      const token = localStorage.getItem('user_token');
    
      if (!token) return null;
    
      return jwtDecode<CustomJwtPayload>(token);
    }

  getEmail(): string | null {
    const decoded = this.getDecodedToken();
  
    return (
      decoded?.email ||
      decoded?.["http://schemas.xmlsoap.org/ws/2005/05/identity/claims/emailaddress"] ||
      null
    );
  }

  isTokenExpired(): boolean {
    const decoded = this.getDecodedToken();
    if (!decoded || !decoded.exp) return true;

    return decoded.exp * 1000 < Date.now();
  }

  isLoggedIn():boolean{   
    const token = localStorage.getItem("user_token");

    if(!token) return false;

    return !this.isTokenExpired();
  }

  startAutoLogout() {
    const decoded = this.getDecodedToken();

    if (!decoded || !decoded.exp) {
      return;
    }

    const expiryTime = decoded.exp * 1000;
    const currentTime = Date.now();

    const timeLeft = expiryTime - currentTime;

    if (timeLeft <= 0) {
      this.logout();
      return;
    }

    if (this.logoutTimer) {
      clearTimeout(this.logoutTimer);
    }

    this.logoutTimer = setTimeout(() => {
      this.logout();
    }, timeLeft);
  }

  logout(){
    localStorage.removeItem("user_token");
    this.router.navigate(['/layout']);
  }
}
