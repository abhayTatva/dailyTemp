import { TestBed } from '@angular/core/testing';

import { CloseSearchModalService } from './close-search-modal-service';

describe('CloseSearchModalService', () => {
  let service: CloseSearchModalService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(CloseSearchModalService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
