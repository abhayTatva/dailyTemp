import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';

@Injectable({
  providedIn: 'root',
})
export class CloseSearchModalService {
  private formClose = new BehaviorSubject<boolean>(false);
  formClose$ = this.formClose.asObservable();

  setFormClose(value:boolean){
    this.formClose.next(value);
  }
}
