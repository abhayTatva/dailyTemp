import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root',
})
export class FormState {
  formData: any = null;
}
