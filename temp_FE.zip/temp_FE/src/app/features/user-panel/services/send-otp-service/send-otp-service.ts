import { HttpClient, HttpContext } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { observableToBeFn } from 'rxjs/internal/testing/TestScheduler';

@Injectable({
  providedIn: 'root',
})
export class SendOtpService {

  private apiUrl = "http://localhost:5025/api/UserLogin";

  constructor(private http: HttpClient) { }

  sendOtp(email: string, name: string): Observable<any> {
    return this.http.post(`${this.apiUrl}/send-otp`, { email, name })
  }

  verifyOtp(name: string, email: string, otp: string): Observable<any> {
    return this.http.post(`${this.apiUrl}/verify-otp`, { name, email, otp })
  }
}
