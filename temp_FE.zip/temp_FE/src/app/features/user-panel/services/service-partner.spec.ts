import { TestBed } from '@angular/core/testing';

import { ServicePartner } from './service-partner';

describe('ServicePartner', () => {
  let service: ServicePartner;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(ServicePartner);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
