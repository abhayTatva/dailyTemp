import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '../../../../environments/environment';

@Injectable({
  providedIn: 'root',
})
export class ServicePartner {
  private apiUrl = `${environment.apiBaseUrl}/service-partners`;

  constructor(private http: HttpClient) {}

  checkEmail(email: string) {
    return this.http.get<any>(`${this.apiUrl}/check-email?email=${email}`);
  }

  applyServicePartner(formData: FormData): Observable<any> {
    return this.http.post(`${this.apiUrl}/apply`, formData);
  }
}
