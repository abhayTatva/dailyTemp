import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';

@Injectable({
  providedIn: 'root',
})
export class ToastService {
  private toastSubject = new BehaviorSubject<{
    message: string;
    type: 'success' | 'error';
    trigger: number;
  } | null>(null);

  toast$=this.toastSubject.asObservable();

  private triggerCount=0;

  show(message:string,type:'success'|'error'='success')
  {
    this.triggerCount++;

    this.toastSubject.next({
      message,
      type,
      trigger: this.triggerCount
    });
  }

  clear(){
    this.toastSubject.next(null);
  }
}
