import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root',
})
export class UpdateDetailsService {
  private ApiUrl="http://localhost:5025/api/UserProfile";

  constructor(private http:HttpClient){ }

  updatePhone(number:string,email:string|null):Observable<any>{
    return this.http.put(`${this.ApiUrl}/update-phone-number`,{number,email})
  }

  getPhone(email:string|null):Observable<any>{
    return this.http.get(`${this.ApiUrl}/phone-number?email=${email}`)
  }
}
