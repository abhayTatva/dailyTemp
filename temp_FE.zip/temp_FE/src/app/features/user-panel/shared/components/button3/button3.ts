import { Component, EventEmitter, Input, Output } from '@angular/core';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-button3',
  imports: [CommonModule],
  templateUrl: './button3.html',
  styleUrl: './button3.css',
})
export class Button3 {
  @Input() width: string = 'auto';
  @Input() height: string = '40px';
  @Input() borderRadius: string = '50px';
  @Input() fontSize: string = '14px';

  @Output() btnClick = new EventEmitter<void>();

  handleClick() {
    this.btnClick.emit();
  }

}
