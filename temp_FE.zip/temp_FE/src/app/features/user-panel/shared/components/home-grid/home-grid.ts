import { Component, Input } from '@angular/core';
import { CommonModule } from '@angular/common';
import { LightButton } from '../light-button/light-button';

export interface Product {
  title: string;
  price: number;
  image: string;
}

@Component({
  selector: 'app-home-grid',
  imports: [CommonModule,LightButton],
  templateUrl: './home-grid.html',
  styleUrl: './home-grid.css',
})
export class HomeGrid {
  @Input() heading:string='Heading';
  @Input() populars:Product[]=[];

  // @Input() image:string="";
  // @Input() title:string="title";
  // @Input() price:string="price";
}
