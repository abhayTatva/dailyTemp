import { ComponentFixture, TestBed } from '@angular/core/testing';

import { LightButton } from './light-button';

describe('LightButton', () => {
  let component: LightButton;
  let fixture: ComponentFixture<LightButton>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [LightButton]
    })
    .compileComponents();

    fixture = TestBed.createComponent(LightButton);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
