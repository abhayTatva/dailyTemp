import { CommonModule } from '@angular/common';
import { Component, EventEmitter, HostBinding, Input,Output } from '@angular/core';

@Component({
  selector: 'app-light-button',
  imports: [CommonModule],
  templateUrl: './light-button.html',
  styleUrl: './light-button.css',
})
export class LightButton {
  @Input() label:string="Add";
  @Input() height:string="40px";
  @Input() width:string="90px";

  @Output() buttonClick= new EventEmitter<void>();
}
