import { CommonModule } from '@angular/common';
import { Component, EventEmitter, Input, Output } from '@angular/core';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-user-profile-modal',
  imports: [CommonModule,FormsModule],
  templateUrl: './user-profile-modal.html',
  styleUrl: './user-profile-modal.css',
})
export class UserProfileModal {
  @Input() title: string = '';
  @Input() placeHolder: string = '';
  @Input() buttonText: string = 'Submit';
  @Input() height="216px";
  @Input() width="400px";
  @Input() subtext:string="";
  @Input() value:string|null=null;
  @Input() modalError:string|null=null;

  @Output() submitValue = new EventEmitter<string>();
  @Output() close = new EventEmitter<void>();

  inputValue: string = '';

  submit() {
    this.submitValue.emit(this.inputValue);
  }

  closeModal() {
    this.close.emit();
  }

  onBackdropClick(event: MouseEvent) {
    if ((event.target as HTMLElement).classList.contains('modal-backdrop')) {
      this.closeModal();
    }
}
}
