import { CommonModule } from '@angular/common';
import { Component, EventEmitter, Input, Output } from '@angular/core';

@Component({
  selector: 'app-white-button',
  imports: [CommonModule],
  templateUrl: './white-button.html',
  styleUrl: './white-button.css',
})
export class WhiteButton {
  @Input() label='';
  @Input() height='40px';
  @Input() width='100px';
  @Input() icon="";
  
  @Output() buttonClick=new EventEmitter<void>;

  onClick(){
    this.buttonClick.emit();
  }
}
