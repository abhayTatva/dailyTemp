import {Component, Input, Output, EventEmitter, OnInit } from '@angular/core';
import { AdminProfile } from '../../../features/admin-panel/pages/admin-main-pages/admin-profile/admin-profile';
import { RouterModule } from '@angular/router';
import { AdminService } from '../../../services/adminservice';
import { environment } from '../../../../environments/environment';

@Component({
  selector: 'app-admin-header',
  standalone: true,
  imports: [ RouterModule],
  templateUrl: './admin-header.html',
  styleUrls: ['./admin-header.css'],
})
export class AdminHeader {
  profile: any = {};
  baseUrl = environment.mediaBaseUrl;

  constructor(private adminService: AdminService) {}

  ngOnInit(): void {

    this.adminService.adminProfile$.subscribe(profile => {
      if(profile){
        this.profile = profile;
      }
    });
  
    const adminId = this.adminService.getAdminIdFromToken();
  
    if(adminId){
      this.adminService.getAdminById(adminId).subscribe(res => {
        this.adminService.setAdminProfile(res);
      });
    }

  }

  logout() {
    localStorage.removeItem('token');
    window.location.href = '/admin/admin-login';
  }
  @Input() isSidebarOpen = false;
  @Output() toggleSidebar = new EventEmitter<void>();

  onToggle() {
    this.toggleSidebar.emit();
  }
}

