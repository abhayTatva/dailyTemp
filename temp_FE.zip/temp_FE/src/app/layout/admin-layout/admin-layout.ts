import { Component, HostListener } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { AdminSidebar } from './admin-sidebar/admin-sidebar';
import { AdminHeader } from './admin-header/admin-header';
import { NgIf } from '@angular/common';

@Component({
  selector: 'app-admin-layout',
  standalone: true,
  imports: [RouterOutlet, AdminSidebar, AdminHeader, NgIf],
  templateUrl: './admin-layout.html',
  styleUrl: './admin-layout.css',
})
export class AdminLayout {

  isSidebarOpen = false;
  isLargeScreen = window.innerWidth >= 992;

  ngOnInit() {
    if (this.isLargeScreen) {
      this.isSidebarOpen = true;
    }
  }

  toggleSidebar() {
    if (!this.isLargeScreen) {
      this.isSidebarOpen = !this.isSidebarOpen;
    }
  }

  closeSidebar() {
    this.isSidebarOpen = false;
  }

  @HostListener('window:resize')
  onResize() {
    this.isLargeScreen = window.innerWidth >= 992;

    if (this.isLargeScreen) {
      this.isSidebarOpen = true;
    } else {
      this.isSidebarOpen = false;
    }
  }
}