import { Component } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { Header } from './header/header';
import { Footer } from './footer/footer';



@Component({
  standalone: true,
  selector: 'app-layout',
  imports: [RouterOutlet,Header,Footer],
  templateUrl: './layout.html',
  styleUrl: './layout.css',
})
export class Layout {

}
