export interface OfferResponseDto {
    id: number;
    couponCode: string;
    couponDescription: string | null;
    discountPercentage: string; // "10% Off"
    couponApplied: string;      // "21 Times"
    isActive: boolean;
    createdOn: string;
  }
  
  export interface CreateOfferRequestDto {
    couponCode: string;
    couponDescription?: string;
    discountPercentage: number;
  }
  
  export interface UpdateOfferRequestDto {
    couponCode: string;
    couponDescription?: string;
    discountPercentage: number;
    isActive: boolean;
  }
  
  export interface OfferFilterDto {
    page: number;
    pageSize: number;
    sortBy: string;
    sortDirection: string;
    minDiscount?: number | null;
    maxDiscount?: number | null;
    minTimeCouponApplied: number | null;
    maxTimeCouponApplied: number | null;
    isActive?: boolean | null;
  }
  
  export interface PagedResult<T> {
    data: T[];
    totalRecords: number;
    page: number;
    pageSize: number;
    totalPages: number;
  }
  