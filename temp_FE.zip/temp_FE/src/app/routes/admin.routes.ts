import { Routes } from "@angular/router";
import { AdminLogin } from "../features/admin-panel/pages/admin-login/admin-login";
import { AdminForgetPassword } from "../features/admin-panel/pages/admin-forget-password/admin-forget-password";
import { AdminResetLink } from "../features/admin-panel/pages/admin-reset-link/admin-reset-link";
import { AdminLayout } from "../layout/admin-layout/admin-layout";
import { AdminDashboard } from "../features/admin-panel/pages/admin-main-pages/admin-dashboard/admin-dashboard";
import { AdminServiceManagement } from "../features/admin-panel/pages/admin-main-pages/admin-service-management/admin-service-management";
import { AdminUserManagement } from "../features/admin-panel/pages/admin-main-pages/admin-user-management/admin-user-management";
import { AdminBookingManagement } from "../features/admin-panel/pages/admin-main-pages/admin-booking-management/admin-booking-management";
import { AdminOffers } from "../features/admin-panel/pages/admin-main-pages/admin-offers/admin-offers";
import { AdminMasterData } from "../features/admin-panel/pages/admin-main-pages/admin-master-data/admin-master-data";
import { AdminSupport } from "../features/admin-panel/pages/admin-main-pages/admin-support/admin-support";
import { AdminProfile } from "../features/admin-panel/pages/admin-main-pages/admin-profile/admin-profile";
import { AdminPaymentTransaction } from "../features/admin-panel/pages/admin-main-pages/admin-payment-transaction/admin-payment-transaction";
import { AdminErrorPage } from "../features/admin-panel/pages/admin-error-page/admin-error-page";
import { Customers } from "../features/admin-panel/pages/admin-main-pages/admin-user-management/customers/customers";
import { ServicePartners } from "../features/admin-panel/pages/admin-main-pages/admin-user-management/service-partners/service-partners";
import { AdminUsers } from "../features/admin-panel/pages/admin-main-pages/admin-user-management/admin-users/admin-users";
import { adminGuard } from "../shared/guards/auth-guard";
import { AdminServiceDetails } from "../features/admin-panel/pages/admin-main-pages/admin-service-details/admin-service-details";

export const ADMIN_ROUTES: Routes = [
    {
        path: 'admin',
        children: [
            { path: '',redirectTo:'admin-login',pathMatch:"full"},
            { path: 'admin-login', component: AdminLogin },
            { path: 'admin-forget-password', component: AdminForgetPassword },
            { path: 'admin-reset-link', component: AdminResetLink },
            // {path:'admin-profile', component:AdminProfile},
            { path: 'admin-layout', component: AdminLayout,  canActivateChild: [adminGuard],
                children: [
                    { path: '', redirectTo: 'dashboard', pathMatch: 'full' },
                    { path: 'dashboard', component: AdminDashboard },
                  
                    {
                        path: 'service-management',
                        children: [
                          { path: '', component: AdminServiceManagement },
                          { path: 'service-details/:id', component: AdminServiceDetails }
                        ]
                      },
                    { path: 'user-management', component: AdminUserManagement,
                        children:[
                            {path:'',redirectTo:'customers',pathMatch:'full'},
                            {path:'customers',component:Customers},
                            {path:'service-partners', component:ServicePartners},
                            {path:'admin-users',component:AdminUsers}
                        ]
                    },
                    { path: 'booking-management', component: AdminBookingManagement },
                    { path: 'offers', component: AdminOffers },
                    { path: 'payment-&-transactions', component: AdminPaymentTransaction },
                    { path: 'master-data', component: AdminMasterData },
                    { path: 'support', component: AdminSupport },
                    { path: 'admin-profile', component: AdminProfile },
                ]
            },
            { path: 'error', component: AdminErrorPage },
            { path: '**', redirectTo: 'error', pathMatch: 'full' },
        ]
    }
]