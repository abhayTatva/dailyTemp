import { Routes } from "@angular/router";
import { Login } from "../features/user-panel/pages/login/login";
import { EnterOTP } from "../features/user-panel/pages/enter-otp/enter-otp";
import { Layout } from "../layout/user-layout/layout";
import { Home } from "../features/user-panel/pages/main-pages/home/home";
import { ServiceProvided } from "../features/user-panel/pages/main-pages/service-provided/service-provided";
import { ContactUs } from "../features/user-panel/pages/main-pages/contact-us/contact-us";
import { UserProfile } from "../features/user-panel/pages/main-pages/user-profile/user-profile";
import { authGuardGuard } from "../core/guards/auth-guard-guard";
import { UserBookings } from "../features/user-panel/pages/main-pages/user-bookings/user-bookings";
import { UserErrorPage } from "../features/user-panel/pages/user-error-page/user-error-page";
import { ServiceListing } from "../features/user-panel/pages/main-pages/service-listing/service-listing";
import { ServiceDetails } from "../features/user-panel/pages/main-pages/service-details/service-details";
import { CheckoutComponent } from "../features/user-panel/pages/main-pages/checkout/checkout";
import { ServiceProviderSignup } from "../features/user-panel/pages/service-provider-signup/service-provider-signup";
import { ServiceProviderThankyou } from "../features/user-panel/pages/service-provider-thankyou/service-provider-thankyou";
import { UserAddressForm } from "../features/user-panel/pages/main-pages/user-profile/user-address-form/user-address-form";
import { UserAddressSearch } from "../features/user-panel/pages/main-pages/user-profile/user-address-search/user-address-search";
import { UserAddressEdit } from "../features/user-panel/pages/main-pages/user-profile/user-address-edit/user-address-edit";
import { ServiceDetailsDemo } from "../features/user-panel/pages/main-pages/service-details-demo/service-details-demo";
export const USER_ROUTES: Routes = [
    {
        path: '',
        children: [
            { path: '', redirectTo: 'layout', pathMatch: 'full' },
            { path: 'login', component: Login },
            { path: 'enter-otp', component: EnterOTP },
            { path: 'service-provider-signup', component: ServiceProviderSignup },
            { path: 'service-provider-submitted', component: ServiceProviderThankyou },
            {
                path: 'layout', component: Layout,
                children: [
                    { path: '', redirectTo: 'home', pathMatch: 'full' },
                    { path: 'home', component: Home },
                    { path: 'service', component: ServiceProvided },
                    { path: 'service-listing/:id', component: ServiceListing },
                    { path: 'service-details-demo/:id', component: ServiceDetailsDemo },
                    { path: 'contact-us', component: ContactUs },
                    { path: 'profile', component: UserProfile, canActivate: [authGuardGuard] },
                    { path: 'bookings', component: UserBookings, canActivate: [authGuardGuard] }
                ]
            },
            {path:'checkout/:id',component:CheckoutComponent},
            //ERROR PATH
            { path: 'error', component: UserErrorPage },
            { path: '**', redirectTo: 'error', pathMatch: 'full' },
        ]
    }
]