import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { environment } from '../../environments/environment';
import { Observable, BehaviorSubject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class AdminService {

  private baseUrl = `${environment.apiBaseUrl}/Admin`;

  private adminProfileSubject = new BehaviorSubject<any>(null);
  adminProfile$ = this.adminProfileSubject.asObservable();

  constructor(private http: HttpClient) {}

  // JWT UTILITIES
  
  private getToken(): string | null {
    return localStorage.getItem('token');
  }

  private decodeToken(): any {
    const token = this.getToken();
    console.log(token);
    if (!token) return null;

    try {
      const payload = token.split('.')[1];
      const decodedPayload = atob(payload);
      console.log(decodedPayload);
      return JSON.parse(decodedPayload);
    } catch (error) {
      console.error('Invalid JWT token');
      return null;
    }
  }


  getAdminIdFromToken(): number | null {
    const decoded = this.decodeToken();
    if (!decoded) return null;

    return decoded.sub ? Number(decoded.sub) : null;
  }


  getAdminEmailFromToken(): string | null {
    const decoded = this.decodeToken();
    return decoded?.email || null;
  }

  getAdminNameFromToken(): string | null {
    const decoded = this.decodeToken();
    return decoded?.Name || null;
  }

  getAdminRoleFromToken(): string | null {
    const decoded = this.decodeToken();
    return decoded?.role || null;
  }

  getAdminProfile() {
    return this.adminProfileSubject.value;
  }

  setAdminProfile(profile: any) {
    this.adminProfileSubject.next(profile);
  }

  // API Calls
  getAdminById(id: number): Observable<any> {
    return this.http.get(`${this.baseUrl}/${id}`);
  }

  updateContactInfo(data: any): Observable<any> {
    return this.http.put(`${this.baseUrl}/update-contact-info`, data);
  }

  changePassword(data: any): Observable<any> {
    return this.http.put(`${this.baseUrl}/reset-password`, data);
  }

  updateBasicInfo(formData: FormData): Observable<any> {
    return this.http.put(`${this.baseUrl}/update-basic-info`, formData);
  }


}