import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { environment } from '../../environments/environment';
import { Observable } from 'rxjs';
import { Category } from '../Interfaces/Category';

export interface CreateCategoryRequest {
  name: string;
  serviceTypeId: number;
}

@Injectable({
  providedIn: 'root',
})
export class CategoryService {

  private readonly baseUrl = `${environment.apiBaseUrl}/categories`;

  constructor(private http: HttpClient) {}




  getByService(serviceTypeId: number): Observable<Category[]> {
    return this.http.get<Category[]>(
      `${this.baseUrl}/service/${serviceTypeId}`
    );
  }




  create(request: CreateCategoryRequest): Observable<any> {
    return this.http.post(this.baseUrl, request);
  }



  delete(id: number): Observable<void> {
    return this.http.delete<void>(`${this.baseUrl}/${id}`);
  }
  
}
  

