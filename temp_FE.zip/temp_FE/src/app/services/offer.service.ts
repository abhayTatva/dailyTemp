import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '../../environments/environment';
import {
  OfferResponseDto,
  CreateOfferRequestDto,
  UpdateOfferRequestDto,
  OfferFilterDto,
  PagedResult,
} from '../models/offer.model'; 

@Injectable({ providedIn: 'root' })
export class OfferService {
  private readonly baseUrl = `${environment.apiBaseUrl}/admin/offers`;

  constructor(private http: HttpClient) {}

  getAll(filter: OfferFilterDto): Observable<PagedResult<OfferResponseDto>> {
    let params = new HttpParams()
      .set('page', filter.page.toString())
      .set('pageSize', filter.pageSize.toString())
      .set('sortBy', filter.sortBy)
      .set('sortDirection', filter.sortDirection);

    if (filter.minDiscount != null) params = params.set('minDiscount', filter.minDiscount.toString());
    if (filter.maxDiscount != null) params = params.set('maxDiscount', filter.maxDiscount.toString());
    if (filter.isActive    != null) params = params.set('isActive',    filter.isActive.toString());
    if (filter.minTimeCouponApplied != null) params = params.set('minTimeCouponApplied',filter.minTimeCouponApplied.toString());
    if (filter.maxTimeCouponApplied != null) params = params.set('maxTimeCouponApplied',filter.maxTimeCouponApplied.toString());

    return this.http.get<PagedResult<OfferResponseDto>>(this.baseUrl, { params });
  }

  create(dto: CreateOfferRequestDto): Observable<OfferResponseDto> {
    return this.http.post<OfferResponseDto>(this.baseUrl, dto);
  }

  update(id: number, dto: UpdateOfferRequestDto): Observable<OfferResponseDto> {
    return this.http.put<OfferResponseDto>(`${this.baseUrl}/${id}`, dto);
  }

  delete(id: number): Observable<void> {
    return this.http.delete<void>(`${this.baseUrl}/${id}`);
  }
}
