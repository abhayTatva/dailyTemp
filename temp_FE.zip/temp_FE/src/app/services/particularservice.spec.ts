import { TestBed } from '@angular/core/testing';

import { Particularservice } from './particularservice';

describe('Particularservice', () => {
  let service: Particularservice;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(Particularservice);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
