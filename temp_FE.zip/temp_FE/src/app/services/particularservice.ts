import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '../../environments/environment';
import { ServiceDetail } from '../Interfaces/ServiceDetail';
import { Service, ServiceWithImage } from '../Interfaces/Service';

@Injectable({
  providedIn: 'root',
})
export class ParticularService {
  private apiUrl = `${environment.apiBaseUrl}/Services`;

  constructor(private http: HttpClient) { }
  getAllServices(): Observable<Service[]> {
    return this.http.get<Service[]>(this.apiUrl);
  }

  getServiceDetail(id: number): Observable<ServiceDetail> {
    return this.http.get<ServiceDetail>(`${this.apiUrl}/${id}`);
  }
  getPopularService(count:number):Observable<any>{
    const params = { count: count };

    return this.http.get<any>(`${this.apiUrl}/popular`, { params });
  
  }
 
  getAllServicesWithDetails(): Observable<ServiceWithImage[]> {
    return this.http.get<ServiceWithImage[]>(`${this.apiUrl}/details`) ;
  }
 
  getById(id: number): Observable<Service[]> {
    return this.http.get<Service[]>(
      `${this.apiUrl}/category/${id}`
    );
  }
  addService(formData: FormData): Observable<Service> {
    return this.http.post<Service>(`${this.apiUrl}`, formData);
  }

  updateAvailability(id: number, isAvailable: boolean): Observable<any> {
    return this.http.patch(
      `${this.apiUrl}/${id}/availability`,
      { isAvailable }
    );
  }
  deleteService(id: number) {
    console.log("deleting");
    return this.http.delete(
      `${this.apiUrl}/${id}`
    );
  }
  filterServices(filters: any): Observable<any> {
    console.log("filter called");
    return this.http.post(
      `${this.apiUrl}/filter`,
      filters
    );
  }


  getServicesBySubCategory(subCategoryId: number): Observable<Service[]> {
    return this.http.get<Service[]>(
      `${this.apiUrl}/subcategory/${subCategoryId}`
    );
  }

  updateService(id: number, formData: FormData): Observable<any> {
    return this.http.put(`${this.apiUrl}/${id}`, formData);
  }

}
