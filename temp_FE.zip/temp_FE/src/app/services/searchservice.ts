import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { environment } from '../../environments/environment';


@Injectable({
  providedIn: 'root'
})
export class SearchService {

    private baseUrl = `${environment.apiBaseUrl}/Services`;

  constructor(private http: HttpClient) {}
  searchServices(term:string){
    return this.http.get<any[]>(`${this.baseUrl}/search?term=${term}`);
  }

  
}