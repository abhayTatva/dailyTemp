import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { environment } from '../../environments/environment';
import { Observable } from 'rxjs';
import { ServiceType } from '../Interfaces/ServiceType';


@Injectable({
  providedIn: 'root'
})
export class ServiceTypes {

  private baseUrl =`${environment.apiBaseUrl}/Service`; 
 

  constructor(private http: HttpClient) {}


  getAll(): Observable<ServiceType[]> {
    return this.http.get<ServiceType[]>(this.baseUrl);
  }

  
   create(name: string, userId: number, image?: File): Observable<any> {
    const formData = new FormData();
    formData.append('name', name);
   
    formData.append('UserId', userId.toString());
  
    if (image) {
      formData.append('image', image);
    }
    console.log("-------------------------",name);

    return this.http.post(this.baseUrl, formData);
  }

  update(id: number, userId: number, name: string, image?: File): Observable<any> {
    const formData = new FormData();
    formData.append('name', name);
    formData.append('UserId', userId.toString());
    if (image) {
      formData.append('image', image);
    }

    return this.http.put(`${this.baseUrl}/${id}`, formData);
  }


  delete(id: number): Observable<any> {
    return this.http.delete(`${this.baseUrl}/${id}`);
  }
}