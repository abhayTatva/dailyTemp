import { TestBed } from '@angular/core/testing';

import { Subcategoryservice } from './subcategoryservice';

describe('Subcategoryservice', () => {
  let service: Subcategoryservice;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(Subcategoryservice);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
