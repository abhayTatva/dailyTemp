import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { environment } from '../../environments/environment';
import { Observable } from 'rxjs';

export interface SubCategory {
  id: number;
  name: string;
  categoryId: number;
}

export interface CreateSubCategoryRequest {
  name: string;
  categoryId: number;
}

@Injectable({
  providedIn: 'root'
})
export class SubCategoryService {

  private readonly baseUrl = `${environment.apiBaseUrl}/subcategories`;

  constructor(private http: HttpClient) {}

  getByCategory(categoryId: number): Observable<SubCategory[]> {
    return this.http.get<SubCategory[]>(
      `${this.baseUrl}/category/${categoryId}`
    );
  }

  create(request: CreateSubCategoryRequest): Observable<any> {
    return this.http.post(this.baseUrl, request);
  }

  delete(id: number): Observable<void> {
    return this.http.delete<void>(`${this.baseUrl}/${id}`);
  }
}