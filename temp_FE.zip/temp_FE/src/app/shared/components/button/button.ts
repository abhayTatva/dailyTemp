import { CommonModule } from '@angular/common';
import { Component, EventEmitter, Input, Output } from '@angular/core';

@Component({
  selector: 'app-button',
  imports: [CommonModule],
  templateUrl: './button.html',
  styleUrl: './button.css',
})
export class Button {
  @Input() label:string="click";
  @Input() width: string = '120px';
  @Input() height: string = '40px';
  @Input() borderRadius:string='40px';

  @Output() buttonClick=new EventEmitter<void>();

  onClick(){
    this.buttonClick.emit();
  }
}
