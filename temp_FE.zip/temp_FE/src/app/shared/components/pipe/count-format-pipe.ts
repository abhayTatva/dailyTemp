import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'countFormat',
  standalone: true
})
export class CountFormatPipe implements PipeTransform {

  transform(value: number | null | undefined): string {

    if (!value || value <= 0) return '0';

    if (value >= 1000000) {
      const m = (value / 1000000).toFixed(1).replace('.0', '');
      return `${m}M+`;
    }

    if (value >= 1000) {
      const k = (value / 1000).toFixed(1).replace('.0', '');
      return `${k}k+`;
    }

    if (value >= 100 && value < 1000) {
      const rounded = Math.floor(value / 100) * 100;
      return `${rounded}+`;
    }
    
    if (value >= 10 && value < 100) {
      const rounded = Math.floor(value / 10) * 10;
      return `${rounded}+`;
    }
    if (value >= 5) {
      return '5+';
    }

    return value.toString();
  }
}
