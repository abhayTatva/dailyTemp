import { CommonModule } from '@angular/common';
import { Component, EventEmitter, Input, OnChanges, Output, SimpleChanges } from '@angular/core';

@Component({
  selector: 'app-toast-message',
  imports: [CommonModule],
  templateUrl: './toast-message.html',
  styleUrl: './toast-message.css',
})
export class ToastMessage implements OnChanges {
  @Input() message: string | null = null;
  @Input() type: 'success' | 'error' = 'success';
  @Input() trigger = 0;

  visible = false;

  ngOnChanges(changes: SimpleChanges): void {
    if (this.message && changes['trigger']) {

      this.visible = true;

      setTimeout(() => {
        this.visible = false; 
      }, 4000)
    }
  }
}