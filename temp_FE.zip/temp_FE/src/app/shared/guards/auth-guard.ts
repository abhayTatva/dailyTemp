import { CanActivateChildFn, Router } from '@angular/router';
import { inject } from '@angular/core';
import { jwtDecode } from 'jwt-decode';

export const adminGuard: CanActivateChildFn = () => {

  const router = inject(Router);
  const token = localStorage.getItem('token');

  if (token) {
    try {
      const decoded: any = jwtDecode(token);
      const isTokenExpired = decoded.exp < Date.now() / 1000;

      if (isTokenExpired) {
        localStorage.removeItem('token');
      }
      return true;
    } catch (error) {
      localStorage.removeItem('token');
    }
  }

  router.navigate(['admin/admin-login']);
  return false;
};