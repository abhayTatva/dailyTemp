export const environment = {
    production: false,
    apiBaseUrl: 'http://localhost:5025/api',

    mediaBaseUrl: 'http://localhost:5025',

    apiBaseUrl2:'http://localhost:5025',

    stripePublishableKey: 'pk_test_51TEpMi0ayPLg8db65YuewlHym5xYZR4LiTv1iXO6eCu3jqAip6MHky1nY7SCKEqTn8HXXurRpAbWbRd4kR5J3xkH004C1kSBJa', 
  };
  